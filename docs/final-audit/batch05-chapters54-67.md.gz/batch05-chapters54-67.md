# Batch 05: revised Chapters 54 to 67

Author: Odejobi Abiola Samuel | CTROTECH
Review date: 15 October 2026

Substantive first pass, not independent approval or closed final gates. Canonical website/PDF source: content/chapters.json. Terms are defined in lesson prose and the publication glossary.

## Chapter 54: How parsing starts

### Objectives

- Describe tokenizer context
- Choose text insertion for plain untrusted text
- Distinguish parser contexts and fragment destinations

### Prerequisites

- CH-53

### Lesson

HTML parsing includes tokenization and tree construction. The tokenizer recognizes text, tags, attributes, comments and other tokens while its state affects how characters are interpreted. A less-than sign inside an ordinary text context does not have the same surrounding rules as text in script or style.

Character references are consumed in the contexts defined by the parser. An apparent tag inside a JavaScript string can still interact with the HTML script-data rules, which is why serializing arbitrary data into inline script needs careful escaping and a reviewed approach.

## Do not sanitize with a tag regex
Untrusted HTML needs a context-appropriate safe handling strategy. Plain text should usually be inserted as text. If a product truly accepts markup, use a maintained sanitizer configured for the allowed content and review how it interacts with the destination.

Encoding for one context does not automatically encode for another. An HTML attribute, JavaScript string, URL and CSS value have different grammar. The examples here are educational text; they are not a complete sanitizer implementation.

## The surrounding grammar changes the token
Normal text, RCDATA in title/textarea, raw text in style and the script-data states do not all recognize the same markup. Character references can be consumed in ordinary text and RCDATA, but an `&amp;` spelling inside script is not converted by that same rule into JavaScript source. Attribute values also have context-dependent reference rules.

The parser operates on decoded characters after encoding detection. NULs, numeric references and malformed input have specified error/replacement behavior. A parse error is not a general stop signal for text/html, and recovery does not make the original source conforming.

## A fragment has a destination context
The same `<tr><td>Fiction</td></tr>` string does not produce the same nodes when parsed for a div and for a tbody. Fragment parsing uses a context element; it is not just document parsing with the outer tags removed. DOMParser.parseFromString with text/html creates a separate HTML document. Unsupported MIME-type arguments produce TypeError; XML inputs have their own well-formedness/error results.

An innerHTML-inserted script generally does not run through ordinary script execution, but that fact is not an XSS defense: event-handler attributes and other active content still matter. A separately parsed document is not a sanitizer either. Do not adopt arbitrary parsed nodes into the live page without reviewing the trust boundary.

Trusted Types can constrain covered injection sinks where implemented and enforced. It does not certify that a policy's transformation is safe. Sanitization support, policy enforcement and parsing behavior each need their own checks.

### Primary example

```html
<p id="message"></p>
<script>
  const submittedText = "<strong>Recommended</strong>";
  document.getElementById("message").textContent = submittedText;
</script>
```

The literal string appears as text because the script assigns textContent. It does not create a strong element. Use this route when the product accepts text rather than markup.

### Common mistake

Assuming that stripping text between angle brackets with a regular expression produces safe HTML.

### Exercise

If a comment field is intended to accept plain text, why use textContent rather than innerHTML? Will the same row string necessarily create a row inside a div and a tbody?

### Explained answer

textContent creates text without interpreting the submitted string as markup. innerHTML parses markup and can introduce dangerous behavior if the data is not handled with a correct sanitization strategy. No. The fragment context changes tree construction. Also, a script not running after innerHTML insertion does not establish that the inserted HTML is safe.

### Sources

- [HTML Living Standard: tokenization](https://html.spec.whatwg.org/multipage/parsing.html#tokenization)
- [HTML Living Standard: dynamic insertion](https://html.spec.whatwg.org/multipage/dynamic-markup-insertion.html#dynamic-markup-insertion)
- [HTML Living Standard: fragment parsing](https://html.spec.whatwg.org/multipage/parsing.html#parsing-html-fragments)
- [DOM Parsing and Serialization](https://w3c.github.io/DOM-Parsing/)
- [OWASP: XSS prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html)

## Chapter 55: Tree construction and recovery

### Objectives

- Observe a repaired tree without recommending invalid source
- Reduce parsing bugs to a testable fixture
- Assert parsed relationships without endorsing recovery

### Prerequisites

- CH-54

### Lesson

The tree builder processes tokens using insertion modes and special rules. Table parsing, implied end tags and misnested formatting are examples where a browser can build a tree that differs from an author's naive reading of the source.

Error recovery is specified so browsers can process existing pages consistently. It is not a list of recommended authoring shortcuts. A source file can appear usable while the parsed relationships break labels, selectors or accessibility semantics.

## Make a small failing case
Reduce unexpected markup to the shortest document that still produces the surprising tree. Compare View Source with the live DOM. Remove scripts and extensions that might be modifying the result before blaming parsing.

Keep invalid examples explicitly labelled. When a checker reports a problem, record the intended correction and verify the resulting tree. Add a regression test for the relationship that mattered, not just a screenshot of the page.

## Three useful reduced observations
A table containing `<tr>` directly can gain a tbody in the parsed tree. A selector that requires table > tr will therefore miss a row even though the source visually suggests that relationship. Write the appropriate tbody explicitly when the teaching contract depends on it.

A div start tag inside a p can close the paragraph under tree-construction rules. Later end tags can create additional unexpected structure. Misnested formatting uses the adoption-agency rules; unexpected table content can be foster-parented. These are distinct algorithms, not one generic "the browser fixes it" step.

Keep the invalid source fixture and the corrected source separate. Check the exact relationship you rely on, such as whether a section is outside a paragraph or a row belongs to the expected row group. A DOM shape observed after recovery is not permission to publish the broken source.

## Avoid stream-writing as an enhancement strategy
Document.open/write/writeln/close manipulate document input streams under special rules. Calling write after ordinary parsing can replace the document, and intervening parser/network/execution conditions affect behavior. There are security and Trusted Types integration constraints as well. Prefer creating the intended nodes or a reviewed content-insertion path for a new interface; a short write call is not a general safe DOM append.

### Primary example

```html
<div class="notice">
  <p>Applications are open.</p>
  <section>
    <h2>How to apply</h2>
    <p>Collect a form at the desk.</p>
  </section>
</div>
```

This corrected structure keeps the section outside the paragraph. A paragraph cannot be used as a generic container for the whole notice, even if recovery makes the output look plausible.

### Common mistake

Testing a CSS selector against the intended source hierarchy rather than the hierarchy the parser actually created.

### Exercise

How should you investigate a table row that appears in an unexpected place in Developer Tools? Does an automatically inserted tbody prove that the author explicitly supplied it?

### Explained answer

Create a reduced complete document, inspect its actual DOM and check the source against table content rules. Parsing can relocate or imply nodes. Verify the correction with a checker and a DOM assertion. No. Record source and parsed DOM separately. Correct the authoring source and assert the intended relationship instead of relying only on a screenshot.

### Sources

- [HTML Living Standard: tree construction](https://html.spec.whatwg.org/multipage/parsing.html#tree-construction)

## Chapter 56: The document lifecycle

### Objectives

- Choose a readiness condition
- Separate document lifecycle from application data loading
- Separate lifecycle signals from operation promises

### Prerequisites

- CH-55

### Lesson

The document moves through loading states. DOMContentLoaded relates to parsing and eligible deferred/module script execution. The load event waits for the document's relevant dependent resources. Neither event proves that every later asynchronous operation has completed.

A script placed after a target element can often use that element immediately. A deferred external classic script runs after parsing under its ordering rules. Code that can run after DOMContentLoaded has already fired may need to inspect readyState before deciding whether to attach a listener.

## Separate readiness from data
A catalogue fetch completing is an application condition, not the same as the initial DOM being ready. Give the result area explicit loading, empty, error and success states where needed. Do not leave a spinner indefinitely because a request failed.

Document navigation, visibility changes, page restoration and the back-forward cache introduce further lifecycle cases. Avoid using unload as a dependable save system. Design persistence and recovery around the actual platform behavior and test reload and back navigation.

## Readiness changes do not describe every operation
readyState progresses through loading, interactive and complete under the document algorithms. At interactive, parsing has finished but the relevant deferred/module work and dependent resource lifecycle can still have work to do. readystatechange, DOMContentLoaded and load are different observation points.

The readyState guard avoids missing an already-fired DOMContentLoaded event. A module that resumes after an await or a script dynamically loaded later can need that guard too. Represent application completion with the promise or state for that operation, rather than declaring it finished when the document becomes interactive.

Use pageshow/pagehide and the persisted indication when investigating restoration. visibilitychange describes visibility state, not reliable proof that a session has ended. A pending async operation, a background timer and a back-forward-cache restoration each need their own analysis. Do not rely on unload to complete an important save or payment.

## Tasks and microtasks are different work
Promise reactions and queueMicrotask use microtask processing; timers schedule tasks under their own rules. A checkpoint can drain additional microtasks queued by earlier ones. A long microtask chain can postpone other work rather than making it "background" work. Rendering is not guaranteed after every task, and requestAnimationFrame is not a fixed-frequency clock.

### Primary example

```html
<p id="status-message">Preparing the catalogue view.</p>
<script>
  function initialize() {
    document.getElementById("status-message").textContent = "Catalogue view ready.";
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initialize, { once: true });
  } else {
    initialize();
  }
</script>
```

This pattern handles running before or after initial parsing has finished. It announces only that this local view initialization ran, not that remote catalogue data was fetched.

### Common mistake

Waiting for load for every DOM task, or assuming DOMContentLoaded waits for every image and application request.

### Exercise

What should your code wait for before rendering data from a specific fetch request? Does a zero-delay timer prove that the page was painted before its callback?

### Explained answer

Wait for that request and its response processing, then render or show its error state. Document readiness alone does not prove the data is available. No. Scheduling and rendering have separate rules. Wait for the actual operation and measure rendering if that is the question.

### Sources

- [HTML Living Standard: document readiness](https://html.spec.whatwg.org/multipage/dom.html#current-document-readiness)
- [HTML Living Standard: stop parsing](https://html.spec.whatwg.org/multipage/parsing.html#the-end)
- [HTML Living Standard: event loops](https://html.spec.whatwg.org/multipage/webappapis.html#event-loops)
- [HTML Living Standard: animation frames](https://html.spec.whatwg.org/multipage/imagebitmap-and-animations.html#animation-frames)

## Chapter 57: Scripts and execution

### Objectives

- Choose a loading strategy for dependencies
- Distinguish disabled scripting from script failure
- Test disabled and failed scripting as separate cases

### Prerequisites

- CH-56

### Lesson

An ordinary external classic script without async or defer can block parsing while it is fetched and executed. defer allows eligible external classic scripts to run after parsing, preserving their deferred execution order. async allows independent loading and execution without that dependency ordering guarantee.

Module scripts have their own loading, dependency, scope and CORS behavior. They are deferred by default in the usual parser-inserted case. Do not assume that adding type="module" to an existing global script preserves every behavior.

## Give dependency rules a home
If one script relies on another, represent the dependency through an appropriate module graph or a deliberately ordered loading strategy. Import maps define supported module-specifier mappings under their own processing rules. Newer script types, including speculation rules, need their own review.

noscript provides content for defined scripting-disabled cases. It is not a catch-all for script download failures or runtime exceptions. A progressively enhanced page should keep useful content and a clear failure path even when one script fails.

## Check which rules apply
For a classic script, `defer` is useful on an external script with `src`; adding it to an inline classic script does not defer that inline code. An async script must tolerate running when its own download is ready rather than relying on document order. Keep shared setup explicit instead of hoping the network will deliver files in the right order.

Module code runs in strict mode and has module scope. Top-level declarations do not become window properties merely because the module is loaded by a page. Check any code that expects globals, and test a failed dependency as well as the successful path.

## Dynamic script insertion has its own flags
A dynamically inserted external classic script can run asynchronously by default. If an application deliberately needs insertion order, set the relevant async property before insertion and review the loading/error contract. Merely changing an attribute after execution does not rerun a script.

An import map uses its defined JSON imports/scopes rules and affects module-specifier resolution. It does not load a library by itself, and it does not remap every classic script src or fetch URL. Place the mapping before dependent resolution and review current multiple-map/merging rules rather than repeating an old universal one-map claim.

A module must also satisfy fetching, MIME-type, CORS and dependency rules. Failed imports need a usable baseline. Top-level await and application promises add completion conditions beyond assuming that every statement finished at DOMContentLoaded. nomodule addresses module-capable processing, not a promise that a non-module fallback is current or accessible.

The supplied catalogue is an actual progressive enhancement: its list exists in HTML and the external script adds a local filter. Disabled controls are enabled only after their listeners are installed. A resource failure does not turn an apparently working search into a fake service.

### Primary example

```html
<section aria-labelledby="catalogue-heading">
  <h2 id="catalogue-heading">Supplied fictional titles</h2>
  <form id="local-filter">
    <label for="catalogue-query">Filter supplied titles</label>
    <input id="catalogue-query" name="q" type="search" disabled>
    <button type="submit" disabled>Filter titles</button>
    <button type="reset" disabled>Show all titles</button>
  </form>
  <p id="catalogue-result" role="status">All three teaching titles are listed below.</p>
  <ul id="catalogue-list">
    <li>Local histories</li>
    <li>Poetry</li>
    <li>Fiction</li>
  </ul>
  <p><a href="#catalogue-list">Browse the supplied list</a></p>
</section>
<script src="../assets/catalogue-demo.js" defer></script>
<noscript><p>Filtering needs JavaScript; the supplied list remains readable.</p></noscript>
```

The supplied deferred script enables and implements local filtering and reset. The list is meaningful before enhancement, while failed or disabled scripting leaves its controls disabled. noscript is not the runtime-failure path. The editor blocks external scripts, so use the standalone example for the filter. No server search or real stock is implied.

### Common mistake

Using async on two dependent classic scripts and relying on their tag order for execution order.

### Exercise

Would noscript automatically display when a script downloads successfully but throws an exception? Does an import map automatically fetch every mapped library?

### Explained answer

No. Scripting remains enabled. Handle the failure in the application design and keep a useful underlying document instead of relying on noscript for runtime errors. No. It supplies resolution mappings for the relevant module loading. Test imports, failures and the non-enhanced baseline separately.

### Sources

- [HTML Living Standard: script](https://html.spec.whatwg.org/multipage/scripting.html#the-script-element)
- [HTML Living Standard: noscript](https://html.spec.whatwg.org/multipage/scripting.html#the-noscript-element)

## Chapter 58: HTML and XML serialization

### Objectives

- Distinguish HTML and XML processing
- Test the media type rather than guessing from source style
- Observe served media type, case and empty-element differences

### Prerequisites

- CH-57

### Lesson

HTML syntax and XML syntax are not interchangeable decorations around the same file. A response's media type determines the relevant processing path. Renaming a file or adding an XHTML-looking namespace does not make a text/html response use XML parsing.

In HTML, element and attribute processing includes defined case handling and error recovery. XML has different well-formedness, namespace and case rules. An XML parse error is not handled like an ordinary recoverable HTML authoring error.

## Do not infer a mode from a slash
A trailing slash on br in HTML is not the XML mechanism applied to every element. A non-void HTML element still needs its end tag. Conversely, XML serialization has its own namespace and empty-element rules.

If you intentionally serve application/xhtml+xml, test the actual HTTP Content-Type and XML requirements. For normal HTML authoring in this book, use the short HTML doctype, UTF-8 and text/html. Preserve namespace-sensitive behavior when integrating SVG or MathML.

## Namespaces and well-formedness are substantive
XML preserves case distinctions in element and attribute names. A namespaced html root is needed for the intended XHTML vocabulary, and attributes such as xmlns are not a switch that changes an existing text/html response into XML. An XML serialization must also satisfy well-formedness, including proper quoting and balanced tags.

For HTML elements in text/html, a slash before a start-tag close does not turn an ordinary div into an XML empty element. An unquoted attribute value immediately followed by slash can absorb that slash into the value, which is another reason not to treat visual slash style as mode evidence.

DOMParser accepts defined MIME-type arguments. An XML syntax error can be represented by a document containing parsererror, rather than an HTML-style recovered tree. The detailed error presentation can differ by engine. XMLSerializer serialization is not a conversion that silently sanitizes arbitrary data or guarantees that the result can be safely reparsed in any chosen context.

Check served Content-Type and the resulting DOM together. The controlled tests use the same namespace-bearing bytes under text/html and application/xhtml+xml to demonstrate that difference; they do not change this publication into an XHTML service.

### Primary example

```html
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>HTML serialization</title></head>
<body><p>Neighbourhood Library<br>Reading room entrance</p></body>
</html>
```

This is intended as text/html. The br element is void and does not have an end tag. A local browser file test is not proof of the headers used by a deployed server.

### Common mistake

Adding xmlns to html and assuming it switches the HTML parser to XML mode.

### Exercise

Which matters more for choosing the HTML or XML parsing path: an XHTML-looking source style or the actual response media type? Does adding xmlns to HTML source override a text/html response?

### Explained answer

The actual processing context and response media type matter. Confirm the server behavior and follow the rules for that syntax; visual resemblance to XHTML is insufficient. No. The processing context still matters. XML parsing preserves case and has different empty-element and well-formedness behavior.

### Sources

- [HTML Living Standard: XML syntax](https://html.spec.whatwg.org/multipage/xhtml.html#the-xhtml-syntax)
- [HTML Living Standard: HTML syntax](https://html.spec.whatwg.org/multipage/syntax.html#syntax)
- [DOM Parsing and Serialization](https://w3c.github.io/DOM-Parsing/)

## Chapter 59: HTML and rendering

### Objectives

- Distinguish default appearance from meaning
- Keep source and interaction order understandable
- Keep actual navigation destinations and reading order coherent

### Prerequisites

- CH-58

### Lesson

Browsers have default rendering rules and styles. A heading often appears bold and large; an anchor often appears underlined. Those defaults make an unstyled document usable, but they do not define every semantic or accessibility behavior.

Changing display can alter layout without changing the element's underlying HTML definition. It can also interact with accessibility mappings and implementation quirks. Test the actual result rather than assuming a CSS property is semantically harmless everywhere.

## Keep reading order deliberate
Layout can visually reorder items while the DOM order stays the same. A keyboard or screen reader may encounter a sequence unlike the visual arrangement. Put the logical order in HTML and use layout to adapt it without creating competing stories.

Use HTML attributes with their intended behavior rather than recreating them through presentation alone. CSS hiding, hidden and inert have different consequences. Contrast, focus visibility, reflow and zoom are also part of the usable page, even though their implementation often lives in CSS.

## Visual position does not rewrite source order
Flex/grid order can change the visual sequence without rewriting the DOM's ordinary sequence. Do not repair a visual mismatch with a chain of positive tabindex values. Fix the meaningful source order, then check both the layout and the actual keyboard/reading experience.

Browser default styles are rendering guidance with implementation variation. Removing a default outline, suppressing an underline or forcing colours can remove a useful affordance. Test forced-colour settings, zoom and narrow layouts with actual content.

A computed CSS value does not prove an accessible-name or role mapping. HTML-AAM and the accessible-name computation address different questions from a screenshot. Display changes and native control styling need implementation and assistive-technology evidence beyond the semantic source definition.

### Primary example

```html
<article>
  <h1>Visit the fictional reading room</h1>
  <p>These are teaching values, not a real service timetable.</p>
  <a href="#example-hours">Read the example hours</a>
  <section id="example-hours" aria-labelledby="hours-heading">
    <h2 id="hours-heading">Example opening hours</h2>
    <p>Tuesday to Saturday, <time datetime="09:00">09:00</time>
       to <time datetime="17:00">17:00</time>.</p>
  </section>
</article>
```

The link now reaches actual in-document teaching content. The DOM gives the context before the destination and remains useful without layout. These fictional hours are not a claim about a real library.

### Common mistake

Choosing an element because its browser default margin looks right, then compensating for the wrong semantics with ARIA.

### Exercise

Can CSS make an h2 look larger than an h1 without changing their heading levels? Can a reversed flex layout prove that DOM or keyboard order was reversed too?

### Explained answer

Yes. Presentation and heading rank are different. Keep the semantic hierarchy appropriate and use CSS for the visual scale, then check that the overall design still communicates the structure. No. Test each sequence deliberately. Prefer one meaningful source order over a separate positive-tabindex patch.

### Sources

- [HTML Living Standard: rendering](https://html.spec.whatwg.org/multipage/rendering.html#rendering)
- [HTML accessibility mappings](https://www.w3.org/TR/html-aam-1.0/)

## Chapter 60: Where the wider APIs begin

### Objectives

- Identify wider API responsibilities
- Keep API integration separate from member-level completeness
- Execute storage recovery and a bounded worker with failure paths

### Prerequisites

- CH-59

### Lesson

The HTML Standard includes more than markup. It defines navigation and history behavior, messaging, workers, worklets, storage, event loops and many interfaces. A language guide can introduce their integration, but a named-interface list does not document every member or algorithm.

localStorage is synchronous, origin-scoped storage with its own access and failure behavior. It is not a suitable place for secrets simply because it is local. Workers run script in a different execution environment, not a second DOM you can manipulate directly. Messaging needs explicit origin and data validation where relevant.

## Treat integration as a design decision
A history update needs a corresponding content and navigation strategy. A cross-document message needs an expected sender and validated payload. A background task needs cancellation and failure handling. These responsibilities do not disappear because the API call is short.

## What the catalogue actually contains
The foundation catalogue retains 166 named interface discovery routes. The expanded declaration register separately records 314 named WebIDL declaration owners and 1,574 direct member declarations in the captured source. Owners include more than interfaces, and direct declarations do not expand every inherited member. These are different inventories, not competing counts of the same thing.

Use the declaration register for signatures and links to definitions. A declaration alone does not explain an algorithm, an exception, an event sequence or a security boundary. Some member links deliberately fall back to their owning definition and are labelled accordingly. Whole-Standard behavioral coverage, imported cross-specification APIs and independent review remain open.

Storage can fail. Access may be restricted by the document's origin or browser policy, and writes can fail when storage limits are reached. Keep the page usable when a preference cannot be saved. Do not assume that a successful write is a durable backup or that any script running in the same origin is barred from reading the stored data.

## Storage methods have different contracts
Storage values are strings. getItem returns null when the key is absent; key(index) can return null; ordering is not a portable insertion-order guarantee. setItem can throw QuotaExceededError, and obtaining storage for an ineligible origin or under policy can throw SecurityError. localStorage and sessionStorage have different lifetime/partition rules. Use removeItem for your own key instead of clear when unrelated same-origin settings must remain.

A storage event is delivered to the relevant other documents, not as a notification to the writing document itself. A no-change write is not a new-value event. Same-origin access is not a user-account permission boundary, and persistence can be cleared or restricted by browser policy.

## History and messages need more than a method call
pushState and replaceState do not by themselves load a new view. Their serializable state and same-origin URL constraints can produce DataCloneError or SecurityError. Read popstate state and restoration needs when designing traversal. Newer Navigation APIs require separate lifecycle/compatibility work.

postMessage serializes data using the defined structured-clone rules. An uncloneable function can produce DataCloneError. Use a specific target origin for normal cross-document delivery, then validate event.origin, event.source and the payload shape at the receiver. A wildcard or a familiar-looking message string is not sender authentication. Transferring an ArrayBuffer changes ownership and detaches it under the transfer rules; it is not just copying JSON.

MessageChannel/MessagePort and BroadcastChannel have different addressing and lifecycle contracts. Start or close ports/channels as appropriate, handle messageerror where relevant and avoid assuming that a channel name is a secret permission token.

## Worker and scheduling scope remains explicit
A dedicated worker has its own global scope, not document access. Construction/loading, CSP, origin restrictions, serialization, errors and termination all matter. The supplied worker is a tiny bounded calculation, not a performance benchmark or shared/service-worker lifecycle demonstration.

A timeout is a minimum-delay scheduling request, not an exact alarm. Nested timers have the defined clamping rules, and background scheduling can differ. requestAnimationFrame runs under rendering opportunities; it can be paused or throttled. The full owner/member register, worklets, shared/service workers and all event-loop/timing/navigation algorithms remain open, not silently excluded.

### Primary example

```html
<form id="example-preference">
  <label for="example-view">Example view preference</label>
  <select id="example-view" name="view">
    <option value="comfortable">Comfortable</option>
    <option value="compact">Compact</option>
  </select>
  <button type="submit" disabled>Store example preference</button>
  <button type="button" id="remove-preference" disabled>Remove stored preference</button>
</form>
<p id="preference-result" role="status">No storage result yet.</p>
<button type="button" id="run-worker" disabled>Run background sum</button>
<p id="worker-result" role="status">No calculation requested.</p>
<p><a id="worker-source" href="../assets/worker-demo.js" download="worker-demo.js">Download the supplied worker source</a></p>
<script>
  const form = document.getElementById("example-preference");
  const choice = document.getElementById("example-view");
  const note = document.getElementById("preference-result");
  const key = "ctrotech.teaching.view";
  try {
    const stored = localStorage.getItem(key);
    if (stored === "compact" || stored === "comfortable") {
      choice.value = stored;
      note.textContent = "Stored example preference restored.";
    } else {
      note.textContent = "No recognized stored preference; choose a local value.";
    }
  } catch {
    note.textContent = "Storage unavailable; the selection still works locally.";
  }
  form.addEventListener("submit", event => {
    event.preventDefault();
    try {
      localStorage.setItem(key, choice.value);
      note.textContent = "Example preference stored in this browser.";
    } catch {
      note.textContent = "Not stored; the selection still works locally.";
    }
  });
  const remove = document.getElementById("remove-preference");
  remove.addEventListener("click", () => {
    try {
      localStorage.removeItem(key);
      note.textContent = "The example's stored preference was removed.";
    } catch {
      note.textContent = "Storage unavailable; no removal confirmed.";
    }
  });
  form.querySelector("button[type=submit]").disabled = false;
  remove.disabled = false;
  const run = document.getElementById("run-worker");
  const workerNote = document.getElementById("worker-result");
  run.addEventListener("click", () => {
    run.disabled = true;
    workerNote.textContent = "Calculating the teaching sum.";
    let worker;
    let finished = false;
    let timer;
    const finish = text => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      workerNote.textContent = text;
      if (worker) worker.terminate();
      run.disabled = false;
    };
    timer = setTimeout(() => finish("Calculation timed out; try again."), 5000);
    try {
      worker = new Worker(document.getElementById("worker-source").href);
      worker.addEventListener("message", event => {
        const data = event.data;
        finish(data && data.kind === "sum" && Number.isFinite(data.total)
          ? "Background sum: " + data.total
          : "The worker returned an unusable result.");
      }, { once: true });
      worker.addEventListener("error", event => {
        event.preventDefault();
        finish("Background calculation unavailable.");
      }, { once: true });
      worker.addEventListener("messageerror", () => finish("Worker message could not be read."), { once: true });
      worker.postMessage([2, 3, 5]);
    } catch {
      finish("Background calculation unavailable.");
    }
  });
  run.disabled = false;
</script>
```

The storage controls restore, store and remove only a namespaced teaching key, with truthful failure messages. The supplied worker validates a short finite-number payload, computes 10 and is terminated after completion, reported failure or the stated five-second teaching timeout. Its URL comes from an actual source link, so the compiled hashed asset stays resolvable. The editor restricts storage/workers; use the standalone example for successful paths. This is not a durable backup, a view-layout implementation or an exhaustive worker application.

### Common mistake

Calling a reference complete because every interface name appears somewhere in it.

### Exercise

Why does the example catch a storage failure rather than assuming localStorage is always writable? Does a storage event notify the writing document of its own setItem call?

### Explained answer

Access restrictions, browser settings and storage failures can prevent writing. A preference control should remain usable and explain the actual result. Do not report a successful save when the write failed. No. Use an explicit local update and the specified events for other documents. Transfer, history and worker methods also have their own serialization, origin and lifecycle constraints.

### Sources

- [HTML Living Standard: web application APIs](https://html.spec.whatwg.org/multipage/webappapis.html#webappapis)
- [HTML Living Standard: web storage](https://html.spec.whatwg.org/multipage/webstorage.html#webstorage)
- [HTML Living Standard: messages](https://html.spec.whatwg.org/multipage/web-messaging.html#web-messaging)
- [HTML Living Standard: workers](https://html.spec.whatwg.org/multipage/workers.html#dedicated-workers-and-the-worker-interface)
- [HTML Living Standard: history](https://html.spec.whatwg.org/multipage/nav-history-apis.html#the-history-interface)
- [HTML Living Standard: timers](https://html.spec.whatwg.org/multipage/timers-and-user-prompts.html#timers)
- [HTML Living Standard: animation frames](https://html.spec.whatwg.org/multipage/imagebitmap-and-animations.html#animation-frames)

## Chapter 61: Accessibility starts in the markup

### Objectives

- Use native semantics with accurate names
- Separate automated checks from accessibility conformance
- Test the actual local filter across success, empty and reset states

### Prerequisites

- CH-60

### Lesson

Use native elements that fit the task, then review the name, role, state and behavior actually exposed to users. A button needs an understandable name and an operable action. A heading needs a useful position in the document hierarchy. A table needs its data relationships.

ARIA can supplement semantics where needed. It can also introduce wrong or conflicting information. Follow ARIA in HTML restrictions rather than adding roles to every element. Prefer an existing visible label through a native label relationship or a suitable reference before inventing an unrelated hidden name.

## Review the entire task
A successful automated scan does not demonstrate WCAG conformance. Test keyboard operation, visible focus, text alternatives, error correction, zoom, reflow and appropriate assistive-technology behavior. Include the actual data and content states, not just a polished empty page.

WCAG describes requirements at the level of the delivered experience. HTML-AAM, AccName, WAI-ARIA and ARIA in HTML help answer more specific mapping and authoring questions. This edition links to them but has not completed an independent accessibility audit. Record that limitation instead of turning a few semantic examples into a certification badge.

## A usable name must still describe the visible task
Accessible-name computation follows its rules, including labelledby references, aria-label, host-language labels and other context-specific sources. An aria-label can override a useful visible label in relevant cases. That is not automatically an improvement: preserve the visible label text in the accessible name where the applicable Label in Name requirement calls for it.

ARIA roles/states do not implement a custom widget's keyboard behavior, validation or permission checks. Adding role="button" to a span does not turn it into a native button. Use ARIA in HTML to check permitted overrides, and HTML-AAM/AccName for mapping/name questions rather than equating a DOM attribute with an OS accessibility result.

## Follow one task across its states
For the supplied filter, test label/name, query entry, Enter activation, matching results, no matches, reset and failed scripting. Verify status communication with the actual assistive technology. Do not move focus to the status after every query merely to force an announcement.

Record zoom/reflow, contrast, visible focus, target sizing, error recovery and text alternatives as separate applicable checks. WCAG 2.2 has requirements beyond a clean semantic snippet; no automated result or role query closes that review.

### Primary example

```html
<section aria-labelledby="catalogue-heading">
  <h2 id="catalogue-heading">Supplied fictional titles</h2>
  <form id="local-filter">
    <label for="catalogue-query">Filter supplied titles</label>
    <input id="catalogue-query" name="q" type="search" disabled>
    <button type="submit" disabled>Filter titles</button>
    <button type="reset" disabled>Show all titles</button>
  </form>
  <p id="catalogue-result" role="status">All three teaching titles are listed below.</p>
  <ul id="catalogue-list">
    <li>Local histories</li>
    <li>Poetry</li>
    <li>Fiction</li>
  </ul>
  <p><a href="#catalogue-list">Browse the supplied list</a></p>
</section>
<script src="../assets/catalogue-demo.js" defer></script>
<noscript><p>Filtering needs JavaScript; the supplied list remains readable.</p></noscript>
```

The visible label, native controls and actual local filter support a complete small task. Enter submits, reset restores the three titles and a no-match query gets a visible status. No live catalogue or availability service is implied. The external script is supplied; the editor blocks it, so the standalone example is the enhancement test target. role=status is not proof that every assistive-technology combination announces the update.

### Common mistake

Adding an aria-label that contradicts the visible wording, or describing role-based automated tests as a complete accessibility review.

### Exercise

A scanner reports no issues. What should you do before claiming that the search experience is accessible? Does overriding a visible label with an unrelated aria-label necessarily improve usability?

### Explained answer

Complete the relevant manual and assistive-technology checks across the actual task and states, assess applicable WCAG requirements, and document results and limitations. A scanner result is one piece of evidence. No. Preserve task meaning and review name computation, permitted ARIA and Label in Name. Test the actual task and assistive-technology output, not just the attribute.

### Sources

- [HTML Living Standard: HTML semantics and ARIA](https://html.spec.whatwg.org/multipage/dom.html#wai-aria)
- [WCAG 2.2](https://www.w3.org/TR/WCAG22/)
- [ARIA in HTML](https://www.w3.org/TR/html-aria/)
- [WAI tutorials](https://www.w3.org/WAI/tutorials/)
- [Accessible name computation](https://www.w3.org/TR/accname-1.2/)
- [HTML accessibility mappings](https://www.w3.org/TR/html-aam-1.0/)
- [WCAG: label in name](https://www.w3.org/WAI/WCAG22/Understanding/label-in-name.html)

## Chapter 62: Keyboard and focus review

### Objectives

- Run a task-based keyboard check
- Plan focus after dynamic changes
- Execute removal/restoration with predictable focus destinations

### Prerequisites

- CH-61

### Lesson

Begin at the top of the page and use Tab, Shift+Tab, Enter, Space and the keys appropriate to each native control. Confirm that every needed action is reachable, the order is sensible and focus remains visible.

Do not require hover to reveal the only route to an action. A control that appears on pointer hover should have an equivalent usable focus or interaction path. Keep focus indications strong enough to locate rather than removing outlines without a replacement.

## Check transitions, not just tab stops
Open and close a dialog. Submit an invalid form. Remove a focused list item. Load more results. These transitions need deliberate focus and feedback behavior. Moving focus on every update can be as disruptive as losing it.

A disabled control and an aria-disabled control do not automatically behave the same way. ARIA communicates semantics but does not implement all interaction restrictions. Choose the appropriate element/state and test the actual behavior.

Record the browser, operating system and assistive technology used. A successful keyboard pass in one environment is useful evidence, not a claim about all combinations.

## Focus must survive the state transition
A predictable focus order is about usable relationships, not merely counting Tab presses. If a focused row disappears, select the next or previous relevant action, or a meaningful heading when the list is empty. Restore should also have a deliberate destination. The working example makes that policy inspectable.

Sequential focusability, programmatic focus, disabled state and aria-disabled remain different. A custom aria-disabled action still needs its click/keyboard suppression implemented. A sticky overlay can obscure the focused item even when the item is technically focused; review Focus Not Obscured alongside Focus Order and Focus Visible.

Native control keys and platform tab preferences can vary. Record actual key actions and results, not a universal assumption that every native widget exposes exactly the same tab stops. Focus tests should cover pointer-triggered transitions too, and never claim OS screen-reader output from document.activeElement alone.

### Primary example

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Local reading-list focus review</title>
<style>
  .skip-link { position: absolute; left: .5rem; top: .5rem;
    transform: translateY(-180%); background: white; color: black;
    padding: .5rem; z-index: 2; }
  .skip-link:focus { transform: none; }
  a:focus-visible, button:focus-visible, [tabindex]:focus-visible {
    outline: 3px solid #163fc2; outline-offset: 3px;
  }
</style>
</head>
<body>
<a href="#keyboard-main" class="skip-link">Skip to main content</a>
<main id="keyboard-main" tabindex="-1">
  <h1 id="list-heading" tabindex="-1">Fictional reading list</h1>
  <ul id="removable-list">
    <li><span>Local histories</span> <button type="button" disabled>Remove Local histories</button></li>
    <li><span>Poetry</span> <button type="button" disabled>Remove Poetry</button></li>
    <li><span>Fiction</span> <button type="button" disabled>Remove Fiction</button></li>
  </ul>
  <p id="remove-status" role="status">Changes stay in this page only.</p>
  <button id="restore-list" type="button" disabled>Restore initial titles</button>
</main>
<script>
  const list = document.getElementById("removable-list");
  const note = document.getElementById("remove-status");
  const heading = document.getElementById("list-heading");
  function enableItems() {
    list.querySelectorAll("button").forEach(button => button.disabled = false);
  }
  list.addEventListener("click", event => {
    if (!(event.target instanceof Element)) return;
    const button = event.target.closest("button");
    if (!button || button.disabled) return;
    const item = button.closest("li");
    const next = item.nextElementSibling || item.previousElementSibling;
    const destination = next ? next.querySelector("button") : heading;
    const title = item.querySelector("span").textContent;
    item.remove();
    destination.focus();
    note.textContent = title + " removed from this local list.";
  });
  const restore = document.getElementById("restore-list");
  restore.addEventListener("click", () => {
    list.replaceChildren();
    for (const title of ["Local histories", "Poetry", "Fiction"]) {
      const item = document.createElement("li");
      const text = document.createElement("span");
      const button = document.createElement("button");
      text.textContent = title;
      button.type = "button";
      button.textContent = "Remove " + title;
      item.append(text, " ", button);
      list.append(item);
    }
    heading.focus();
    note.textContent = "The initial teaching list was restored.";
  });
  enableItems();
  restore.disabled = false;
</script>
</body>
</html>
```

The skip link has a supplied focus-visible style, and removal now performs the actual local action. Focus moves to the next item, otherwise the previous item, otherwise the heading. Restore rebuilds the teaching list safely and returns focus to its heading. This is not saved to a server; status announcements and focus visibility still need actual OS AT and user review.

### Common mistake

Setting a positive tabindex sequence to match a visual layout instead of fixing the source order.

### Exercise

After deleting the focused row in a list, where should focus go? What should happen when the final item is removed in this example?

### Explained answer

There is no universal target. Choose a predictable nearby control or a relevant list heading based on the task, then test the behavior. Do not let focus disappear into the document body accidentally. The meaningful list heading receives focus. The visible result explains the local removal; actual assistive-technology feedback must still be checked.

### Sources

- [HTML Living Standard: focus model](https://html.spec.whatwg.org/multipage/interaction.html#focus)
- [WCAG: focus order](https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html)
- [WCAG: focus not obscured](https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum.html)

## Chapter 63: Trust boundaries

### Objectives

- Identify client-controlled data
- Choose controls for specific trust boundaries
- Distinguish text insertion, serialization and origin validation

### Prerequisites

- CH-62

### Lesson

A browser can display constraints and hidden values, but a requester can send a different request. Validate on the server, enforce the relevant authentication and authorization rules, and apply abuse controls appropriate to the service.

For content insertion, distinguish plain text from accepted markup. textContent fits text. Markup acceptance needs a maintained, context-appropriate sanitization strategy. A handmade list of forbidden strings is not a dependable general sanitizer.

## Review each boundary
A form crosses into a server handler. An iframe crosses into another document. A script can introduce a remote execution dependency. A file upload crosses into storage and later retrieval. Document the expected origin, allowed capabilities and validation for each boundary.

Security policies and headers belong to the deployment as well as the document. CSP, CORS, SRI, referrer policy and Permissions Policy address different concerns. Do not describe any one of them as a complete defense. Test the intended failure behavior, and never place private API credentials in HTML, client JavaScript, data attributes or a downloadable environment file.

## An origin is a browser boundary, not the whole service policy
Origin comparison uses the relevant scheme/host/port rules, not a substring test on a URL. Sandboxing without allow-same-origin can create an opaque origin; a null message origin is not enough to identify a trusted sender. Capability allowances and destination validation need deliberate design.

CSP limits covered execution/resource behavior, CORS governs specified cross-origin response sharing, SRI checks resource bytes, Referrer Policy controls referrer information and Permissions Policy controls eligible features. None substitutes for authenticated server authorization. A blocked script request and a refused form action are different failure paths.

## Encode for the actual output and review the sanitizer
For embedded JSON in script text, JSON.stringify alone is not a general HTML-context encoder: a raw closing script delimiter can end the element before JavaScript processes it. A reviewed serializer can escape the relevant less-than characters as JavaScript/JSON escapes, then preserve the data on decoding. Do not reuse that technique indiscriminately for HTML attributes, CSS or URLs.

A Trusted Types policy whose callback simply returns input does not create a sanitizer. Browser enforcement can reject a string at a covered sink, while unsafe allowed transformations can still be unsafe. Prefer plain text where markup is not a product requirement, keep maintained sanitizer versions/configuration visible and test both rejected input and allowed output.

For servers, require the intended method/content handling, identity, authorization, CSRF protection where applicable, upload constraints and log/privacy controls. Hidden fields and a correctly validated client form are not substitutes. This static publication does not add a collection service.

### Primary example

```html
<p id="reader-comment"></p>
<script>
  const commentFromAReader = "A useful guide <script>example</scr" + "ipt>";
  document.getElementById("reader-comment").textContent = commentFromAReader;
</script>
```

The comment is rendered as text. Splitting the closing script spelling here avoids accidentally terminating the surrounding HTML script element. Real serialization should use a reviewed data-embedding strategy.

### Common mistake

Thinking that a value is trusted because it originated in a hidden input or a front-end build variable.

### Exercise

Why must the server ignore a submitted role="admin" value when deciding a requester's permissions? Does a Trusted Types policy that returns every input string establish safe HTML?

### Explained answer

The requester controls submitted data. Authorization must use trusted server-side identity and permission information, not a role string supplied by the client. No. Enforcement and the safety of the policy transformation are separate. A client-side origin or role string is not trusted server authorization either.

### Sources

- [HTML Living Standard: dynamic markup insertion](https://html.spec.whatwg.org/multipage/dynamic-markup-insertion.html#dynamic-markup-insertion)
- [OWASP: input validation guidance](https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html)
- [OWASP: authorization guidance](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)
- [OWASP: XSS prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html)
- [OWASP: CSP guidance](https://cheatsheetseries.owasp.org/cheatsheets/Content_Security_Policy_Cheat_Sheet.html)

## Chapter 64: Performance without folklore

### Objectives

- Relate HTML loading choices to real resources
- Report measured results with their conditions
- Use a supplied dimensioned resource without fabricating a speed result

### Prerequisites

- CH-63

### Lesson

HTML influences resource discovery and loading. An early stylesheet link, a delayed image source, script loading attributes and image candidates can affect the page's critical work. Measure the actual page on representative conditions before prescribing changes.

Provide image dimensions and appropriate resources. Keep likely important above-the-fold media from being needlessly delayed. Lazy loading is useful when deferring a resource is appropriate; it is not a rule to apply to every image.

## Test a before and an after
Record the page version, device or emulation, network conditions and measurement method. Repeat enough to recognize variation. Do not invent percentage improvements or treat one warm-cache result as a stable performance guarantee.

A fast initial response can coexist with a slow interaction. Loading less script helps only when it addresses actual work. Keep the underlying document usable while enhancements load. Review the network waterfall and interaction path together rather than optimizing a score in isolation.

## Attribute hints have limited states
fetchpriority accepts high, low and auto, with Auto for missing or invalid values. It influences the relevant fetch, not a guaranteed queue position. loading uses its defined eager/lazy states; missing/invalid follows its eager default. Deferred lazy resources also have scripting-related conditions. Verify the actual resource request, decoding and layout instead of treating attribute reflection as a speed measurement.

## Match a metric to the user question
LCP concerns an eligible largest-content paint candidate, CLS concerns qualifying unexpected layout shifts and INP concerns the relevant interaction responsiveness measurement. Those metrics have their own definitions, aggregation and implementation boundaries; a request count is none of them. Field data and a controlled lab run answer different questions.

Performance entries may expose limited cross-origin details without the appropriate Timing-Allow-Origin configuration. Warm caches, service workers, throttling and device work can change results. Record the conditions and repeat comparisons; no percentage or score improvement is claimed by this example.

### Primary example

```html
<figure>
  <img src="../assets/media/floor-plan-800.png"
       alt="Fictional schematic showing entrance, reception and reading room."
       width="800" height="450" style="max-width: 100%; height: auto"
       loading="eager" fetchpriority="high">
  <figcaption>A supplied teaching schematic, not a real entrance photograph.</figcaption>
</figure>
```

The resource is actually supplied and decodes to 800 by 450 pixels, so the dimensions reserve its ratio. The CSS also constrains the displayed width to the available space while retaining that ratio. This is a single likely important figure in a tiny teaching page. A high priority hint does not prove earlier delivery or an improved performance score; compare measured alternatives before generalizing.

### Common mistake

Claiming that fetchpriority="high" on every image makes the page faster.

### Exercise

What evidence should accompany a claim that an HTML loading change improved performance? Does a reflected fetchPriority value of high prove that an image downloaded first?

### Explained answer

A recorded before/after measurement under stated comparable conditions, with the tested page version and enough detail to reproduce it. Explain variability and avoid generalizing beyond the measured scenario. No. It is a hint under the fetch rules. Record actual comparable measurements, not a property value presented as a performance result.

### Sources

- [HTML Living Standard: fetch priority](https://html.spec.whatwg.org/multipage/urls-and-fetching.html#fetch-priority-attributes)
- [HTML Living Standard: lazy loading](https://html.spec.whatwg.org/multipage/urls-and-fetching.html#lazy-loading-attributes)
- [Resource Timing specification](https://www.w3.org/TR/resource-timing/)
- [Web performance metrics](https://web.dev/articles/vitals)

## Chapter 65: Findable and shareable pages

### Objectives

- Write task-specific titles and links
- Qualify metadata and search-consumer claims
- Keep discovery links and fictional metadata honest

### Prerequisites

- CH-64

### Lesson

Use descriptive titles, meaningful headings and links, useful body content and accurate metadata. A crawler cannot discover a resource through a private thought or a button whose only destination exists in opaque application state.

Canonical URLs should identify the intended canonical document, not point every page to the home page. Alternate-language relationships need correct URLs and language relationships. Structured data should match the visible content and an actual supported vocabulary.

## Keep promises narrow
A meta description can help summarize a page but does not force a search snippet. Structured data does not guarantee a rich result. Social-card previews depend on platform behavior, caching and the accessible resource URLs.

Test the deployed output, not only templates. A robots restriction, a wrong status code, an inaccessible asset or a repository subpath error can undo otherwise tidy head markup. Do not add a measurement claim or an SEO guarantee to sales copy without actual evidence.

## Discovery is not access control
A crawler needs to fetch a page to read its `noindex` instruction. Blocking that fetch in `robots.txt` is not a reliable way to make the crawler process the page's noindex metadata. Neither directive protects private information. Use actual authentication and authorization for private content.

An `llms.txt` file can offer a plain-text route through a publication, but it is not a universal crawler protocol or a promise of inclusion in AI answers. Keep any discovery export consistent with the visible book. Search visibility, snippet choice and model use remain outside the publisher's control.

## Relationships must agree with reachable content
Use real href destinations for crawlable navigation. A canonical is a consumer signal, not a redirect. Language alternatives need the correct language tags, corresponding reachable variants and consumer-specific rules; a tag alone does not translate a page. Redirect/status handling, relative-base resolution and content consistency all need deployed checks.

Consumer-specific social-card and structured-data formats are not automatically HTML normative behavior. Keep image URLs and visible content accurate, and do not invent an author credential, rating or service policy to fill a field.

robots and noindex are discovery/indexing instructions, not secrets protection. A sitemap is a route suggestion, not an indexing guarantee. Optional llms exports should match the actual publication and its rights; they neither grant a new reuse license nor guarantee model retrieval or citation.

### Primary example

```html
<article>
  <h1>Example membership-renewal guide</h1>
  <p>This fictional checklist is for teaching, not a real library policy.</p>
  <a href="#sample-document-list">Read the sample document checklist</a>
  <section id="sample-document-list" aria-labelledby="document-heading">
    <h2 id="document-heading">Sample document checklist</h2>
    <ul>
      <li>A fictional practice membership card.</li>
      <li>A completed practice form containing no real personal details.</li>
    </ul>
  </section>
</article>
```

The descriptive native link reaches actual supplied fictional content. It no longer advertises an absent accepted-document page or a real eligibility policy. Search indexing, rich results and ranking are not established by this snippet.

### Common mistake

Using the same generic summary and title on every page, then adding unsupported ranking claims.

### Exercise

Does a valid canonical link prove that a search engine will choose your preferred URL? Can robots restrictions safely protect an unlisted private page?

### Explained answer

No. It supplies a signal that consumers interpret under their own rules. Keep the signal accurate and consistent with redirects, links and actual content, then inspect the deployed behavior. No. Use real authorization. Discovery instructions and consumer signals must not be represented as an access-control system.

### Sources

- [HTML Living Standard: document metadata](https://html.spec.whatwg.org/multipage/semantics.html#document-metadata)
- [HTML Living Standard: link types](https://html.spec.whatwg.org/multipage/links.html#linkTypes)
- [Google Search Central: block indexing with noindex](https://developers.google.com/search/docs/crawling-indexing/block-indexing)
- [Google Search Central: AI features and your website](https://developers.google.com/search/docs/appearance/ai-features)
- [Google: crawlable links](https://developers.google.com/search/docs/crawling-indexing/links-crawlable)

## Chapter 66: Maintainable HTML

### Objectives

- Keep a useful baseline where feasible
- Review content variation and maintenance responsibilities
- Test the actual no-script and failed-resource baseline

### Prerequisites

- CH-65

### Lesson

Keep the content, relationships and primary task available before adding optional enhancements where the service permits it. Progressive enhancement is a design approach, not a promise that every application can offer identical behavior without scripting.

Use consistent naming, a small number of clear components and maintained sources for repeated structures. Avoid editing separate website and PDF copies of the same explanation. A single-source build reduces drift, but the generated outputs still need independent checks.

## Plan for changed content
Test a long name, a translated label, no results, a server error and more content than the design screenshot contained. A layout that only works with one short English phrase is not ready for real users.

Keep source review dates, compatibility notes and meaningful changelog entries. A Living Standard and browser implementations can change independently. Assign an actual maintainer before promising updates. Do not advertise an automated maintenance process that has not been configured.

## Enhancement must fail honestly
A form aimed at a static filename does not acquire a server query handler merely because its query string looks plausible. Supply a real handler or clearly describe the enhancement as local. The revised example keeps all fictional titles in HTML, disables the unavailable filter initially and enables it only after setup.

Test no scripting, blocked/missing resources and runtime failures separately. noscript only addresses its defined scripting-disabled conditions. Keep the primary route usable where feasible; do not display an action as ready before its handler is available.

## Make the change traceable through every output
Keep one maintained manuscript, rebuild website/PDF/code exports and identify the source/artifact fingerprints for the actual check. A single-source pipeline reduces drift but does not prove that typography, links, accessibility tags and examples survive transformation.

When a resource is hashed or moved, test the compiled request, not just the unbuilt source URL. Store compatibility/review dates alongside a correction and distinguish a new Standard definition from stable implementation support. Backups, repository history and reproducible build instructions are different maintenance assets, not interchangeable claims.

### Primary example

```html
<section aria-labelledby="catalogue-heading">
  <h2 id="catalogue-heading">Supplied fictional titles</h2>
  <form id="local-filter">
    <label for="catalogue-query">Filter supplied titles</label>
    <input id="catalogue-query" name="q" type="search" disabled>
    <button type="submit" disabled>Filter titles</button>
    <button type="reset" disabled>Show all titles</button>
  </form>
  <p id="catalogue-result" role="status">All three teaching titles are listed below.</p>
  <ul id="catalogue-list">
    <li>Local histories</li>
    <li>Poetry</li>
    <li>Fiction</li>
  </ul>
  <p><a href="#catalogue-list">Browse the supplied list</a></p>
</section>
<script src="../assets/catalogue-demo.js" defer></script>
<noscript><p>Filtering needs JavaScript; the supplied list remains readable.</p></noscript>
```

The supplied list is usable without JavaScript. An actual external script adds local filtering and reset; disabled or failed scripting leaves an honest browse-only baseline. This is not a server-side search endpoint. Test the standalone example because the restricted editor blocks external scripts.

### Common mistake

Calling a page progressively enhanced when every visible route silently depends on one script succeeding.

### Exercise

What content states should you test besides the short, successful example shown in a design file? Does a static catalogue.html file implement search just because a form submits q to it?

### Explained answer

Include empty, loading, error, long-content, translated and high-density states as relevant to the task. Test the actual interaction and recovery path, not just their appearance. No. Implement a real endpoint or disclose the local-only behavior. In this example the list remains readable and unavailable enhancement controls remain disabled.

### Sources

- [HTML Living Standard: extensibility and authoring](https://html.spec.whatwg.org/multipage/introduction.html#extensibility)

## Chapter 67: A release checklist that means something

### Objectives

- Keep independent review states
- Tie release claims to specific evidence
- Separate gate evidence, tagged structure and real deployment

### Prerequisites

- CH-66

### Lesson

Check the built documents with a recorded checker version. Test internal links and referenced assets under the real deployment base path. Inspect the browser console and run behavior tests for the examples that make behavior claims.

Review keyboard navigation, focus, names, text alternatives, form errors, reflow and relevant assistive-technology use. Record what was tested and what was not. Security and accessibility reviews need named responsibilities and evidence rather than decorative badges.

## Separate authoring from approval
An answer being written does not mean it has been independently checked. A chapter existing does not mean every assigned feature is fully documented. Keep drafting, example conformance, browser behavior, compatibility and editorial approval as separate states.

For publication, verify the PDF's text, links, navigation and accessibility workflow; do not call an untagged export an accessible PDF. Check downloads in a logged-out browser and test the promised delivery method. The published reading edition keeps its executed checks and open reviews separate. Being available on the web does not mean every whole-Standard coverage gate has closed.

## Record an observation, not a badge
A useful release note identifies the artifact, the date, the tool or browser, the action performed and the observed result. "The homepage loaded" is useful delivery evidence, but it says nothing about an untested registration handler. "Zero automated accessibility violations" describes that scan, not a complete keyboard or screen-reader review. Keep the original limits beside the result so the next reader knows what still needs testing.

For this book, report corrections with the chapter or reference URL, the passage, a reproducible example when relevant and the source that supports the proposed change. Do not include personal form data, private credentials or unpublished security details in a public issue.

## Close the gate the evidence actually covers
For each promised element, attribute, keyword/default, member and algorithm, retain its owner, definition, teaching location, test/review evidence and unresolved conditions. A captured signature or a nearby mention is not completed behavioral coverage. No scope reduction for this publication has been approved.

Use a release matrix that separates manuscript/explained answers, exhaustive coverage, accessibility/security and the accessible tagged PDF. A build pass may update the build row without closing any of those four gates. Record artifact hashes, source commit, tool versions and the actual action/result for each claim.

## A tagged PDF requires semantic structure
Selectable text, bookmarks and a document-language field do not supply a tag tree. Headings, paragraphs, lists, tables, figures, links, code and reading order need appropriate semantic treatment; decorative material and repeating furniture need appropriate artifact handling. Font/Unicode mapping, link associations and language changes also require review.

Check the generated tag tree and logical reading order, then use suitable validation and actual assistive-technology inspection. A four-page prototype does not certify a full book, and machine validation alone does not establish user experience or an independent approval. The full-book tagged edition remains an explicit open gate.

## Verify delivery separately
A successful Git push means the remote commit was updated; read it back. A hosted CI pass means its defined jobs completed, not that Vercel deployed the current site. Check actual production routes, downloads, headers and rollback/recovery conditions before claiming delivery of a new edition. Keep private credentials out of source, logs and public issue reports.

### Primary example

```html
<section aria-labelledby="release-heading">
  <h2 id="release-heading">Before publishing</h2>
  <ul>
    <li>Validate the built documents and record the output.</li>
    <li>Test the main tasks with a keyboard.</li>
    <li>Check paths under the deployment subdirectory.</li>
    <li>Record remaining content and technical review work.</li>
  </ul>
</section>
```

This is a visible checklist, not an assertion that its tasks passed. A project should link each claimed result to the relevant command output, environment or review note.

### Common mistake

Renaming a draft final and carrying its unchecked review states into the release unchanged.

### Exercise

What should you do if examples validate but the API-member inventory is incomplete? Do selectable PDF text and bookmarks establish an accessible tag tree?

### Explained answer

Report the example result separately, keep API coverage open, and limit the publication promise or complete the missing inventory before making the broader claim. One passing check cannot close unrelated work. No. Semantic tags, associations, reading order and accessibility review are separate work. Build, repository delivery, hosted CI and production deployment must also be evidenced separately.

### Sources

- [HTML Living Standard: conformance](https://html.spec.whatwg.org/multipage/introduction.html#conformance-requirements-for-authors)
- [WAI PDF technique: reading and tab order](https://www.w3.org/WAI/WCAG22/Techniques/pdf/PDF3)


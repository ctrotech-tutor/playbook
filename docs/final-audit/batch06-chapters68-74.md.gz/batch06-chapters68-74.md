# 68. Build a personal profile

Build a truthful volunteer profile whose headings and contact-status link work without scripts.

Prerequisites: CH-07, CH-14, CH-17, CH-18, CH-23, CH-25

## Objectives

- Organise a fictional person's introduction and experience into a useful heading structure.
- Make a descriptive contact-status link resolve to real content.
- Distinguish a complete static profile from a working contact service.

## Before you start

Review Chapters 7, 14, 17, 18, 23, 25. Create a document shell, choose headings, make a list and connect a same-page link.

## Working terms

A fragment is the part of a URL after # that can identify a document destination. A landmark identifies a major page region through native HTML or an appropriate role. Contact status explains whether a contact route actually exists; it is not itself a messaging service.

## Build contract
Create a one-page profile for Ada, a fictional library volunteer. Include one page-level title, a short introduction, three relevant practice activities and a contact-status section. Make the fictional context visible rather than relying on a README. Do not invent a real address, availability claim or endorsement. The reference has no portrait because no visual information is needed to complete this task.

## Implementation route
Begin with the content, then choose the structure. Put the whole page topic in the main heading. Experience and contact status are separate sections with second-level headings. Use a list for the three activities, not a table or a row of decorative cards. A link to `#contact` takes the reader to the status section. It is navigation, so it remains an anchor even if styled prominently.

## Acceptance and recovery
Open the file without JavaScript. Read it in document order, activate the contact-status link with Enter and confirm that the destination explains the absence of a contact service. Try a 320 CSS-pixel viewport and enlarge text. The profile should remain readable without page-wide horizontal scrolling. No-script operation is a property of this static design, not a claim that the reader has tested it.

## Reference walkthrough
The download adds a language declaration, title, viewport metadata, a keyboard skip link and a local stylesheet around the subject content. Its activity statements are explicitly practice tasks. The contact section gives no coordinator instruction that might be mistaken for a real service. Replacing that status with a real route is a separate publishing decision requiring verified details and the person's agreement.

## Assessment rubric: 28 observable points
Award one point for each demonstrated check below, four per area. Record the evidence next to the check; untested checks receive no point. These points are an authoring assessment aid, not WCAG conformance or security certification. A broken primary task, a misleading service claim, unsafe data collection or a dead required destination blocks readiness regardless of the score.

### Content and truth (4 points)
- Fictional context is visible.
- Ada is named.
- Introduction identifies the practice role.
- No unverifiable service claim appears.

### Structure (4 points)
- One main landmark is present.
- The page topic has an h1.
- Experience has an h2.
- Contact status has an h2.

### Experience (4 points)
- Three activities are supplied.
- Activities form a native list.
- Each activity is specific.
- No table is used for layout.

### Contact navigation (4 points)
- The link says what it opens.
- Its fragment matches a unique ID.
- Keyboard activation reaches the section.
- The section states no contact route is supplied.

### Baseline (4 points)
- No script is needed to read.
- No script is needed to navigate.
- Stylesheet failure leaves logical content.
- No fabricated form is present.

### Presentation (4 points)
- Text remains readable at 320 CSS pixels.
- The page has no horizontal overflow.
- Keyboard focus is visible.
- Text enlargement does not hide the contact section.

### Delivery (4 points)
- The HTML has a useful document title.
- The language is declared.
- All local links resolve.
- The README explains how to open the page.

## Example

```html
<main>
  <h1>Ada, a fictional library volunteer</h1>
  <p>A made-up profile for practising HTML, not a real volunteer service.</p>
  <p>In this exercise, Ada helps readers explore a small collection.</p>
  <a href="#contact">Read the contact status</a>
  <section>
    <h2>Practice experience</h2>
    <ul><li>Preparing a fictional reading-group notice.</li>
      <li>Organising a sample shelf list.</li>
      <li>Writing a catalogue entry as a learning task.</li></ul>
  </section>
  <section id="contact"><h2>Contact status</h2>
    <p>No personal contact details or messaging service are supplied.</p>
  </section>
</main>
```

The fragment teaches the profile content, not a complete document shell. The downloadable index.html supplies that shell and keeps the contact destination on the same page. A section heading identifies the contact topic; a link is appropriate because activation navigates rather than submitting data. The list expresses a collection of activities. Fictional status is part of the interface, not hidden assessment metadata.

## Common mistake

A prominent Contact button with no destination promises an action the page cannot provide. Use a descriptive link to the actual contact-status section, and state the absence of a service.

## Exercise

A learner replaces the contact-status anchor with a button that does nothing and removes the fictional notice. Which checks fail, and what is the smallest truthful repair?

## Explained answer

The contact-navigation checks fail because the button has neither a destination nor an implemented action. Content truth also fails: a reader can mistake the volunteer and contact route for real offerings. Restore an anchor whose href is #contact, retain a unique contact section that states no route is supplied, and restore the visible fictional notice. Test Enter activation and the narrow page again. Styling alone cannot repair the broken task.

## Sources

- HTML Living Standard: heading elements: https://html.spec.whatwg.org/multipage/sections.html#the-h1,-h2,-h3,-h4,-h5,-and-h6-elements
- HTML Living Standard: links: https://html.spec.whatwg.org/multipage/links.html#links
- WCAG 2.2 Understanding: Reflow: https://www.w3.org/WAI/WCAG22/Understanding/reflow.html
- WCAG 2.2 Understanding: Focus Order: https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html

# 69. Build a portfolio

Build a three-page learning portfolio with two distinct project notes and honest contact status.

Prerequisites: CH-17, CH-24, CH-25, CH-27, CH-61

## Objectives

- Connect two project summaries to separate working detail pages.
- Keep primary navigation and current-page information consistent.
- Describe static learning work without inventing clients, outcomes or a contact backend.

## Before you start

Review Chapters 17, 24, 25, 27, 61. Resolve sibling-relative links, structure independent project notes and plan navigation across files.

## Working terms

A project summary introduces one item of work; a detail page supplies its substantive explanation. A current-page marker describes the document currently being viewed. A relative URL is resolved against a base URL, so moving files can change its destination.

## Build contract
Deliver `index.html`, `project.html` and `reading-list.html`. The index introduces a fictional front-end learner's work, summarises two different studies and links each to its own detail page. The notice-board note explains a document-structure study; the reading-list note explains why its collection is a list. Include a contact-status section on the index. No contact form or real personal information is required.

## Implementation route
Write the two summaries before the navigation. Use articles for independently understandable project summaries, with third-level headings under Selected work. Give each link a destination-specific name. Reuse a primary navigation landmark across the three documents and mark only the current document's link with `aria-current="page"`. This attribute supplies current-page information; visible styling and actual destinations still matter.

## Acceptance and recovery
Open each detail page directly, not only through the index. Confirm that its title identifies its own subject and that its primary links still work. Return to `index.html#contact` from each detail. Remove scripting and check again. A browser reload, an extracted ZIP and a narrow viewport must not turn either project into an empty placeholder.

## Reference walkthrough
The supplied files have real relative links, consistent local CSS and no client or revenue claims. Each detail page includes actual sample content and a short design decision. The contact section states that the site does not collect messages. This meets the fictional exercise contract. A real professional portfolio would require the owner's own work, permission to show it, evidence for outcomes and an appropriate verified contact route.

## Assessment rubric: 28 observable points
Award one point for each demonstrated check below, four per area. Record the evidence next to the check; untested checks receive no point. These points are an authoring assessment aid, not WCAG conformance or security certification. A broken primary task, a misleading service claim, unsafe data collection or a dead required destination blocks readiness regardless of the score.

### Portfolio content (4 points)
- The fictional status is visible.
- An introduction is supplied.
- Two distinct studies are summarised.
- No unsupported client or outcome claim appears.

### Detail destinations (4 points)
- The notice-board link opens project.html.
- The reading-list link opens reading-list.html.
- Both detail documents contain substantive content.
- The two links do not lead to the same empty page.

### Structure (4 points)
- Selected work has a heading.
- Each project summary has a subordinate heading.
- Each page has a main landmark.
- Document titles distinguish the three pages.

### Navigation (4 points)
- All three pages expose primary navigation.
- All primary destinations resolve.
- Exactly one link per primary navigation is current.
- Both detail pages can reach the contact status.

### Contact truth (4 points)
- Contact status is present on the index.
- Its ID is unique.
- No fake message submission is offered.
- No real personal details are invented.

### Recovery (4 points)
- Each detail opens directly.
- Links work without JavaScript.
- Links work after ZIP extraction.
- 320-pixel reading does not cause page-wide overflow.

### Delivery (4 points)
- Each page declares its language.
- Focus styling is visible.
- All stylesheet references are local and resolve.
- Assessment notes identify static limitations.

## Example

```html
<section aria-labelledby="work-title">
  <h2 id="work-title">Selected work</h2>
  <article><h3>Library notice board</h3>
    <p>A static notice-page structure study.</p>
    <a href="../projects/portfolio/project.html">Read the notice-board note</a>
  </article>
  <article><h3>Reading list</h3>
    <p>A semantic list study, not a reservation service.</p>
    <a href="../projects/portfolio/reading-list.html">Read the reading-list note</a>
  </article>
</section>
```

These are two separate studies with separate destinations. The chapter fragment uses paths from the wrapped examples directory to the supplied reference documents. Inside the extracted project folder, the index uses sibling-relative URLs instead. The reference primary navigation marks only the active document with aria-current="page". A current-page marker cannot fix a wrong href. Both detail pages include a return route to the index contact status, which is deliberately not a message service.

## Common mistake

Repeating one project description behind two different link labels makes the portfolio look more complete than it is. Build both detail pages and inspect each directly.

## Exercise

Both project links currently open project.html, while reading-list.html contains only a title. Is the three-file count enough? Explain the repair and how to verify it.

## Explained answer

No. A file count proves neither distinct work nor usable navigation. Write the reading-list sample and its list-design explanation, point the corresponding summary to reading-list.html, and keep the notice-board summary pointing to project.html. Open each detail directly, compare the content, inspect the document title and current-page link, then follow its contact-status return link. Repeat from the extracted ZIP with JavaScript disabled.

## Sources

- HTML Living Standard: the article element: https://html.spec.whatwg.org/multipage/sections.html#the-article-element
- HTML Living Standard: the nav element: https://html.spec.whatwg.org/multipage/sections.html#the-nav-element
- HTML Living Standard: links: https://html.spec.whatwg.org/multipage/links.html#links
- WCAG 2.2 Understanding: Focus Order: https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html

# 70. Build a registration form

Build an explicitly local form demonstration with linked errors, reset recovery and disabled no-script controls.

Prerequisites: CH-34, CH-35, CH-36, CH-38, CH-40, CH-41, CH-53, CH-66

## Objectives

- Associate required labels, instructions and field errors with three practice controls.
- Keep a no-script or failed-script form disabled instead of falling back to GET collection.
- Test linked error correction, reset and honest local-success messaging.

## Before you start

Review Chapters 34, 35, 36, 38, 40, 41, 53, 66. Build labelled controls, inspect browser validity, distinguish form submission from local script and preserve a safe failure baseline.

## Working terms

Constraint validation checks applicable browser-side rules, not server trust. An error summary collects correction links above a form. Custom validity is a script-supplied message that makes a control invalid while the message is nonempty. A disabled baseline keeps this practice task unavailable until its local handlers are installed.

## Build contract
Collect only fictional practice values for name, one email and a session choice. This is a browser-side interface study, not a registration service. The baseline fieldset is disabled. No control has a submission name and there is no application endpoint. Tell readers not to enter personal information. The local script must install its handlers before enabling fields, cancel submit, validate the fields and display only a local result.

## Implementation route
Use explicit labels and visible required indicators. Leave native `required` and `type="email"` constraints on the controls. After setup, `form.noValidate = true` selects the custom-summary submit path; it does not remove ValidityState or make the values trusted. The script inspects each control's validity and adds a non-whitespace rule for the practice name with `setCustomValidity()`. The browser email syntax check cannot prove that an address exists or belongs to the user.

Place a summary before the form with links to invalid fields. Reveal inline error text, set `aria-invalid="true"` only on failed fields and focus the summary after an unsuccessful submit. Use stable description IDs for the field messages and email hint. When the learner edits a failed field, revalidate it and remove that error when corrected. Clear any previous success message as soon as input changes. The script builds message nodes using text content, not HTML interpolation.

## Acceptance and recovery
Submit all fields empty, then a whitespace-only name and malformed email, then a valid practice set. Follow every summary link with the keyboard. Confirm that no form navigation or application request occurs and the URL does not acquire query values. Reset after an error and after success; values, errors, invalid states and custom name validity must return to their initial state. With JavaScript disabled or `demo.js` blocked, the form remains disabled and its explanation stays readable. This is failure containment for this static reference, not a claim of universal browser privacy.

## Reference walkthrough
The chapter's marked form content is reused in both the registration and capstone downloads. One maintained local script supplies both copies. The form has no named application controls, but that omission is not the primary no-submit mechanism: the disabled baseline and installed submit handler are essential. `autocomplete="off"` is only a browser hint and cannot guarantee that a browser stores nothing. The demonstration does not write application data to cookies or Web Storage. A real service needs a real endpoint, server validation, an appropriate transport and request-security design, data minimisation and a truthful retention notice; enabling this static form is not that implementation.

## Assessment rubric: 28 observable points
Award one point for each demonstrated check below, four per area. Record the evidence next to the check; untested checks receive no point. These points are an authoring assessment aid, not WCAG conformance or security certification. A broken primary task, a misleading service claim, unsafe data collection or a dead required destination blocks readiness regardless of the score.

### Control contract (4 points)
- The page visibly says practice only.
- Exactly name/email/session data are requested.
- All controls have explicit labels.
- Required state is visible and programmatic.

### Disabled baseline (4 points)
- The initial fieldset is disabled.
- No application endpoint is claimed.
- Blocked scripting leaves the fields disabled.
- Instructions remain readable without scripts.

### Validation (4 points)
- Empty values produce three errors.
- Whitespace-only name is rejected.
- Malformed single-email syntax is rejected.
- A valid practice set produces only local success.

### Error navigation (4 points)
- The summary precedes the form.
- The failed-submit summary receives focus.
- Each error link focuses its field.
- Each invalid field has an associated visible message.

### Correction (4 points)
- Invalid fields expose aria-invalid.
- Correcting a failed field removes its error.
- Editing removes an earlier success message.
- Hidden summary content is not left visibly stale.

### Reset (4 points)
- Name/email/session values reset.
- Custom name validity resets.
- Inline and summary errors clear.
- Invalid attributes and earlier success clear.

### Boundary evidence (4 points)
- Submit does not change the URL.
- No application request is emitted.
- The script writes no application storage.
- Real-service requirements are clearly distinguished.

## Example

```html
<link rel="stylesheet" href="../assets/project-reference.css">
<main><h1>Reading-group form study</h1>
<!-- registration:start -->
<p class="note" id="demo-note">Practice only. Use made-up details such as reader@example.invalid. This page checks fields locally; no application is sent or saved by its script. Browser autofill and history are separate browser features. JavaScript must load successfully to enable the fields. This is not a registration service.</p>
<section id="demo-errors" class="errors" aria-labelledby="demo-errors-title" tabindex="-1" hidden>
  <h2 id="demo-errors-title">Correct these fields</h2>
  <ul id="demo-error-list"></ul>
</section>
<form id="demo-form" aria-describedby="demo-note" autocomplete="off">
  <fieldset id="demo-fields" disabled>
    <legend>Fictional practice details</legend>
    <label for="demo-name">Practice name (required)</label>
    <input id="demo-name" required aria-describedby="demo-name-error">
    <p id="demo-name-error" class="field-error" hidden></p>
    <label for="demo-email">Practice email (required)</label>
    <input id="demo-email" type="email" required aria-describedby="demo-email-help demo-email-error">
    <p id="demo-email-help">Use one made-up address, for example reader@example.invalid.</p>
    <p id="demo-email-error" class="field-error" hidden></p>
    <label for="demo-session">Practice session (required)</label>
    <select id="demo-session" required aria-describedby="demo-session-error">
      <option value="">Choose a practice session</option>
      <option value="morning">Morning study</option>
      <option value="afternoon">Afternoon study</option>
    </select>
    <p id="demo-session-error" class="field-error" hidden></p>
    <button type="submit">Check this demonstration</button>
    <button type="reset">Reset example fields</button>
  </fieldset>
</form>
<p id="demo-result" role="status"></p>
<!-- registration:end -->
</main>
<script src="../assets/project-registration.js" defer></script>
```

The download and wrapped chapter example load the same maintained local behaviour. Disabled fieldset descendants cannot be used for the application task before successful setup. Once handlers are installed, the script enables them and suppresses form navigation with preventDefault(). The summary supplies a focused overview and links that explicitly focus each failed control. A polite status reports only that the browser checks passed. No confirmation of membership, delivery or server acceptance is justified. See assets/project-registration.js in the site source, or demo.js in the ZIP, for the complete validation and reset implementation.

## Common mistake

A form with method="get" and an action ending in #note is not a harmless no-backend fallback. Named successful controls can still enter a URL query. A success message must not imply that local validity created an application.

## Exercise

Why must this static reference not use a GET-to-fragment fallback? Describe the failed-script behaviour, then explain what reset must clear after a whitespace-name error.

## Explained answer

A fragment names a destination within a resource; it does not cancel form submission. A GET form with named controls can place values in the URL and navigate even without an application backend. This reference therefore starts with disabled fields and enables them only after the local submit/error/reset handlers are installed. If the script is blocked, the instructions remain and the fields stay disabled. Reset clears the controls, the summary list, inline messages, aria-invalid attributes and the custom validity message on the name. The result reports reset, not application acceptance. Test reset again after a valid local check, since stale success text can otherwise survive.

## Sources

- HTML Living Standard: the form element: https://html.spec.whatwg.org/multipage/forms.html#the-form-element
- HTML Living Standard: constraint validation: https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#constraint-validation
- HTML Living Standard: the fieldset element: https://html.spec.whatwg.org/multipage/form-elements.html#the-fieldset-element
- WAI Forms Tutorial: user notifications: https://www.w3.org/WAI/tutorials/forms/notifications/
- WCAG 2.2 Understanding: Focus Order: https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html

# 71. Build an article page

Publish a complete fictional lending article with three destinations, a defined policy and a machine-readable review date.

Prerequisites: CH-14, CH-17, CH-20, CH-24, CH-25

## Objectives

- Write consistent borrowing, renewal and return explanations rather than policy placeholders.
- Connect an on-page contents list to three unique section IDs.
- Encode a displayed review date using the time element.

## Before you start

Review Chapters 14, 17, 20, 24, 25. Organise a self-contained article, make fragment links and encode a date that matches its displayed text.

## Working terms

A policy model is the explicit fictional rule set used for this exercise. A review date identifies the stated editorial check date, not the date of every loan. Calendar-day arithmetic here follows the convention stated in the article; it does not infer a real organisation's counting rules.

## Build contract
Write an article titled How lending works with an introduction, an on-page contents navigation, Borrowing, Renewal and Returns sections, and a review date. Label the policy fictional on the page. Give enough information to evaluate the model without contacting a nonexistent desk. This exercise supplies a 14-calendar-day loan, one eligible 14-calendar-day renewal before the due date, and a paper-log practice return. The page itself processes none of these actions.

## Implementation route
Use an article because the guide is a self-contained subject, and give each substantive section its own heading and stable ID. The contents landmark needs a name distinct from any site-wide primary navigation. Describe the loan date arithmetic explicitly: a loan starting 1 October 2026 is due 15 October; one eligible renewal extends that due date to 29 October. Define this convention in prose instead of asking the reader to infer inclusivity from a bare number. Mark the review date with `time datetime="2026-10-15"` while displaying 15 October 2026.

## Acceptance and recovery
Activate all three contents links, inspect their fragments and verify each destination exists once. Read just the headings and confirm the policy sequence makes sense. Check the date attribute against the displayed review date. Disable scripts and repeat navigation. At narrow widths, the contents links must wrap without covering the article. A valid `time` value does not verify that an editor actually reviewed a policy; review provenance remains editorial evidence.

## Reference walkthrough
The supplied article contains the entire practice policy rather than an instruction to ask someone for it. It distinguishes a possible model extension from an actual renewal operation. Returns are represented as a local paper exercise, not a real address or live record. The article footer belongs to that article's review information; the outer project footer carries publication credit. Adaptation to a real library requires replacing both the fictional policy and the unverified service context.

## Assessment rubric: 28 observable points
Award one point for each demonstrated check below, four per area. Record the evidence next to the check; untested checks receive no point. These points are an authoring assessment aid, not WCAG conformance or security certification. A broken primary task, a misleading service claim, unsafe data collection or a dead required destination blocks readiness regardless of the score.

### Article contract (4 points)
- The article has the required title.
- Fictional policy status is visible.
- An introduction identifies the model.
- No real service is implied.

### Contents navigation (4 points)
- The nav has a descriptive accessible name.
- Borrowing links to its section.
- Renewal links to its section.
- Returns links to its section.

### Borrowing (4 points)
- The 14-calendar-day rule is stated.
- A start date example is supplied.
- Its due date is 15 October 2026.
- The model date convention is understandable.

### Renewal (4 points)
- Only one renewal is allowed in the model.
- Eligibility and before-due-date scope are stated.
- The extension is 14 calendar days.
- The sample extended due date is 29 October.

### Returns (4 points)
- A return procedure is actually described.
- The procedure is identified as practice.
- No real branch address is invented.
- No live return recording is claimed.

### Review and structure (4 points)
- Review text displays 15 October 2026.
- datetime contains 2026-10-15.
- All three section IDs are unique.
- The article headings form a coherent hierarchy.

### Resilience (4 points)
- Contents links work without scripts.
- All fragments resolve.
- The page reads at 320 CSS pixels.
- README and solution distinguish static policy from service.

## Example

```html
<article>
  <h1>How lending works</h1>
  <p>Fictional practice policy, not a real lending service.</p>
  <nav aria-label="On this page"><a href="#borrowing">Borrowing</a>
    <a href="#renewal">Renewal</a> <a href="#returns">Returns</a></nav>
  <section id="borrowing"><h2>Borrowing</h2>
    <p>A practice loan lasts 14 calendar days after its start date:
      1 October 2026 gives a 15 October 2026 due date.</p></section>
  <section id="renewal"><h2>Renewal</h2>
    <p>One eligible renewal before the due date adds 14 calendar days
      to that date: 15 October becomes 29 October.</p></section>
  <section id="returns"><h2>Returns</h2>
    <p>Mark the practice return in a local paper log.
      This page records no real return.</p></section>
  <footer>Reviewed <time datetime="2026-10-15">15 October 2026</time>.</footer>
</article>
```

All contents links lead to real, distinct sections. The sample borrowing and renewal dates follow the explicitly supplied calendar-day convention; they are not claims about a real library policy. The time element encodes the same date that readers see. The reference supplies a complete explanation of the practice return, while making clear that HTML content does not update a lending system. Section headings, navigation and an article footer express different relationships rather than acting as interchangeable layout containers.

## Common mistake

A policy heading followed by “ask at the desk” does not meet a brief requiring the policy itself. A review date without a matching valid datetime also loses machine-readable precision.

## Exercise

An article says loans last 14 days after 1 October and gives a 14 October due date. Its displayed review date is 15 October but datetime is 2026-10-14. What should change?

## Explained answer

Use the stated model convention consistently: 14 calendar days after 1 October 2026 is 15 October, and the eligible 14-day extension is 29 October. If a real policy uses another counting convention, explain and apply that convention instead of silently changing the arithmetic. Match the reviewed date attribute to the displayed date as 2026-10-15. Verify all three section destinations after editing; date syntax and working links still do not prove that a real library approved the policy.

## Sources

- HTML Living Standard: the article element: https://html.spec.whatwg.org/multipage/sections.html#the-article-element
- HTML Living Standard: the nav element: https://html.spec.whatwg.org/multipage/sections.html#the-nav-element
- HTML Living Standard: the time element: https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-time-element
- HTML Living Standard: links: https://html.spec.whatwg.org/multipage/links.html#links

# 72. Build a data dashboard

Make a static dashboard whose loan total, units, period and accessible table agree.

Prerequisites: CH-26, CH-61, CH-62

## Objectives

- Reconcile a displayed total with all three fictional collection counts.
- Provide a caption and explicit row and column headers for a simple data table.
- Keep wide data readable in a labelled keyboard-focusable scroll region.

## Before you start

Review Chapters 26, 61, 62. Create a captioned simple table, distinguish headers from data and test a keyboard-accessible scrolling region.

## Working terms

A measure is the quantity counted, here loan entries. A unit tells readers how to interpret a value. Reconciliation checks that summary and rows describe the same dataset and arithmetic. A table header association connects a data cell with its relevant row or column heading.

## Build contract
Build a static October 2026 dashboard for three fictional loan counts: Fiction 42, Local history 18 and Reference 9. Display their total, 69 loans, and the count of represented collections, three. Label the values as fictional loan entries, not unique people, stock levels or live availability. There is no comparison period, so do not invent a growth arrow or percentage.

## Implementation route
Use a description list for the named summary values and a table for the cross-row data relationships. Give the table a caption that identifies the subject and period. Mark column headers with `scope="col"` and each collection's row header with `scope="row"`. Include a period column so that a copied row retains useful context. Scope is suitable for this simple grid; complex multi-level tables need an explicit association review rather than a mechanical copy of this example.

## Acceptance and recovery
Recalculate the total from the rows, then compare every displayed summary against the table. At 320 CSS pixels, the document itself should fit the viewport. The wide table may scroll inside its labelled region; preserve the two-dimensional relationships instead of hiding columns. Tab to that region, check its visible focus and inspect horizontal scroll. Reflow permits exceptions for content that requires two-dimensional layout, but the exception does not excuse page-wide overflow or an inaccessible scrolling surface.

## Reference walkthrough
The supplied dashboard is all static HTML. It exposes the period, units and fiction notice without hover, script or colour interpretation. Its summary cannot remain correct if someone changes a row without updating the total, so reconciliation is an explicit acceptance check. The scroll wrapper is focusable and named. Native markup provides associations for this simple table; confirming its actual presentation in a screen reader still requires an assistive-technology review.

## Assessment rubric: 28 observable points
Award one point for each demonstrated check below, four per area. Record the evidence next to the check; untested checks receive no point. These points are an authoring assessment aid, not WCAG conformance or security certification. A broken primary task, a misleading service claim, unsafe data collection or a dead required destination blocks readiness regardless of the score.

### Data truth (4 points)
- Fictional status is visible.
- The period is October 2026.
- Units mean loan entries.
- No live feed or unsupported comparison is claimed.

### Rows (4 points)
- Fiction is 42.
- Local history is 18.
- Reference is 9.
- All three rows carry the period.

### Summary (4 points)
- Total is visibly 69 loans.
- The total equals 42 + 18 + 9.
- Three collections are reported.
- Summary labels explain their quantities.

### Table structure (4 points)
- A subject-and-period caption is present.
- A thead groups column headings.
- Each column heading has scope=col.
- Each collection heading has scope=row.

### Narrow layout (4 points)
- The 320-pixel document fits its viewport.
- The table is inside a bounded scroll region.
- No data column is hidden.
- The scroll region has an accessible name.

### Keyboard and baseline (4 points)
- The table region can receive keyboard focus.
- Focus is visible.
- Data remain readable without scripts.
- Reading order retains caption/headings/rows.

### Delivery (4 points)
- Local CSS resolves.
- Document title identifies the dashboard.
- No unexplained chart substitutes for data.
- Solution notes require recalculation after edits.

## Example

```html
<p>Fictional October 2026 loan entries, not a live feed.</p>
<dl><dt>Total across these collections</dt><dd>69 loans</dd></dl>
<table>
  <caption>Fictional loans by collection, October 2026</caption>
  <thead><tr><th scope="col">Collection</th><th scope="col">Loans (count)</th>
    <th scope="col">Period</th></tr></thead>
  <tbody><tr><th scope="row">Fiction</th><td>42</td><td>October 2026</td></tr>
    <tr><th scope="row">Local history</th><td>18</td><td>October 2026</td></tr>
    <tr><th scope="row">Reference</th><td>9</td><td>October 2026</td></tr></tbody>
</table>
```

The total and rows now describe the same three collections: 42 + 18 + 9 = 69. No reader count or percentage can be inferred from those values. The caption supplies table context, while scoped headers express the simple row/column relationships. The fragment focuses on the data model; the complete reference adds the named scroll wrapper, focus styling and second summary value. A passing conformance checker does not establish that those associations were understood through a particular assistive technology.

## Common mistake

A summary showing 128 active readers above a table of 69 loan entries mixes incompatible quantities and has no supporting data. Reconcile the measure as well as the arithmetic.

## Exercise

Someone changes Reference from 9 to 12 but leaves 69 loans in the summary and adds “69 readers.” What needs correction and why?

## Explained answer

The revised loan total is 42 + 18 + 12 = 72. Update the summary and any explanatory arithmetic to 72 loans. Do not relabel it readers: one reader may have multiple loan entries and there is no distinct-person dataset. Keep the period and collection count explicit, then recheck all rows, scope attributes and the narrow scroll region. A matching number alone would not repair the unit error.

## Sources

- HTML Living Standard: table header cells: https://html.spec.whatwg.org/multipage/tables.html#the-th-element
- WAI Tables Tutorial: two headers: https://www.w3.org/WAI/tutorials/tables/two-headers/
- WCAG 2.2 Understanding: Reflow: https://www.w3.org/WAI/WCAG22/Understanding/reflow.html
- WCAG 2.2 Understanding: Focus Order: https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html

# 73. Build a media gallery

Present three original local SVG drawings with accurate alternatives, matching dimensions and honest loading choices.

Prerequisites: CH-19, CH-28, CH-29, CH-33

## Objectives

- Describe the supplied drawings accurately rather than inventing photographic detail.
- Pair each image with a caption that contributes context instead of duplicating its alternative.
- Keep local image assets usable offline and reserve a matching aspect ratio.

## Before you start

Review Chapters 19, 28, 29, 33. Choose alternatives from an image's purpose, pair figures with captions and compare an asset's dimensions with its display.

## Working terms

A text alternative supplies image-equivalent meaning for its context. A caption adds related visible context. An intrinsic aspect ratio comes from the resource geometry; the supplied drawings are 640 by 400. Lazy loading is a browser loading hint, not a promise about a request time.

## Build contract
Deliver three self-contained drawings named `shelves.svg`, `window.svg` and `tables.svg`. State that these are illustrations, not photographs of a real library. Use a list of figures with an image and caption in each. The reference drawings are made from simple geometric shapes and need no external font, network image or attribution to an unknown photographer. Retain the publication credit and rights notice when using the supplied package; do not assume the whole book has an open licence.

## Implementation route
The shelves drawing has three rows of six book shapes. The window has six panes. The tables drawing shows two tables from above, each with a book shape. Write alternatives from those visible facts. Captions provide the learning context, such as organising a collection, rather than repeating the full alternative. These images carry information in this exercise, so an empty alternative would remove part of the intended content. A genuinely decorative image in another context could require a different decision.

## Acceptance and recovery
Set both HTML dimensions and SVG viewBox to the same 640 by 400 ratio, then constrain display size with CSS without distorting the image. The first image uses eager loading; later images use lazy loading as a hint. This is an authoring choice, not a timing guarantee or a measured performance improvement. Check actual rendering after scrolling the lazy images into view. Extract the ZIP and confirm all three local files load without network access. Block image loading once and confirm the text alternatives and captions still preserve meaningful information.

## Reference walkthrough
The generated SVGs contain their own drawing instructions and no remote URLs or scripts. The img elements supply alternatives in the embedding HTML. Width and height reserve the intended ratio even when display width changes. There is no lightbox or synthetic button because viewing these figures requires neither a custom interaction nor a modal. The layout uses a responsive list grid and keeps source order intact when it collapses to one column.

## Assessment rubric: 28 observable points
Award one point for each demonstrated check below, four per area. Record the evidence next to the check; untested checks receive no point. These points are an authoring assessment aid, not WCAG conformance or security certification. A broken primary task, a misleading service claim, unsafe data collection or a dead required destination blocks readiness regardless of the score.

### Asset delivery (4 points)
- All three SVG files are supplied.
- SVGs contain no remote resources.
- The page says they are drawings.
- No real venue photography is claimed.

### Accurate alternatives (4 points)
- The shelves alternative describes three rows.
- The shelves alternative matches six shapes per row.
- The window alternative matches six panes.
- The tables alternative matches two tables with book shapes.

### Figure relationships (4 points)
- The gallery is a native list.
- Each list item contains a figure.
- Each image has its caption in that figure.
- Captions add context instead of duplicating alternatives.

### Geometry (4 points)
- HTML width is 640 for every image.
- HTML height is 400 for every image.
- Each SVG viewBox is 0 0 640 400.
- Narrow rendering preserves the ratio.

### Loading (4 points)
- The first image is not lazy.
- Later images carry the lazy hint.
- All images render after scrolling into view.
- No measured speed claim is invented.

### Fallback (4 points)
- Local files load after ZIP extraction.
- Images require no network resource.
- Blocked images leave meaningful alternatives.
- Captions remain readable with images blocked.

### Presentation and rights (4 points)
- The 320-pixel page has no horizontal overflow.
- The list reading order is meaningful.
- No unnecessary lightbox control is offered.
- Publication credit and rights limits are retained.

## Example

```html
<ul>
  <li><figure>
    <img src="../projects/gallery/shelves.svg"
      alt="Three shelf rows, each holding six book shapes"
      width="640" height="400" style="max-width:100%;height:auto" loading="eager" decoding="async">
    <figcaption>Organising a small collection.</figcaption>
  </figure></li>
  <li><figure>
    <img src="../projects/gallery/window.svg"
      alt="A rectangular window divided into six panes"
      width="640" height="400" style="max-width:100%;height:auto" loading="lazy" decoding="async">
    <figcaption>Light in a reading space.</figcaption>
  </figure></li>
  <li><figure>
    <img src="../projects/gallery/tables.svg"
      alt="Two reading tables seen from above, each with a book shape"
      width="640" height="400" style="max-width:100%;height:auto" loading="lazy" decoding="async">
    <figcaption>A study in shared space.</figcaption>
  </figure></li>
</ul>
```

The three alternatives match the actual geometric drawings and do not describe people, colours or photographic settings that the files do not show. Captions explain why each subject appears in the gallery. The wrapped chapter example links to the supplied project image files; the extracted gallery uses sibling-relative paths. HTML width/height and SVG viewBox all share a 1.6:1 ratio. Local assets and explicit dimensions make the reference self-contained, but loading="lazy" remains a browser hint rather than proof of faster loading.

## Common mistake

Describing a generated drawing as a photograph, or using an alternative with more objects than the asset contains, makes the text fallback inaccurate. Inspect the delivered image, not a remembered prompt.

## Exercise

The window SVG has six panes, but its alternative says four and its HTML height is changed to 640 while width stays 640. What should be repaired?

## Explained answer

Restore an accurate six-pane alternative. Keep the supplied 640 by 400 width/height pair so its reserved ratio matches the 0 0 640 400 SVG viewBox; CSS may scale the display while height remains automatic. Check the actual loaded image and the blocked-image state, then verify all three files from the extracted ZIP. Neither a plausible alternative nor successful image loading proves the other requirement.

## Sources

- HTML Living Standard: the img element: https://html.spec.whatwg.org/multipage/embedded-content.html#the-img-element
- WAI Images Tutorial: informative images: https://www.w3.org/WAI/tutorials/images/informative/
- WCAG 2.2 Understanding: Reflow: https://www.w3.org/WAI/WCAG22/Understanding/reflow.html

# 74. Capstone: the library site

Integrate four honest library pages, then verify navigation, local form recovery, data and offline delivery as one system.

Prerequisites: CH-27, CH-61, CH-62, CH-66, CH-68, CH-69, CH-70, CH-71, CH-72, CH-73

## Objectives

- Integrate Home, Catalogue, Membership and Visit with consistent navigation and truthful service boundaries.
- Reuse and retest the disabled-baseline local form instead of implying a real membership backend.
- Assess the whole extracted site against observable functional, accessibility and privacy checks.

## Before you start

Review Chapters 27, 61, 62, 66, 68, 69, 70, 71, 72, 73. Complete the six smaller projects, plan file routes and test both successful enhancement and failed-script recovery.

## Working terms

Integration testing checks connected components as one task flow. A service boundary identifies what the static interface cannot do. An acceptance blocker is a critical failure that prevents readiness even when other rubric points are earned. Offline delivery means the supplied local documents and resources can be used without fetching a remote dependency.

## Build contract
Deliver four documents: `index.html`, `catalogue.html`, `membership.html` and `visit.html`. The fictional context must be visible throughout the site. Home links readers to the other tasks. Catalogue contains three fictional titles and their collections. Membership reuses the Chapter 70 local demonstration, not a collection endpoint. Visit supplies fictional practice hours and explicitly says that no actual destination, access conditions or contact route have been verified.

## Implementation route
Use the same primary-navigation labels and destinations on every page, with exactly one current-page marker. Give each document its own title and main heading. Keep the catalogue caption and headers meaningful. Bound its wide table inside a labelled, focusable scroll region rather than hiding its second column on a phone. Reuse the form markup and maintained script from Chapter 70, then test that the integration still preserves all error, correction, reset and failed-script behaviours.

## Truthful visit information
The practice timetable is Tuesday to Saturday, 09:00 to 17:00, closed Sunday and Monday. These are example hours, not a real timetable. Do not infer step-free access from an invented building or publish an imaginary address as a destination. The reference clearly states that entrance routes, parking and facilities are unverified. A real service needs verified location and relevant access details, not a generic accessible badge.

## Acceptance and recovery
Enter the site through every page directly and follow every primary link. Check all four at 320 CSS pixels, with keyboard-only navigation and without scripting. Use valid and invalid fictional values on Membership and inspect requests and the URL. Re-run the form suite rather than assuming component reuse proves correct integration. Extract the ZIP and inspect the same tasks offline. Styles or images failing should not remove the page's content, and script failure must leave the form disabled.

## Reference walkthrough
The supplied site offers only reading and local validation tasks. It cannot reserve a title, accept an application, search a catalogue or record a visit. Catalogue entries are static HTML, not a backend disguised by a polished layout. The Visit page makes its missing real-service details explicit. README, BRIEF and SOLUTION describe these limits from the same chapter source. This reference is a teaching implementation, not independent accessibility approval, a security audit or a production service.

## Assessment rubric: 28 observable points
Award one point for each demonstrated check below, four per area. Record the evidence next to the check; untested checks receive no point. These points are an authoring assessment aid, not WCAG conformance or security certification. A broken primary task, a misleading service claim, unsafe data collection or a dead required destination blocks readiness regardless of the score.

### Four-page contract (4 points)
- All four required documents exist.
- Every page has its own document title.
- Every page has a main heading.
- Fictional static-service status is visible.

### Navigation (4 points)
- All primary labels are consistent.
- All primary destinations resolve from every page.
- Exactly one current-page link appears per page.
- The skip link reaches each main landmark.

### Catalogue (4 points)
- Three fictional entries are supplied.
- The caption describes the data.
- Row and column headers identify relationships.
- The table scrolls inside a named keyboard-focusable region.

### Membership safety (4 points)
- The no-script baseline is disabled.
- Setup enables only local validation.
- Invalid submit provides linked field errors.
- Valid submit claims no sent application.

### Membership recovery (4 points)
- Correcting failed fields removes their errors.
- Editing clears prior success.
- Reset clears values/errors/custom validity.
- Blocked script leaves instructions and disabled fields.

### Visit truth (4 points)
- Practice hours are explicitly fictional.
- Sunday/Monday closure is stated.
- No real address or contact is invented.
- Access conditions are explicitly unverified.

### Integrated evidence (4 points)
- Every page opens directly after extraction.
- All four pages fit a 320-pixel viewport outside tables.
- Keyboard focus remains visible.
- Submit emits no application request or URL values.

## Example

```html
<nav aria-label="Primary">
  <a href="../projects/capstone/index.html" aria-current="page">Home</a>
  <a href="../projects/capstone/catalogue.html">Catalogue</a>
  <a href="../projects/capstone/membership.html">Membership</a>
  <a href="../projects/capstone/visit.html">Visit</a>
</nav>
<main><h1>Neighbourhood Library</h1>
  <p>A fictional static reference site, not a real library service.</p>
  <p>No books can be reserved and no applications are collected here.</p>
  <ul><li><a href="../projects/capstone/catalogue.html">Browse fictional book data</a></li>
    <li><a href="../projects/capstone/membership.html">Inspect the demonstration form</a></li>
    <li><a href="../projects/capstone/visit.html">Read the fictional visit information</a></li></ul>
</main>
```

The chapter fragment previews Home and links into the four-document reference; it is not the entire capstone. Within the download, the four pages use sibling-relative links and each updates its own current-page marker. The generated membership form comes from Chapter 70 and uses the same script, so its privacy and error-recovery boundaries stay aligned. Catalogue and Visit contain actual explanatory content, not headings awaiting a backend. A static reference can be complete against this contract while remaining insufficient as a real public library service.

## Common mistake

A working Home page does not prove the capstone works. Dead catalogue links, an enabled no-script membership form or unverified step-free claims are critical failures even if the visual design scores well.

## Exercise

Home passes a visual check, but Membership submits named values with GET when its script is blocked and Visit claims step-free access without evidence. Can a high rubric total make this ready?

## Explained answer

No. Privacy/task and truthful-service blockers prevent readiness regardless of points. Restore the disabled fieldset baseline and install the local submit/error/reset handlers before enabling it; confirm the blocked-script test leaves it unusable for collection and emits no application query. Remove the unsupported access claim and state what has not been verified. Then test all four pages directly, all navigation routes, membership errors and reset, narrow table scrolling and the extracted offline package. Do not convert same-assistant checks into independent accessibility or security approval.

## Sources

- HTML Living Standard: the nav element: https://html.spec.whatwg.org/multipage/sections.html#the-nav-element
- HTML Living Standard: links: https://html.spec.whatwg.org/multipage/links.html#links
- HTML Living Standard: the form element: https://html.spec.whatwg.org/multipage/forms.html#the-form-element
- WAI Forms Tutorial: user notifications: https://www.w3.org/WAI/tutorials/forms/notifications/
- HTML Living Standard: table header cells: https://html.spec.whatwg.org/multipage/tables.html#the-th-element
- WCAG 2.2 Understanding: Reflow: https://www.w3.org/WAI/WCAG22/Understanding/reflow.html
- WCAG 2.2 Understanding: Focus Order: https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html

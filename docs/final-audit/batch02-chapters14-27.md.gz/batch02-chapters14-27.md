# The HTML Playbook: revised Chapters 14 to 27

**Odejobi Abiola Samuel | CTROTECH**

Candidate manuscript, reviewed 15 October 2026. AI-assisted preparation. Copyright and third-party rights follow the publication notices. This is a same-agent first-pass revision, not independent approval or a final release.

Examples retain their publication-relative paths. The original teaching schematic is also supplied as `library-floor-plan.svg` beside this excerpt. Browser evidence and remaining coverage are described in `batch02-report.md`.

# Chapter 14: Headings and paragraphs

Make the page structure readable without its styling.

## Objectives

- Create a conventional heading hierarchy
- Use paragraphs, line breaks and thematic breaks for their meanings
- Group a heading and supporting subtitle without inventing a subsection

## Lesson

A heading names the content that follows it. Use h1 through h6 to express the hierarchy you intend. For the ordinary pages in this book, one page-level h1 and properly nested subsection headings are a practical convention.

Where a document has headings, the current Standard requires at least one computed level-1 heading and does not permit a forward level jump of more than one between consecutive headings. It does not require exactly one h1.

Choose heading levels for structure, not font size. CSS can make an h2 smaller or larger without changing its meaning. A section element does not automatically reset a conventional heading hierarchy to a new h1 in the way many old tutorials suggested.

## Separate paragraphs from line breaks
Use p for paragraphs. br is a line break within content where the break itself belongs, such as an address or a poem. Empty paragraphs and repeated br elements are not layout tools. hr represents a thematic break, not merely a horizontal line to decorate a page.

The Living Standard also includes headingoffset and headingreset. These require independent compatibility and accessibility review; they are not a reason to discard a clear conventional hierarchy. This edition records them in the reference and uses ordinary heading levels in its running examples.

## A heading and its supporting line
Use `hgroup` when a heading has a subtitle, alternative title or tagline that belongs with it. It contains one `h1` to `h6`, with permitted `p` elements before or after it, and allows script-supporting elements under its content model. For example, `<hgroup><h1>Library membership</h1><p>A place for every reader</p></hgroup>` keeps the tagline as a paragraph rather than pretending it is a subsection heading.

## Understand offsets before relying on them
In the current Standard, `headingoffset` is an integer from 0 to 8 for authoring, and `headingreset` is boolean. Computation starts at the heading itself, adds offsets while walking its inclusive ancestors and stops at a reset boundary. The computed heading level is capped at 9. An inherited offset of 1 changes an `h2` computation to level 3; a reset boundary prevents offsets outside that boundary from contributing. When the current node has a shadow-root parent, traversal continues at that shadow root's host. An offset on the reset boundary itself still contributes before traversal stops.

These rules do not rename the DOM element or prescribe its font size. They are also not evidence that every browser and assistive-technology combination exposes the computed level correctly. Keep the ordinary hierarchy in the running example, and test any offset-based component against the actual target browsers and accessibility tools.

## Worked example

```html
<main>
  <h1>Membership</h1>
  <p>Membership is open to local residents.</p>
  <section>
    <h2>What to bring</h2>
    <p>Bring an address document and a form of identification.</p>
  </section>
</main>
```

The h2 introduces a subsection of membership. It does not depend on the browser calculating an implicit outline from section nesting.

## Common mistake

Picking h4 because its default size matches a design. That makes document structure depend on a browser stylesheet.

## Exercise

A designer wants the main heading to look small. Should you change h1 to h5? Where should a subtitle go when it belongs with the main heading?

## Explained answer

Keep the heading level that matches the document structure and change its presentation with CSS. A visual size preference does not change where the heading belongs in the hierarchy. A supporting subtitle can be a p in an hgroup with the heading; it should not become a false subsection heading.

## Sources

- [HTML Living Standard: headings](https://html.spec.whatwg.org/multipage/sections.html#the-h1,-h2,-h3,-h4,-h5,-and-h6-elements)
- [HTML Living Standard: paragraphs](https://html.spec.whatwg.org/multipage/grouping-content.html#the-p-element)
- [HTML Living Standard: hgroup](https://html.spec.whatwg.org/multipage/sections.html#the-hgroup-element)
- [HTML Living Standard: heading levels and offsets](https://html.spec.whatwg.org/multipage/sections.html#heading-levels-&-offsets)

---

# Chapter 15: Inline meaning

Pick emphasis because of the sentence, not the browser font.

## Objectives

- Distinguish stress, importance and presentation
- Represent titles and quotations deliberately
- Mark a defining instance and supply its definition

## Lesson

em marks stress emphasis. strong marks importance, seriousness or urgency. Their default italic and bold styles are not their definitions. A book title can use cite; a short quotation can use q. Use a blockquote for a quoted section rather than a short inline quotation.

small suits side comments such as a copyright or a qualification. mark can identify text relevant to the reader's current context, such as a search match. span supplies a generic phrasing container when no more specific semantic element fits.

## Do not turn typography into semantics
The b and i elements also have defined uses beyond their default appearance. b can draw attention without conveying extra importance; i can mark text in an alternate voice or mood. u is for an explicitly rendered non-textual annotation, not a generic request to underline.

Quote and cite carefully. A cite attribute can record a source URL, but browsers do not normally expose it as a useful visible citation. Provide an ordinary visible source link when readers need to follow it. cite represents a work's title rather than a person's name.

## Define a term, rather than just styling it
`dfn` identifies the defining instance of a term. In `<p>A <dfn>loan period</dfn> is the time before an item is due back.</p>`, the same paragraph contains the definition. The nearest containing paragraph, description-list group or section must contain the definition; merely adding `dfn` to an unexplained word is not enough. Do not nest one `dfn` inside another.

If `dfn` has a `title`, that value identifies the exact term being defined, not a longer explanatory tooltip. Without that title, if the dfn has exactly one element child, that child is an abbr with a title, and there are no child Text nodes, the abbr title gives the term. Otherwise, the dfn descendant text supplies it. Even whitespace Text nodes matter to that special-case condition. Chapter 20 explains abbreviation expansions. `s` marks wording that is no longer accurate or relevant; Chapter 20 contrasts it with `del`, which marks an edit.

A `q` quotation has phrasing content. A `blockquote` can contain a quoted section with paragraphs and other permitted structure. Neither element verifies a quotation or attributes it for you. Keep an ordinary visible source citation where readers need it.

## Worked example

```html
<p><strong>Return the key before closing time.</strong></p>
<p>You may borrow <em>two</em> reference books.</p>
<p>Our reading group chose <cite>Things Fall Apart</cite>.</p>
```

The importance of returning the key differs from the stress on two. The novel's title names a work; it does not claim emphasis in the sentence.

## Common mistake

Using strong around every visually bold fragment, including purely decorative interface text.

## Exercise

Which element fits a short phrase that must carry stress in the sentence, and which fits an urgent warning? In the loan-period example, what makes dfn more than a styling hook?

## Explained answer

Use em for stress emphasis and strong for an urgent or important warning. If the requirement is only a typeface change, use CSS on an appropriate existing element or a neutral span. It identifies the defining instance, and the containing paragraph actually states what the term means.

## Sources

- [HTML Living Standard: text-level semantics](https://html.spec.whatwg.org/multipage/text-level-semantics.html#text-level-semantics)
- [HTML Living Standard: defining instances](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-dfn-element)
- [HTML Living Standard: content no longer accurate](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-s-element)
- [HTML Living Standard: inline quotations](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-q-element)

---

# Chapter 16: Code and technical text

Preserve the source when readers need to copy it.

## Objectives

- Distinguish code, input and output
- Display copyable escaped source
- Distinguish meaningful subscripts and superscripts from decoration

## Lesson

code identifies computer code. pre preserves the significance of whitespace in preformatted text. Combine them when indentation and line breaks matter. Escape markup characters before placing HTML source inside either element.

kbd marks user input, samp marks sample output, and var marks a variable. These meanings are useful even when a stylesheet makes them look similar. A filename or a command does not need a decorative badge to be understandable.

## Give examples enough context
State the file, command environment or containing element that an example needs. Readers should know whether they can paste a block into a document or need to supply surrounding code. A fragment that works in body may be invalid in head.

Avoid screenshots as the only version of code. Text can be copied, searched and read by assistive technology. If a code block scrolls horizontally, make the scroll container keyboard reachable and label it. Keep the example short enough to explain; put a longer working file in the downloads.

## Subscripts and superscripts carry meaning
Use `sub` and `sup` for meaningful typographical conventions, not to move decorative text up or down. `<var>x</var><sup>2</sup>` represents a squared variable; `H<sub>2</sub>O` uses a chemical subscript. A logo that merely has raised lettering should use CSS instead. For richer mathematical structure, consider the MathML integration discussed in Chapter 33.

There is a parser detail worth checking when exact text matters: in HTML syntax, one leading newline immediately after a `pre` start tag is stripped. `<pre>` is not a raw-text escape hatch. If `code` is its first child, a newline inside that child is not the same immediate-after-`pre` case. Test the actual text and use the exact source download when copying a complete example.

Keyboard combinations can be grouped with nested `kbd`, such as `<kbd><kbd>Ctrl</kbd> + <kbd>S</kbd></kbd>`. The shortcut still depends on the application and platform. An element describing input does not register that shortcut.

## Worked example

```html
<p>Press <kbd>Ctrl</kbd> + <kbd>S</kbd> to save.</p>
<pre><code>&lt;h1&gt;Library catalogue&lt;/h1&gt;</code></pre>
<p>The server returned <samp>201 Created</samp>.</p>
```

The example shows HTML source as text. kbd identifies input rather than output. The status string is a sample response, not proof that this page made a request.

## Common mistake

Pasting raw <h1> markup into code and expecting it to stay visible as source.

## Exercise

Why do you still need escaping inside pre and code? Should a decorative raised logo character automatically use sup?

## Explained answer

Neither element turns off ordinary HTML parsing of their contents. Escape the angle brackets so the parser creates text instead of an h1 element. pre changes whitespace handling, not the basic parsing rule. No. Use CSS for a decorative position; sup is for meaningful superscript conventions.

## Sources

- [HTML Living Standard: preformatted text](https://html.spec.whatwg.org/multipage/grouping-content.html#the-pre-element)
- [HTML Living Standard: code](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-code-element)
- [HTML Living Standard: sub and sup](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-sub-and-sup-elements)
- [HTML Living Standard: keyboard input](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-kbd-element)
- [HTML Living Standard: sample output](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-samp-element)
- [HTML Living Standard: variables](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-var-element)

---

# Chapter 17: Links that go somewhere

Let the destination explain the control.

## Objectives

- Choose links for navigation
- Resolve document and fragment URLs correctly

## Lesson

An a element with href creates a hyperlink. Give it wording that makes sense in context and a destination that does what the wording promises. A file path, a fragment and an absolute URL resolve differently.

Without a base URL that changes the target document, a fragment such as #fees points to an element with a matching id in the current document. Relative URLs resolve against the document's base URL. A base element can change that resolution across the page, which makes it easy to introduce surprising navigation bugs.

## Navigation is different from an action
Use a hyperlink to go to a resource. Use a button to submit a form or perform an interface action. href="#" is not a neutral placeholder for a JavaScript button; it still has navigation behavior.

Opening a new browsing context changes the user's experience. Avoid doing it automatically without a reason. If you use target="_blank", describe the behavior where it helps and understand opener relationships. Modern anchor behavior provides implicit noopener for this target, but explicitly writing rel="noopener" can document the intention. Do not imply that this solves every trust or privacy concern.

## Resolve the URL before trusting the label
If the document is `https://example.invalid/book/pages/contact.html`, `../index.html` resolves to `https://example.invalid/book/index.html`, while `/index.html` resolves at the origin root. These are different paths. A fragment-only URL also resolves against the document's base: a `base` pointing to another document can make `#fees` target that other document, not the current page.

Inspect the resolved `href` as well as its source attribute. The attribute preserves the relative spelling; the DOM property gives the resolved URL. A `download` attribute does not promise that every cross-origin link will download a file, and a mail or telephone link does not implement a communications service. Check the destination's rules and the actual user experience.

## Worked example

```html
<p><a href="catalogue.html">Browse the catalogue</a></p>
<p><a href="#fees">Read the membership fees</a></p>
<section id="fees">
  <h2>Membership fees</h2>
  <p>Ask the desk about the current membership options.</p>
</section>
```

The first URL is a sibling document. The second is a fragment in this document. The target id must be unique in the element's tree.

## Common mistake

Using link text such as click here repeatedly when a destination-specific phrase would be clearer.

## Exercise

Would you use an anchor or a button to open the next page of the catalogue? What about removing a book from a local reading list? Can a base element make #fees target another document?

## Explained answer

Use an anchor for another catalogue page. Use a button for the removal action. If the action changes server data, also design and test its request, permissions and error handling; the element choice alone does not implement those controls. Yes. Even a fragment-only reference resolves against the document base URL; inspect the resolved href before treating it as a current-document target.

## Sources

- [HTML Living Standard: the a element](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-a-element)
- [HTML Living Standard: links](https://html.spec.whatwg.org/multipage/links.html#links)
- [HTML Living Standard: base URLs](https://html.spec.whatwg.org/multipage/semantics.html#the-base-element)
- [HTML Living Standard: downloading resources](https://html.spec.whatwg.org/multipage/links.html#downloading-resources)

---

# Chapter 18: Lists with a reason

Order and relationships determine the markup.

## Objectives

- Distinguish ordered, unordered and description lists
- Nest a list under the item it expands
- Explain what menu supplies and what it does not implement

## Lesson

Use ul for a group whose order is not significant, and ol when sequence or rank is part of the meaning. Each item is an li. A navigation menu is often a list of links, but not every group of adjacent items needs list markup.

A description list uses dl, dt and dd for name-value groups. A group can have multiple terms or multiple descriptions. It is not limited to dictionary definitions and does not require a table-like visual layout.

## Keep nested lists inside an item
A sublist belongs inside the li it expands. A list placed beside an li is not that item's nested list. Markup should explain the relationship before CSS adds indentation.

For ordered lists, start and reversed can change the numbering behavior, and an li value can set an item's ordinal value in an ol. These are useful when the displayed order has meaning. Avoid using list markers as a substitute for actual text if readers need the text outside that presentation.

## Commands and description groups
`menu` represents an unordered list of commands, a semantic alternative to `ul` for that purpose. `<menu><li><button type="button">Copy</button></li><li><button type="button">Paste</button></li></menu>` describes two command items; it does not implement either action. It is not the ARIA menu-widget pattern and does not automatically provide arrow-key navigation, a popup or a context menu.

In a `dl`, one or more `dt` names precede one or more `dd` values in each group. Keep several paragraphs belonging to one value in the same `dd`. A permitted alternative wraps each complete name-value group in a `div`, for example `<dl><div><dt>Saturday</dt><dd>10:00 to 14:00</dd></div></dl>`. Do not mix direct groups and div-wrapped groups as if the two content-model alternatives were interchangeable.

For a reversed `ol` without an explicit start, the initial ordinal is based on the number of its list-item children. A `value` on an `li` can change that item's ordinal and the sequence that follows. Check source order as well as marker styling; CSS counters are a separate presentation mechanism.

## Worked example

```html
<ol>
  <li>Choose a book.</li>
  <li>Check the lending period.
    <ul><li>Reference books have separate rules.</li></ul>
  </li>
  <li>Take the book to the desk.</li>
</ol>
```

The unordered sublist qualifies the second step. It remains inside that step's li, so the tree preserves the relationship.

## Common mistake

Putting the nested ul directly under the outer ol between two li elements.

## Exercise

Which structure fits opening hours grouped by day names: an ordered list of steps or a description list? Does menu implement a popup and its keyboard controls?

## Explained answer

A description list is a reasonable choice for day names and their hours because the groups describe name-value relationships. A table may be better when readers need to compare a regular grid of days and multiple time ranges. An ordered list communicates that order matters; it does not inherently mean a procedure. Use it if the ordered sequence itself is the point, rather than merely to pair each day with its hours. No. The element describes a command list; a popup widget and its keyboard interaction require separate implementation and testing.

## Sources

- [HTML Living Standard: lists](https://html.spec.whatwg.org/multipage/grouping-content.html#the-ol-element)
- [HTML Living Standard: description lists](https://html.spec.whatwg.org/multipage/grouping-content.html#the-dl-element)
- [HTML Living Standard: menu commands](https://html.spec.whatwg.org/multipage/grouping-content.html#the-menu-element)
- [HTML Living Standard: list items](https://html.spec.whatwg.org/multipage/grouping-content.html#the-li-element)

---

# Chapter 19: Figures and captions

Keep self-contained material with its explanation.

## Objectives

- Choose a figure for self-contained content
- Separate a caption from an image alternative
- Check alternative text against the supplied teaching schematic

## Lesson

A figure holds self-contained content that the surrounding prose can refer to as a unit. It can contain a diagram, photograph, code listing or another suitable item. figcaption supplies its caption as the first or last child when present.

Not every image needs a figure. An icon in a button is part of that control. A photograph beside a paragraph may or may not be self-contained. Decide from the content relationship, not a desire for a styled border.

## A caption and alternative text do different work
A caption explains the figure in the document. Alternative text supplies a replacement for an image according to its purpose and context. Repeating a long caption word for word as alt can add noise without helping. An image with information absent from the caption still needs that information represented appropriately.

A complex chart usually needs more than a short alt string. Provide the important conclusion and a detailed text or data alternative that readers can reach. Do not claim an image is accessible solely because alt is present.

## Keep the figure's structure honest
A `figure` may have one `figcaption`, placed first or last, not inserted between arbitrary content children. The caption can describe a code listing or a quotation as well as an image. If the content is a quotation, keep attribution outside the quoted passage, for example in the figure's caption.

The supplied floor plan is an original teaching schematic, not a map of real premises. Compare its rooms with the alternative: the reading room is left of reception, and the lift is across the corridor. The caption identifies the purpose of the schematic rather than repeating those relationships. For a real plan, check every direction against the actual premises and provide another usable route to essential location information.

## Worked example

```html
<figure>
  <img src="../assets/library-floor-plan.svg"
       alt="The reading room is left of reception; the lift is opposite."
       width="640" height="360">
  <figcaption>Teaching schematic: ground-floor facilities near reception.</figcaption>
</figure>
```

The alternative conveys the directions shown by the image. The caption identifies the figure's subject in the document. A real floor plan would need its own reviewed alternative based on its actual contents. The supplied schematic is fictional, not a real-site access or evacuation plan.

## Common mistake

Generating alternative text from a filename without inspecting the image or its purpose.

## Exercise

A chart caption says Monthly loans. Does repeating Monthly loans in alt communicate the chart's trend? In the supplied schematic, what does the alternative communicate that the caption does not?

## Explained answer

No. It only repeats the subject. Describe the meaningful information, and provide an accessible data table or fuller explanation when the chart needs one. The appropriate wording depends on the actual data and the reason the chart appears. It gives the reading-room and lift relationships to reception; the caption identifies the schematic and its teaching purpose.

## Sources

- [HTML Living Standard: figures](https://html.spec.whatwg.org/multipage/grouping-content.html#the-figure-element)
- [HTML Living Standard: figcaption](https://html.spec.whatwg.org/multipage/grouping-content.html#the-figcaption-element)
- [WAI images tutorial: complex images](https://www.w3.org/WAI/tutorials/images/complex/)

---

# Chapter 20: Dates, values and edits

Give machines a useful value without spoiling the sentence.

## Objectives

- Use machine-readable dates without invented precision
- Distinguish document edits from obsolete wording
- Expand an abbreviation visibly and distinguish edit timestamp syntax

## Lesson

time can pair readable date or time text with a machine-readable datetime value. Use a value that matches the defined syntax and the kind of temporal information you actually know. Do not add a timezone or a time of day just to make a date look more precise.

data associates its contents with a machine-readable value. It is useful for a product identifier or another mapping that a script or processor uses. It does not create a general validation rule for that value.

## Record edits when the change matters
ins and del mark additions and deletions. Their datetime and cite attributes can record when and why a change happened, subject to their defined rules. Provide visible context when readers need it; an attribute alone is not a usable change log.

s has a different meaning from del: it marks content that is no longer accurate or relevant, without necessarily marking a document edit. An old price can be struck through while the current price remains plainly stated. Choose the meaning before choosing the decoration.

## Expand an abbreviation where readers can use it
`abbr` marks an abbreviation or acronym. For example, `Hypertext Markup Language (<abbr title="Hypertext Markup Language">HTML</abbr>)` provides a visible expansion as well as optional metadata. If `title` is present on `abbr`, it must contain the expansion, and nothing else. Match the expansion's grammatical number to the abbreviation content: a plural abbreviation needs a plural expansion. Do not put an unrelated explanation there, and do not assume an expansion on one abbreviation is inherited by another occurrence.

Using `abbr` for every abbreviation is not mandatory. Expand unfamiliar terms in visible text when that helps readers, rather than making essential information available only through a tooltip whose behavior varies by device and software.

## Match the date syntax to the element
`time` accepts several defined kinds of temporal values, including dates, times and durations; they are not all interchangeable timestamps. By contrast, `datetime` on `ins` and `del` uses a valid date string with optional time. If that edit value includes a time, it must be a valid global date and time with the required offset information. A bare local time such as `10:00` is not a complete edit timestamp. Keep a visible explanation of an important policy change rather than relying on metadata alone.

## Worked example

```html
<p>Next meeting: <time datetime="2026-11-07">7 November 2026</time>.</p>
<p>Book code: <data value="LIB-204">Local history collection</data>.</p>
<p>The desk opens at <del>09:00</del> <ins>10:00</ins>.</p>
```

The date supplies only a date. The collection has an explicit identifier. The changed opening time is visible in the sentence, rather than hidden in metadata.

## Common mistake

Writing an informal date such as 7/11/26 in datetime and assuming every parser will interpret it the same way.

## Exercise

You know an event date but not its time. Should you write a midnight UTC timestamp? Is datetime="10:00" a valid edit timestamp on ins?

## Explained answer

No. Use a valid date value such as 2026-11-07. A fabricated time or timezone adds information you do not have and can mislead downstream software. No. An edit needs a valid date with optional time, not a bare local time. Do not transfer every time-element value syntax to ins or del.

## Sources

- [HTML Living Standard: time](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-time-element)
- [HTML Living Standard: edits](https://html.spec.whatwg.org/multipage/edits.html#edits)
- [HTML Living Standard: abbreviations](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-abbr-element)
- [HTML Living Standard: edit attributes](https://html.spec.whatwg.org/multipage/edits.html#attributes-common-to-ins-and-del-elements)
- [HTML Living Standard: date strings with optional time](https://html.spec.whatwg.org/multipage/common-microsyntaxes.html#valid-date-string-with-optional-time)

---

# Chapter 21: Language and direction

Language, writing direction and pronunciation are separate concerns.

## Objectives

- Mark language changes
- Isolate mixed-direction text
- Distinguish optional word breaks from forced line breaks

## Lesson

Set the primary language on html, then mark language changes where they occur. A valid language tag helps software choose pronunciation, spelling and other language-sensitive behavior. It does not translate the words or determine their writing direction.

Use dir for directionality. Values such as rtl and ltr express known directions; auto lets the user agent determine direction from the content under the defined rules. For user-provided names or messages of unknown direction, isolation can stop adjacent punctuation and text from being rearranged unexpectedly.

## Work with unfamiliar text
bdi isolates a run of text from the surrounding bidirectional context. bdo overrides direction and is a more specialized tool, not the normal choice for ordinary right-to-left text. Avoid inserting directional control characters casually when markup expresses the relationship more clearly.

Ruby annotations use ruby with rt and, where appropriate, rp fallback punctuation. They have language-specific uses and should be reviewed by someone who understands the writing system. Test the actual languages your product supports, including long words, mixed scripts and names that do not fit a Western given-name/surname assumption.

## Breaking a line is different from changing direction
`wbr` offers a line-breaking opportunity in otherwise difficult text, such as a long identifier. In `catalogue<wbr>reference`, it supplies a possible break without inserting a hyphen or an ordinary text space. It does not mean "start a new line here" in the way `br` does. Test copying and wrapping in the actual reading interface.

`bdi` has automatic directionality by default when no `dir` is specified. Writing `dir="auto"` can make the intention explicit. `bdo` is different: it requires `dir="ltr"` or `dir="rtl"` and overrides bidirectional ordering. Do not use it as the general wrapper for names whose direction you do not know.

A small ruby example is `<ruby>漢<rp>(</rp><rt>かん</rt><rp>)</rp></ruby>`. `rt` supplies the annotation; `rp` provides fallback parentheses for presentations that do not support ruby. This syntax example does not replace review of the reading and typography by someone familiar with the language.

## Worked example

```html
<p>Readers say <span lang="yo">Ẹ káàbọ̀</span> at the entrance.</p>
<p>Reserved for <bdi dir="auto">&#x645;&#x631;&#x64a;&#x645;</bdi>: shelf 4.</p>
```

The first span identifies Yoruba text. The bdi isolates the Arabic name from the English sentence and its punctuation. Language metadata does not replace a correct translation or a test with the intended text. The Arabic name uses numeric character references to keep the printed source unambiguous; the browser still renders the name as Arabic text.

## Common mistake

Using CSS direction as the only representation of document language, or assuming every non-Latin script is right-to-left.

## Exercise

A visitor submits a name whose writing direction you do not know. What is a reasonable HTML wrapper inside an English sentence? Does wbr add a hyphen or require an immediate new line?

## Explained answer

Use bdi, commonly with dir="auto", around the name. Keep the surrounding sentence language separate. Insert the untrusted name as text, not as untrusted HTML. Neither. It offers a breaking opportunity without adding a hyphen or ordinary space; br requests a line break.

## Sources

- [HTML Living Standard: language and direction](https://html.spec.whatwg.org/multipage/dom.html#the-lang-and-xml:lang-attributes)
- [HTML Living Standard: bidi isolation](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-bdi-element)
- [HTML Living Standard: word-break opportunities](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-wbr-element)
- [HTML Living Standard: directional overrides](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-bdo-element)
- [HTML Living Standard: ruby](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-ruby-element)
- [HTML Living Standard: ruby annotations](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-rt-element)
- [HTML Living Standard: ruby fallback](https://html.spec.whatwg.org/multipage/text-level-semantics.html#the-rp-element)

---

# Chapter 22: Containers and grouping

Use a generic container when the content has no more specific grouping meaning.

## Objectives

- Use generic wrappers deliberately
- Avoid adding semantics without a content reason

## Lesson

div is a generic flow container. span is its phrasing-level counterpart. Both are useful. The problem is replacing meaningful elements with them automatically, or adding layers with no clear purpose.

A wrapper for a layout grid may be a div. An independent article can be article. A quoted passage belongs in blockquote. Keep these choices distinct from class names such as card, row and panel, which describe your implementation rather than defining HTML semantics.

## Group for a stated reason
Start with the text and controls, then add a wrapper only when layout, scripting or a content relationship needs one. A single element can carry several class tokens. You do not need a separate div for every CSS property.

Do not add a role to every generic container. Many wrappers should remain semantically neutral. Adding unnecessary landmarks or groups can make an interface harder to navigate with assistive technology. When you do add an explicit accessible group, give it an appropriate purpose and name and test that relationship.

## A quotation needs a source, not an indentation effect
`blockquote` represents a section quoted from another source. Its `cite` attribute can record the source URL, but does not create a visible attribution. Keep an author's attribution outside the quoted content. If the quote and its attribution form a self-contained figure, the attribution can go in its `figcaption`.

Do not use `blockquote` just to obtain an indented box, and do not invent an expert quotation to give a sample credibility. A quotation can contain permitted paragraphs and other structure; a generic wrapper does not add quotation semantics.

## Worked example

```html
<div class="contact-grid">
  <section aria-labelledby="visit-title">
    <h2 id="visit-title">Visit the library</h2>
    <p>Ask at reception for directions.</p>
  </section>
  <section aria-labelledby="call-title">
    <h2 id="call-title">Contact the desk</h2>
    <p>Contact details are not configured in this teaching example.</p>
  </section>
</div>
```

The outer div is a layout wrapper. The named sections carry the content organization. A real contact page needs verified contact details; this teaching example deliberately supplies no dialable number.

## Common mistake

Naming a div class="section" and assuming it now has section semantics.

## Exercise

A wrapper exists only to arrange two existing sections in a grid. Does it need to become a third section?

## Explained answer

No. A generic div is appropriate for the layout wrapper. Another section would imply another thematic grouping and should have a content reason.

## Sources

- [HTML Living Standard: div](https://html.spec.whatwg.org/multipage/grouping-content.html#the-div-element)
- [HTML Living Standard: block quotations](https://html.spec.whatwg.org/multipage/grouping-content.html#the-blockquote-element)

---

# Chapter 23: Sections that have a subject

A section should explain the document, not a spacing requirement.

## Objectives

- Identify a thematic grouping
- Name useful regions without excessive landmarks

## Lesson

section represents a thematic grouping, normally with a heading. A chapter's requirements, an article's background and a service page's eligibility rules can be sections. A border or a margin does not establish a theme.

A heading can be enough to structure a straightforward document without wrapping every subsection in section. Choose wrappers when they clarify grouping or are needed for the document's relationships. Keep the conventional heading hierarchy readable either way.

## Name important regions
A section with an accessible name can become a region landmark in relevant accessibility mappings. Name a region when users benefit from navigating to it, rather than naming every small block. aria-labelledby can reference an existing visible heading.

Source order should remain understandable when layout is removed. Moving columns with CSS does not change the DOM reading order. Review both the visible result and the underlying sequence, especially when the page has multiple related sections.

## A heading and an accessible name are not the same mechanism
A visible heading inside a `section` helps readers understand the content, but it does not by itself always give the section a programmatic accessible name. In the example, `aria-labelledby="eligibility"` explicitly names the region from that heading. Without an accessible name, a `section` is not exposed as the same named region landmark under the HTML accessibility mapping.

Do not solve this by labelling every wrapper. Too many landmarks can obscure the useful ones. Review the resulting navigation structure with the intended accessibility tools, not only by counting section tags.

## Worked example

```html
<section aria-labelledby="eligibility">
  <h2 id="eligibility">Who can join</h2>
  <p>Membership options depend on the service you need.</p>
  <h3>Young readers</h3>
  <p>A guardian can help complete the application.</p>
</section>
```

The section has a theme and a visible heading used as its name. The h3 is a subsection under the h2, not a visual size instruction.

## Common mistake

Replacing every div with section as a general cleanup step.

## Exercise

A block exists solely to add a background colour around two unrelated widgets. Should it automatically be a section?

## Explained answer

No. A div may be the more accurate wrapper. Use section when the content forms a thematic grouping, usually introduced by a heading.

## Sources

- [HTML Living Standard: section](https://html.spec.whatwg.org/multipage/sections.html#the-section-element)
- [HTML Accessibility API Mappings: section](https://www.w3.org/TR/html-aam-1.0/#el-section)

---

# Chapter 24: Articles and supporting content

Decide what can stand on its own.

## Objectives

- Distinguish standalone and tangential content
- Use contextual headers and footers

## Lesson

article represents a complete or self-contained composition that could be distributed or reused independently in principle. A news story, a forum post or a self-contained review can qualify. An article can contain its own header, footer and sections.

aside holds content tangentially related to its surrounding content. The element does not mean right column. Related background could appear beneath the article on a phone and still be an aside. address provides contact information for its nearest relevant article or body ancestor; it is not a generic postal-address styling element.

## Reuse header and footer carefully
header is introductory or navigational material for its relevant context. footer can contain authorship, related links or other footer information. A footer does not need to sit at the bottom of a viewport.

Keep a page's repeated site header separate from an article's own introduction. If you include dates, author details or related reading, make their relationship clear from the surrounding structure and text. Do not select article merely because a card has a title; ask whether the content is a composition in its own right.

## Keep contextual landmarks and contact information distinct
A site-level `header` or `footer` can have a different accessibility mapping from one nested in an `article`, `section`, `nav`, `aside` or `main` context. Do not assume every header creates another banner landmark or every footer creates a site-level content-information landmark. Check both the document context and the mapping.

An `address` is for contact information for the nearest applicable article or body, not for any postal address mentioned in a story. A story describing a venue may simply use ordinary text for its location. The contact block also has content restrictions: it must not contain headings, sectioning content, header, footer or another address. Keep a "Contact" heading outside the address block when needed.

## Worked example

```html
<article>
  <header>
    <h2>A reading room after school</h2>
    <p>Library programme notes</p>
  </header>
  <p>The room is available for supervised study.</p>
  <footer><p>Contact the library desk for current sessions.</p></footer>
</article>
```

The article includes its own introduction and footer. Their meaning belongs to this composition; a page may also have a separate site-wide header and footer.

## Common mistake

Using aside because a design puts something on the right, even when it contains essential main content.

## Exercise

Is the only set of instructions for submitting an application appropriate in an aside?

## Explained answer

Usually not. Those instructions are part of the main task, not tangential content. Put essential instructions with the form or the relevant main section.

## Sources

- [HTML Living Standard: articles](https://html.spec.whatwg.org/multipage/sections.html#the-article-element)
- [HTML Living Standard: aside](https://html.spec.whatwg.org/multipage/sections.html#the-aside-element)
- [HTML Living Standard: address](https://html.spec.whatwg.org/multipage/sections.html#the-address-element)
- [HTML Living Standard: header](https://html.spec.whatwg.org/multipage/sections.html#the-header-element)
- [HTML Living Standard: footer](https://html.spec.whatwg.org/multipage/sections.html#the-footer-element)
- [HTML Accessibility API Mappings: header](https://www.w3.org/TR/html-aam-1.0/#el-header)
- [HTML Accessibility API Mappings: footer](https://www.w3.org/TR/html-aam-1.0/#el-footer)
- [HTML Accessibility API Mappings: body-scoped header](https://www.w3.org/TR/html-aam-1.0/#el-header-ancestorbody)
- [HTML Accessibility API Mappings: body-scoped footer](https://www.w3.org/TR/html-aam-1.0/#el-footer-ancestorbody)

---

# Chapter 25: Navigation and main content

Give recurring page regions clear jobs.

## Objectives

- Create a clear main region
- Distinguish navigation regions and test a skip link
- Apply the main hidden-state authoring condition

## Lesson

main represents the dominant content of the document body. A normal visible page should not expose several competing main regions. Repeated site navigation and the general site footer ordinarily sit outside main.

nav identifies a major navigation section. Use it for the principal site menu or a substantial table of contents, not every isolated link. If several navigation regions need distinguishing, give them concise names such as Primary and On this page.

## Make repeated content easy to pass
A skip link near the beginning can take keyboard users to main content. Its target needs a unique id and should be tested in the browsers you support. Keep the link visible on focus rather than hiding it permanently.

The search element groups controls or content used for searching or filtering. It does not implement a search service by itself. A form inside it can submit a query to a real endpoint. Keep the form's label and response behavior usable without relying on a decorative magnifying-glass icon.

## State the main-content requirement precisely
The authoring rule is that a document must not have more than one `main` without a `hidden` attribute. A CSS rule that merely hides another main is not the same condition. When an application switches between main elements, manage their hidden state deliberately.

A main must also be hierarchically correct: its permitted ancestors are limited by the definition. A simple page can keep main as a direct child of body, with articles and sections inside it. Do not put the page's main inside an article or a navigation section and assume a class name repairs the relationship.

`search` can contain a site's search form or filtering controls. It supplies search-related semantics, not a query engine, and it does not replace a label for the actual input. Check current implementation support before relying on a newer element's accessibility mapping.

## Worked example

```html
<a href="#main-content">Skip to main content</a>
<nav aria-label="Primary">
  <a href="index.html">Home</a>
  <a href="catalogue.html">Catalogue</a>
</nav>
<main id="main-content" tabindex="-1">
  <h1>Library services</h1>
  <p>Choose a service from the catalogue.</p>
</main>
```

The skip destination is programmatically focusable without adding it to ordinary sequential keyboard navigation. Test actual focus and scrolling rather than assuming the fragment provides the full intended experience everywhere.

## Common mistake

Giving several visible main elements different class names and treating them as layout columns.

## Exercise

How would you distinguish a site menu from a chapter table of contents for landmark navigation? Is CSS-only hiding enough to allow a second main without hidden?

## Explained answer

Use separate nav regions and name them, for example Primary and On this page. Keep names concise and avoid repeating the word navigation when the role already communicates it. No. The authoring condition specifically concerns main elements without a hidden attribute, not simply their CSS visibility.

## Sources

- [HTML Living Standard: main](https://html.spec.whatwg.org/multipage/grouping-content.html#the-main-element)
- [HTML Living Standard: navigation](https://html.spec.whatwg.org/multipage/sections.html#the-nav-element)
- [HTML Living Standard: search](https://html.spec.whatwg.org/multipage/grouping-content.html#the-search-element)
- [HTML Accessibility API Mappings: search](https://www.w3.org/TR/html-aam-1.0/#el-search)

---

# Chapter 26: Tables that explain the data

Use a table when the relationships run in rows and columns.

## Objectives

- Build a simple data table with headers
- Recognize when a complex table needs stronger associations
- Resolve explicit header ids and explain a zero row span

## Lesson

A data table relates cells along two axes. Use table, tr and the appropriate th or td cells. A caption identifies the table. thead, tbody and tfoot can group rows, but grouping alone does not create header associations for every complex layout.

For a simple table, use scope="col" on column headers and scope="row" on row headers where appropriate. More complex tables can need explicit id and headers relationships. Simplifying the data layout is often easier for readers than making a deeply spanned table navigable.

## Preserve the relationships on small screens
A wide table can live in a labelled, keyboard-reachable scrolling region. Do not replace it with a screenshot. If you change its visual layout, test that header relationships and reading order still make sense.

rowspan and colspan change the cell grid. Incorrect spans can make a table model hard to reason about even when the display appears close enough. Do not use obsolete presentational attributes to recreate an old layout system. Use CSS for table styling and keep HTML focused on the data.

## Know what column groups do
`colgroup` describes a group of table columns; `col` describes one or more columns within a group. For two individually described columns, `<colgroup><col><col></colgroup>` goes after any caption and before the row sections. `col` is void. A colgroup using its own `span` must not also contain col children. These elements do not replace the header cells that explain the data.

## Make an explicit relationship inspectable
The example gives the Days header `id="period-days"` and the General lending header `id="collection-general"`. For a case needing explicit relationships, `<td headers="collection-general period-days">14</td>` names those two headers. Each token must identify a `th` in the same table, and ids must still be unique in the tree. The attribute records relationships, not visible header text.

`colspan` author values run from 1 to 1000. `rowspan` permits 0 to 65534; zero means all remaining rows in the row group, not an unlimited span across the whole table. Spans must not overlap cells. A cell's `cellIndex` is its position in the row's cells collection, not necessarily its visual column after spans are considered.

A correct-looking grid and valid header references are not a screen-reader test. Verify the actual header announcements and navigation in the intended browser and assistive-technology combination.

## Worked example

```html
<table>
  <caption>Lending periods</caption>
  <thead><tr><th scope="col">Collection</th><th id="period-days" scope="col">Days</th></tr></thead>
  <tbody>
    <tr><th id="collection-general" scope="row">General lending</th><td>14</td></tr>
    <tr><th scope="row">Reference desk copies</th><td>0</td></tr>
  </tbody>
</table>
```

Each value has a collection row header and a Days column header. The numbers are fictional teaching data, not actual library policy.

## Common mistake

Using a table for an entire page layout, or using bold td cells where actual th headers are required.

## Exercise

Which two headers should describe the value 14 in this table? Which ids express those relationships explicitly, and does rowspan="0" cover later row groups?

## Explained answer

General lending and Days. The row header supplies the category and the column header supplies the quantity. The caption identifies the table as lending-period data. headers="collection-general period-days" refers to the corresponding th ids in this table. rowspan="0" extends through the remaining rows of the current row group, not later groups.

## Sources

- [HTML Living Standard: tables](https://html.spec.whatwg.org/multipage/tables.html#tables)
- [HTML Living Standard: column groups](https://html.spec.whatwg.org/multipage/tables.html#the-colgroup-element)
- [HTML Living Standard: columns](https://html.spec.whatwg.org/multipage/tables.html#the-col-element)
- [HTML Living Standard: cell attributes](https://html.spec.whatwg.org/multipage/tables.html#attributes-common-to-td-and-th-elements)
- [HTML Living Standard: header association algorithm](https://html.spec.whatwg.org/multipage/tables.html#header-and-data-cell-semantics)
- [WAI tables tutorial: irregular headers](https://www.w3.org/WAI/tutorials/tables/irregular/)

---

# Chapter 27: Plan a small site

Page structure should survive the trip between documents.

## Objectives

- Assign a purpose to each page
- Test paths under a deployment subdirectory

## Lesson

Before writing a multi-page site, list the pages and the task each page supports. Give every document a distinct title and a useful main heading. Repeated navigation should remain consistent without making every page's content identical.

Use relative links deliberately. A path from pages/contact.html to the home page differs from the same path in index.html. A root-relative path beginning with a slash can break when the site is hosted under a repository subpath on GitHub Pages.

## Work from a content map
For the library, start with Home, Catalogue, Membership and Contact. Keep policy wording in one maintained location and link to it. If pages repeat the same structure, use a build template rather than manually copying it indefinitely.

A navigation link with aria-current="page" identifies the current page. Keep that state correct on each document. Do not rely only on colour to mark it visually. Test every relative path from the built output and from the eventual deployment base path.

## Distinguish a deployment prefix from an origin root
For a page at `/book/pages/contact.html`, `../index.html` targets `/book/index.html`, while `/index.html` leaves the book prefix. This is a general URL-resolution issue, not a reason to switch hosting providers. Test the actual compiled links under the chosen base path, and repeat that test after changing any base element or routing convention.

`aria-current="page"` communicates the current page; it is not a disabled state. A current-page link may remain a working link. Keep its destination, state and visible indication consistent, and do not add `aria-disabled` merely because a navigation item is current.

## Worked example

```html
<nav aria-label="Primary">
  <a href="index.html">Home</a>
  <a href="catalogue.html" aria-current="page">Catalogue</a>
  <a href="membership.html">Membership</a>
  <a href="contact.html">Contact</a>
</nav>
```

The current-page state belongs to the catalogue link on this page. A shared template needs page-specific information to put that state on the right link.

## Common mistake

Assuming a site that works at localhost / will work unchanged at /repository-name/ when links begin with a slash.

## Exercise

From pages/contact.html, what relative path reaches index.html one directory above?

## Explained answer

Use ../index.html. The double-dot segment moves to the parent directory. Check the built link rather than guessing from the source template path.

## Sources

- [HTML Living Standard: URLs](https://html.spec.whatwg.org/multipage/urls-and-fetching.html#urls)
- [HTML Living Standard: hyperlinks](https://html.spec.whatwg.org/multipage/links.html#hyperlink)
- [WAI-ARIA: aria-current](https://www.w3.org/TR/wai-aria-1.2/#aria-current)

---

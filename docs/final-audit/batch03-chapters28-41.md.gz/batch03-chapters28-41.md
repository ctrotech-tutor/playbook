# The HTML Playbook: revised Chapters 28 to 41

**Odejobi Abiola Samuel | CTROTECH**

Candidate manuscript, reviewed 15 October 2026. AI-assisted preparation. Copyright and third-party rights follow the publication notices. Same-agent first-pass revision, not independent approval or a final release.

Examples retain publication-relative paths. Supplied media resources are included in the cumulative recovery patch, `candidate-source.patch.gz`. The recorded fixtures use fictional data and local receivers; the static book does not implement a submission service. Detailed findings are in `batch03-report.md`.

# Chapter 28: Images with a purpose

The alternative depends on why the image is there.

## Objectives

- Choose alternatives from purpose and context
- Use dimensions and loading hints deliberately
- Distinguish resource success from the image complete flag

## Lesson

An img embeds an image. Its src identifies a resource; alt supplies a text alternative according to the image's purpose. Useful alternative text requires the actual image and its context. A filename or a generic image description is not enough evidence.

For a purely decorative image, alt="" can keep it out of the ordinary text alternative. Do not omit alt as a casual way to say decorative. A functional image in a link needs an alternative that communicates the link's purpose if no other accessible wording provides it.

## Reserve the space
Provide width and height when you know the intended image dimensions or ratio. CSS can still size the rendered image responsively. Reserving an aspect ratio helps avoid layout movement as the resource loads.

Use loading="lazy" for suitable off-screen images, not automatically for the likely largest above-the-fold image. decoding and fetchpriority are hints with defined behavior and implementation limits. Measure before claiming a performance improvement. A broken src and a valid alt are different tests: an alternative does not make a missing image resource successful.

## Inspect the resource as well as the attribute
The running example now uses the supplied teaching schematic. Compare the reading room, reception and lift with the alternative before adopting its wording. A logo used as the only content of a home link needs to name that destination; a decorative divider can have an empty alternative. Those decisions come from purpose, not file format.

`complete` can be true for a broken image as well as a successfully fetched one. Check the image's actual state and natural dimensions rather than declaring success from that flag alone. `decode()` returns a promise for decoding; it can reject with an `EncodingError` when the image cannot be decoded. Handling that rejection is different from supplying useful alternative text.

`decoding` permits `sync`, `async` and `auto`; missing or invalid values select Auto. `fetchpriority` permits `high`, `low` and `auto`, with Auto as its missing and invalid default. These preferences do not guarantee a loading order or a performance gain. Lazy loading is a separate policy and should fit the image's position and purpose.

`crossorigin="anonymous"` requests CORS-enabled fetching without cross-origin credentials. It does not make a server grant access. Drawing a cross-origin image into a canvas without the required CORS access can make the bitmap unavailable for pixel readback. Chapter 33 explains that security boundary.

## Worked example

```html
<img src="../assets/library-floor-plan.svg"
     alt="The reading room is left of reception; the lift is opposite."
     width="640" height="360" decoding="async">
<p>Fictional teaching schematic, not directions to real premises.</p>
```

The supplied original schematic has a 640 by 360 view. Its alternative gives the two spatial relationships relevant here. The decoding preference is a hint, not a measured performance result. The same image could need different wording in a different context.

## Common mistake

Writing alt="image" or alt="photo" while leaving out the information the image contributes.

## Exercise

An image repeats the adjacent text label inside the same link and adds no other information. What alt value may be appropriate? Does img.complete alone prove that its resource decoded successfully?

## Explained answer

An empty alt can avoid repeating the link label, provided the visible text already supplies the required name and the image is genuinely redundant. Review the complete link and context rather than applying this to all linked images. No. A broken image can also be complete. Inspect the actual loading/decoding result and handle failures; alternative text remains a separate requirement.

## Sources

- [HTML Living Standard: images](https://html.spec.whatwg.org/multipage/embedded-content.html#the-img-element)
- [WAI images tutorial](https://www.w3.org/WAI/tutorials/images/)
- [HTML Living Standard: image decoding](https://html.spec.whatwg.org/multipage/embedded-content.html#dom-img-decode)

---

# Chapter 29: Responsive image choices

Offer candidates without pretending the browser follows a simple width switch.

## Objectives

- Describe candidate widths and slot size
- Separate resolution switching from art direction
- Check that the declared slot matches the implemented CSS

## Lesson

srcset gives the browser image candidates. Width descriptors describe candidate resource widths; sizes describes the expected rendered slot width for selecting among width candidates. A misleading sizes value can cause an unnecessarily large or blurry choice.

picture is useful for art direction or format alternatives. Its source elements appear before the fallback img. The img remains required for the actual image and its alternative text. A source inside picture has rules different from a source inside audio or video.

## Match the markup to the layout
If the slot is full width on small screens and half the viewport on wider screens, describe that relationship accurately. Keep a src fallback and test actual selections in the network panel at different viewport sizes and device pixel ratios.

Do not write a fixed candidate table and promise a particular resource in every browser condition. Selection can account for implementation and device considerations. For art direction, inspect that each crop still communicates the intended content and that the single alternative text remains appropriate.

## Read the descriptors literally
A `640w` descriptor says that the candidate resource has an intrinsic width of 640 pixels. It is not a breakpoint and does not mean "use this file on a 640-pixel screen." A `2x` descriptor expresses pixel density instead. Do not mix width and density descriptors in one candidate list.

With width candidates, `sizes` describes the intended image slot, not the width of the image file. It helps resource selection; it does not set the CSS layout. Check that the layout and the declared slot agree. When testing, inspect the image's `currentSrc` as well as its rendered dimensions. A previously cached resource can affect what you observe, so one resize is not a complete loading test.

## Keep the two source contexts separate
A `source` in `picture` uses `srcset`, not the media-resource `src` attribute. Source elements precede the image; the image still owns the alternative. The `type` can let the browser skip an unsupported format and the `media` can select a different composition. A source is not an image on its own.

For a lazy image that meets the auto-sizes conditions, a value such as `sizes="auto, (max-width: 40rem) 100vw, 50vw"` can use the concrete rendered width, with explicit sizes as fallback. `auto` must be first and is not a general replacement for sizes on eager images. Keep dimensions or a deliberate CSS size so the image does not depend on a misleading default box.

Resolution candidates are not an excuse to skip checking the crops. A portrait crop that removes the lift cannot keep an alternative describing the lift as if it were still visible. Use `currentSrc` to inspect selection, but remember that natural dimensions can be density-corrected rather than a direct report of the file's pixel width.

## Worked example

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Responsive schematic</title>
  <style>
    body { margin: 0; }
    img { display: block; width: 50vw; height: auto; }
    @media (max-width: 40rem) { img { width: 100vw; } }
  </style>
</head>
<body>
  <h1>Library layout: teaching schematic</h1>
  <img src="../assets/media/floor-plan-800.png"
       srcset="../assets/media/floor-plan-400.png 400w,
               ../assets/media/floor-plan-800.png 800w,
               ../assets/media/floor-plan-1200.png 1200w"
       sizes="(max-width: 40rem) 100vw, 50vw"
       alt="The reading room is left of reception; the lift is opposite."
       width="1200" height="675">
</body>
</html>
```

The three supplied raster files have the advertised intrinsic widths and the same 16:9 composition. The CSS actually implements the slot described by sizes. A browser may choose different resources under different device or caching conditions; the example does not promise an exact filename for each viewport.

## Common mistake

Using width descriptors with an inaccurate sizes value, or believing srcset is a guaranteed breakpoint-to-file mapping.

## Exercise

When is picture more appropriate than simply adding more width candidates to one img? Does sizes set the rendered width of the image?

## Explained answer

Use picture when the source itself should change, such as a different crop for a narrow layout or a supported format alternative. Use width candidates when the same image composition is available at different resource widths. No. The CSS determines layout; sizes informs resource selection. In the complete example the two descriptions agree, and all three resources exist.

## Sources

- [HTML Living Standard: responsive images](https://html.spec.whatwg.org/multipage/images.html#images)
- [HTML Living Standard: picture](https://html.spec.whatwg.org/multipage/embedded-content.html#the-picture-element)
- [HTML Living Standard: source contexts](https://html.spec.whatwg.org/multipage/embedded-content.html#the-source-element)
- [HTML Living Standard: sizes syntax](https://html.spec.whatwg.org/multipage/images.html#sizes-attributes)
- [HTML Living Standard: srcset syntax](https://html.spec.whatwg.org/multipage/images.html#srcset-attributes)

---

# Chapter 30: Audio, video and tracks

Playable media needs controls and usable alternatives.

## Objectives

- Provide controls and intentional loading hints
- Distinguish timed text and transcript needs
- Distinguish track-kind defaults from caption accuracy

## Lesson

audio and video embed media. Provide controls unless an appropriate alternative interface supplies the required operation. Autoplay is subject to browser policies and user choices; adding autoplay is not a guarantee that playback begins.

source provides alternate media resources with relevant type information. track supplies timed text such as captions, subtitles or descriptions using a supported format, commonly WebVTT. Captions and subtitles serve different purposes, so choose the kind accurately.

## Plan the alternative before publishing
A transcript, captions and an audio description each address different access needs. The correct combination depends on the media and the information it conveys. A decorative silent clip and an instructional interview do not have identical requirements.

Include a poster for suitable video content and choose preload with an understanding that it is a hint. Third-party players add privacy, performance and embedding-policy concerns. Test keyboard playback controls, caption selection, mobile behavior and fallback links with the actual resources. Placeholder filenames prove nothing about media decoding or caption accuracy.

## Be exact about timed text and source selection
The five track kinds are `subtitles`, `captions`, `descriptions`, `chapters` and `metadata`. Missing `kind` selects Subtitles; an invalid value selects Metadata, not Captions. `srclang` is required for a subtitle track and uses a valid language tag. A `default` track is a preference when the user's choices do not select something more appropriate, not a guarantee that it appears.

Only one subtitles-or-captions track per media element may have `default`. Separate limits apply to default descriptions and chapters. Do not mark every translation default. A loaded track and a reviewed caption are different achievements: inspect timing, speech, speaker identification and relevant non-speech sounds against the actual media.

An `audio` element can use controls and alternate source children too. It has no video picture to describe, but meaningful prerecorded speech still needs an appropriate text alternative. `muted` initializes the default-muted state; the current `muted` property can change afterward. `loop` requests repetition. `playsinline` concerns inline video presentation, not a permission to autoplay.

For media elements, a source's `media` condition is evaluated during resource selection, not continuously as a responsive picture reacts to environment changes. A nonempty media `src` takes precedence over source-child selection. Unsupported decoding needs an ordinary usable download or alternative, not only a confident MIME label.

The local fixture contains no speech and is deliberately small. Its descriptive transcript is not a claim that transcripts replace audio description for every audiovisual lesson. A real publication needs a media-specific accessibility plan and review.

## Worked example

```html
<video controls width="640" height="360" preload="metadata"
       poster="../assets/library-floor-plan.svg">
  <source src="../assets/media/schematic-demo.webm" type="video/webm">
  <source src="../assets/media/schematic-demo.mp4" type="video/mp4">
  <track kind="captions" src="../assets/media/schematic-demo.en.vtt"
         srclang="en" label="English" default>
  <p><a href="../assets/media/schematic-demo.mp4">Download the demo</a>.</p>
</video>
<p><a href="../assets/media/schematic-transcript.html">Read the descriptive transcript</a></p>
```

The supplied four-second fixture shows the fictional schematic and sounds a short tone, with no speech. The caption labels that sound; the descriptive transcript gives the visual information. Loading the cue and decoding the video are testable, but do not certify real-world media accessibility or make a transcript sufficient for every lesson.

## Common mistake

Treating auto-generated captions as reviewed simply because a track file loads.

## Exercise

Why put the transcript link outside the video element as well as providing fallback content? Does default on every caption translation make all of them display?

## Explained answer

Fallback children are not a reliable always-visible location in browsers that support video. An ordinary external paragraph gives every reader a discoverable transcript link. No. User preferences affect activation, and only one subtitles-or-captions track may be default for that media element. Caption accuracy still needs review against the actual content.

## Sources

- [HTML Living Standard: media](https://html.spec.whatwg.org/multipage/media.html#media-elements)
- [HTML Living Standard: tracks](https://html.spec.whatwg.org/multipage/media.html#the-track-element)
- [HTML Living Standard: source selection contexts](https://html.spec.whatwg.org/multipage/embedded-content.html#the-source-element)
- [WAI: making audio and video accessible](https://www.w3.org/WAI/media/av/)

---

# Chapter 31: Image maps

Coordinate-based hotspots need an equivalent way to navigate.

## Objectives

- Connect a map and its areas
- Review geometry and alternatives against the actual image
- Verify a hotspot against a supplied image and a real target

## Lesson

An image map associates areas of an image with hyperlinks. img uses usemap to refer to a map. area supplies a shape, coordinates, destination and appropriate alternative text for each linked region.

These controls are tied to the image's coordinate system. A design that resizes or changes the image needs careful testing. For many interfaces, ordinary links beside a diagram are easier to maintain and understand.

## Explain the destinations
Give each linked area an alt that communicates its purpose. A geographic or building diagram should not require readers to identify a shape visually before they can follow a link. Provide visible text links when they make the choices clearer.

Check keyboard focus, activation and the relationship between the displayed image and the hotspot geometry. The existence of an area element does not prove that a visitor can find the right destination or that the coordinate mapping still matches a responsive design.

## Measure coordinates in the displayed geometry
A rectangular area uses left, top, right and bottom coordinates; a circle uses centre x, centre y and radius; a polygon uses pairs of x and y values. `shape="default"` covers the image rather than taking coordinates. The coordinates are CSS-pixel distances in the defined image-map model, not a promise of automatic proportional scaling when CSS changes the image's size.

In this fixed-size example, the hotspot aligns with the supplied drawing. If you make the image fluid, verify the new geometry and activation at each relevant size rather than assuming that these coordinates adapt. The ordinary text link keeps the destination available without finding a hotspot.

A map needs a nonempty name unique among maps in the document; if it also has an id, that id must equal the name. A linked area needs destination-specific alternative text. An area without `href` is not the same hyperlink. `ismap` on an image inside a hyperlink is a different, server-side coordinate mechanism, not a replacement for these named client-side areas.

## Worked example

```html
<img src="../assets/library-floor-plan.svg"
     alt="Teaching plan: reading room left of reception, lift opposite"
     usemap="#facilities" width="640" height="360">
<map name="facilities" id="facilities">
  <area shape="rect" coords="26,240,290,322" href="#reading-room"
        alt="Reading room details">
</map>
<p><a href="#reading-room">Reading room details</a></p>
<section id="reading-room">
  <h2>Reading room</h2>
  <p>This fictional schematic places the reading room left of reception.</p>
</section>
```

The map name matches usemap, and its id matches the name. The rectangle encloses the reading-room box in the supplied 640 by 360 schematic. Both the area and the visible link reach the same real fragment target. This is not a map of actual premises.

## Common mistake

Copying hotspot coordinates to a different image and assuming the clickable regions still match.

## Exercise

What needs to change when a replacement floor-plan image moves the reading room to another location? If CSS halves this image, may you assume the unchanged hotspot still aligns?

## Explained answer

Review the area geometry against the new image, update coordinates and alternatives as necessary, and retest navigation. Also inspect the visible link wording and any directions that referred to the old layout. No. Review the displayed image-map geometry and retest pointer and keyboard activation. Keep the visible text destination usable as well.

## Sources

- [HTML Living Standard: image maps](https://html.spec.whatwg.org/multipage/image-maps.html#image-maps)

---

# Chapter 32: Embedding another document

An iframe introduces another browsing context and another trust decision.

## Objectives

- Identify an embedding trust boundary
- Choose sandbox permissions from actual requirements
- Explain srcdoc precedence without treating it as sanitization

## Lesson

iframe embeds another document. Give it a useful title so readers can identify the embedded content. A title does not fix the embedded document's own accessibility problems.

sandbox restricts capabilities. The tokens you add restore particular capabilities, so start from the actual requirements and grant as little as the integration needs. Combining allow-scripts with allow-same-origin can weaken the intended isolation for same-origin content. Do not describe sandbox as a universal security wrapper.

## Consider the resource owner
Third-party embeds may load tracking, cookies, scripts and further resources. Review privacy, origin policy, referrer policy and the allow attribute's Permissions Policy integration. A provider's sample embed code is a starting point, not a completed review.

object and embed serve other embedding cases and bring their own fallback and implementation concerns. param is obsolete for authoring in the captured Standard and belongs in migration guidance. Do not add it to new object examples because an old tutorial used it.

## srcdoc changes the source, not the trust decision
When present, `srcdoc` takes precedence over `src` and creates an `about:srcdoc` document. Relative URLs normally use the embedding document's base unless the embedded document establishes another base. When writing srcdoc into an HTML attribute, escape attribute delimiters and ampersands appropriately. Assigning an untrusted string to the srcdoc property is still an injection-sensitive operation, not text insertion.

An empty sandbox does not itself block every resource request. Use an appropriate CSP and permissions policy for the actual boundary. `allow` delegates selected Permissions Policy features within other applicable restrictions; it does not cancel sandbox flags or make a blocked feature available automatically.

The book's editable lab deliberately blocks nested frames and external media. Run this embedding example from its standalone HTML page when inspecting the notice, rather than weakening the lab policy to make every embed render. The real example's native frame can be read without scripts.

`object` uses `data` for an embedded resource and can contain fallback content; `embed` is void and cannot contain equivalent fallback children. A useful direct link outside either remains available independently. The publication policy blocks object/plugin embedding. Do not interpret that deliberate restriction as proof that a copied object example works in every deployment.

## Worked example

```html
<iframe title="Quiet-study notice" sandbox=""
        srcdoc="<!doctype html><html lang='en'><head><title>Notice</title></head><body><h1>Quiet study</h1><p>Keep calls outside the reading room.</p></body></html>"
        width="640" height="200"></iframe>
```

The static notice is supplied directly with srcdoc, so no missing preview.html is required. The empty sandbox grants no opt-in capabilities. This still does not mean the iframe is a universal no-network environment or that every embedded document is accessible.

## Common mistake

Adding every sandbox permission until an embed works, then assuming the original security boundary remains intact.

## Exercise

A widget needs only static text and images. Should you add allow-scripts and allow-same-origin by default? If src and srcdoc are both present, which supplies the iframe document?

## Explained answer

No. Do not grant capabilities without a demonstrated need. Test the actual static resource under the intended restrictions and document any permissions you choose to add. srcdoc takes precedence. It still parses markup, so neither that precedence nor the sandbox makes arbitrary untrusted HTML a safe text value.

## Sources

- [HTML Living Standard: iframe](https://html.spec.whatwg.org/multipage/iframe-embed-object.html#the-iframe-element)
- [HTML Living Standard: object](https://html.spec.whatwg.org/multipage/iframe-embed-object.html#the-object-element)
- [HTML Living Standard: embed](https://html.spec.whatwg.org/multipage/iframe-embed-object.html#the-embed-element)

---

# Chapter 33: Canvas, SVG and MathML

Graphics need a document-level alternative strategy.

## Objectives

- Distinguish bitmap drawing from document semantics
- Describe HTML integration boundaries for foreign content
- Explain why canvas export can fail for a cross-origin bitmap

## Lesson

canvas provides a bitmap drawing surface controlled through APIs. Drawing pixels does not automatically produce semantic headings, text or controls in the accessibility tree. Fallback content and a usable alternative interface need deliberate design.

SVG and MathML are foreign vocabularies that can be integrated into an HTML document. Their own element vocabularies and rules come from their respective specifications. HTML parsing and integration rules still matter at the boundary.

## Use the right representation
For a simple diagram, an SVG with a title and a text explanation can be more maintainable than a canvas rendering. For a data chart, an accessible table may communicate the exact values better than an image alone. For meaningful mathematical notation, MathML can express structure that a screenshot loses.

This chapter introduces the HTML integration, not completed Canvas or SVG API coverage. The assigned interfaces remain in the coverage ledger; member-level behavior, conversions, exceptions and tests are still required before the full publication can be final. Do not infer that a graphic is accessible merely because it has a title element. Review its purpose, interactions and the information the alternative actually supplies.

## A canvas has a bitmap size and context state
A canvas without dimensions starts with a 300 by 150 bitmap. CSS can change its displayed size without adding bitmap detail. In the 2D context, setting a dimension, even back to the same value, resets the bitmap and rendering state. Resize deliberately, then restore the needed state and redraw from maintained data.

`getContext("2d")` can return a context or null; do not assume every requested mode is supported. A canvas already bound to one context mode does not freely switch to a different one. Check the result before calling drawing methods.

An initially origin-clean bitmap can be tainted by cross-origin image drawing without appropriate CORS access. `toDataURL()` and `toBlob()` then throw `SecurityError`; drawing is not a way to bypass resource-origin restrictions. A usable export feature needs tested CORS behavior and a failure path, not advice to disable browser security.

## Preserve the foreign vocabulary's structure
A small MathML example is `<math xmlns="http://www.w3.org/1998/Math/MathML"><msup><mi>x</mi><mn>2</mn></msup></math>`. Unlike an image of a formula, it expresses an identifier raised to a power. SVG and MathML have their own namespaces, content rules and accessibility mappings. Do not treat every foreign node as an HTMLElement, and do not infer a useful spoken result merely from a title or namespace.

## Worked example

```html
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 100"
     role="img" aria-labelledby="route-title route-desc">
  <title id="route-title">Route to the reading room</title>
  <desc id="route-desc">Reception connects directly to the reading room.</desc>
  <path d="M40 50 H280" stroke="currentColor" stroke-width="4"/>
  <circle cx="40" cy="50" r="10" fill="currentColor"/>
  <circle cx="280" cy="50" r="10" fill="currentColor"/>
</svg>
```

The graphic has a short title and a description of the relationship. The visible diagram is intentionally simple. A real route plan with turns or hazards would need a more complete alternative.

## Common mistake

Replacing an interactive chart with canvas pixels while removing all operable controls and data relationships.

## Exercise

Your canvas chart shows exact lending totals. What alternative lets readers inspect those values without interpreting pixels? Does drawing a cross-origin image guarantee that toDataURL can read its pixels?

## Explained answer

Provide a text or data-table representation with the actual values and labels. Keep it synchronized with the chart data. If the chart has controls, those also need an accessible operable interface. No. Without the required CORS access, the drawing can taint the bitmap and pixel export throws SecurityError. Provide a supported source and a useful failure path.

## Sources

- [HTML Living Standard: canvas](https://html.spec.whatwg.org/multipage/canvas.html#the-canvas-element)
- [HTML Living Standard: foreign elements](https://html.spec.whatwg.org/multipage/syntax.html#foreign-elements)
- [MathML Core: math element](https://w3c.github.io/mathml-core/#the-top-level-math-element)
- [SVG 2: document structure](https://www.w3.org/TR/SVG2/struct.html)

---

# Chapter 34: How forms send data

Start with the request, then choose the controls.

## Objectives

- Distinguish name from id
- Explain a form request without inventing a backend
- Inspect repeated entries and submitter participation

## Lesson

A form constructs an entry list from eligible controls and submits it according to its action, method and encoding rules. A visible input without a name usually does not contribute the expected name-value entry. An id connects labels and references; it is not the submission key.

GET commonly expresses retrieval by placing the encoded query in the URL. POST sends a request body under the selected encoding. Neither method provides encryption by itself. Use HTTPS for transport protection where appropriate and implement the server's validation, permissions and storage handling.

## Make the simple path work
A search form can submit without JavaScript. Build that path first when the service supports it. Scripts can enhance the experience without becoming the only way to reach the result.

Controls outside a form can be associated through a form attribute when their element supports it. Avoid relying on visual proximity as a submission relationship. Check actual submitted entries, including unchecked controls, disabled fields and the button used to submit. A browser preview without a backend cannot prove a successful application workflow.

## Predict the entry list
For an ordinary named text input, the name becomes the entry key and the current value becomes its value. A disabled control is omitted. An unchecked checkbox or radio button is omitted too; it does not automatically send a false value. A readonly text input can still contribute an entry. Repeated names can produce multiple entries, so do not assume that every form is a one-value-per-key object.

Give the server a deliberate interpretation for missing and repeated entries. Do not trust a disabled field, a hidden field or a client-side constraint to enforce a permission. Someone can construct a request without using your interface.

## Observe entries instead of guessing from the controls
For a form with two checked controls both named `topic`, `new FormData(form).getAll("topic")` reads both entries. Turning the entries into an ordinary one-value object can lose that relationship. Output elements are associated with forms but do not submit their result values merely because they have names.

`new FormData(form, submitButton)` includes that eligible submitter's entry; constructing it without a submitter omits the submit buttons. A `formdata` event is fired while constructing the list, allowing a handler to inspect or amend its FormData. This is not the cancelable `submit` event and does not itself send a request.

A named file input with no selected file still has a defined empty File entry, rather than behaving exactly like an unchecked checkbox. A hidden `_charset_` field has special encoding-value behavior. A supporting text control with `dirname="reader.dir"` can contribute an additional direction entry whose value is `ltr` or `rtl`.

The missing and invalid method defaults are GET; the usual missing or invalid enctype default is application/x-www-form-urlencoded. `method="dialog"` has a different purpose: inside a dialog it can close that dialog rather than send an application request. Chapter 41 compares the submission paths.

The FormData constructor and its entry accessors are defined by the XMLHttpRequest Standard; HTML defines how a form constructs its entries. During native construction, trying to construct another FormData from the same form inside its formdata listener hits the construction guard and throws InvalidStateError. Amend the supplied event.formData instead of starting that construction again.

## Worked example

```html
<form action="catalogue.html" method="get">
  <label for="query">Search the catalogue</label>
  <input id="query" name="q" type="search">
  <button type="submit">Search</button>
</form>
```

The query key is q because that is the name. A real catalogue endpoint must read the query and return results; a static catalogue file does not implement that search service automatically.

## Common mistake

Assuming that giving a control an id is enough to send its value under that key.

## Exercise

Why might a filled input appear on screen but be absent from the submitted entry list? Will new FormData(form) automatically include every submit button?

## Explained answer

It may lack a name, be disabled, be outside the relevant form without an association, or fall under another exclusion rule. Inspect the actual control state and form data rather than the visual layout. No. Buttons are excluded unless the relevant submitter is supplied to entry-list construction. Repeated names remain separate entries; inspect them with getAll when the data model expects several values.

## Sources

- [HTML Living Standard: forms](https://html.spec.whatwg.org/multipage/forms.html#forms)
- [HTML Living Standard: submission](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#form-submission-2)
- [HTML Living Standard: constructing the entry list](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#constructing-form-data-set)
- [HTML Living Standard: form methods and encodings](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#attributes-for-form-submission)
- [XMLHttpRequest Standard: FormData](https://xhr.spec.whatwg.org/#interface-formdata)

---

# Chapter 35: Labels and groups

People should know what to enter before making a mistake.

## Objectives

- Associate visible labels with controls
- Group related choices with a fieldset and legend
- Check form-owner boundaries in radio grouping

## Lesson

A label supplies the visible prompt for a form control. An explicit label uses for to reference the control's id. Nesting an appropriate control inside its label can also establish the association under the defined rules.

A placeholder is not a durable label. It can disappear as soon as someone types and often has poor contrast or confusing wording. Use supporting text for instructions, formatting rules and examples, then connect it with aria-describedby where that relationship helps.

## Group a shared question
fieldset and legend can express a group such as contact preference or membership type. Each radio still needs its own label. Keep the legend short enough that repeated announcements remain manageable.

Do not place essential instructions only in title or in a tooltip that requires a pointer. Write the instructions visibly. If a field is required, communicate that meaning consistently and explain the service's expectations. Required does not mean the requested information is necessary; review the form's data needs before adding fields.

## Association has exact boundaries
An explicit label's `for` must identify a labelable control in the same tree. A hidden input is not labelable. Keep ids unique: a duplicate id can make the browser find the wrong element rather than the intended control. A label must not contain a second unrelated labelable control or another label.

For radio grouping, a shared nonempty name is not the only condition. The radios must also be in the same tree and have the same form owner, or both have no form owner. Two separate forms can each have a `contact` group without making those groups one mutual-exclusion set.

Put the fieldset's legend first. A disabled fieldset disables its descendant controls except those inside its first legend child, subject to any other disabling conditions. Its `form` attribute does not automatically associate every descendant control with that form; controls outside a form need their own applicable association. Check `control.form` rather than assuming a group caption or layout sets the owner.

## Worked example

```html
<fieldset>
  <legend>How should we contact you?</legend>
  <label><input type="radio" name="contact" value="email"> Email</label>
  <label><input type="radio" name="contact" value="phone"> Phone</label>
</fieldset>
```

Here the two radios share the same nonempty name, form owner and tree, which creates the radio group for selection behavior and submission. The legend supplies the common question. Each label names its own option.

## Common mistake

Using two separate names for radio options that should be mutually exclusive.

## Exercise

Why does a legend not remove the need to label each radio button? Are same-named radios in two separate forms necessarily one group?

## Explained answer

The legend names the group question. Each radio still needs to identify its particular answer, such as Email or Phone. The reader needs both pieces of information. No. Their form owners differ. The grouping conditions also include the same tree and a matching nonempty name; common wording on screen is not sufficient.

## Sources

- [HTML Living Standard: labels](https://html.spec.whatwg.org/multipage/forms.html#the-label-element)
- [HTML Living Standard: fieldset](https://html.spec.whatwg.org/multipage/form-elements.html#the-fieldset-element)
- [WAI forms tutorial](https://www.w3.org/WAI/tutorials/forms/)
- [HTML Living Standard: radio group conditions](https://html.spec.whatwg.org/multipage/input.html#radio-button-state-(type=radio))
- [HTML Living Standard: legend](https://html.spec.whatwg.org/multipage/form-elements.html#the-legend-element)

---

# Chapter 36: Text, email and passwords

Choose a state for the data, not just the keyboard.

## Objectives

- Choose a text-related input state
- Distinguish syntax validation from verification
- Distinguish telephone input mechanisms from syntax enforcement

## Lesson

input type="text" is the general single-line text state. email and url have their own syntax and validation behavior. search can supply search-oriented interface behavior. password obscures the displayed value but does not encrypt it, protect it from scripts on the page or secure its eventual storage.

Use autocomplete tokens that describe the field's purpose. An existing-password field and a new-password field are different. Permit password managers and pasting rather than introducing unnecessary obstacles.

## Do not promise more validation than you have
An email input checks its defined syntax, not whether the address belongs to someone or can receive messages. A service that needs ownership verification must implement a separate confirmation process.

inputmode is a hint about input mechanisms, not a data validator. A numeric keyboard hint does not turn a text input into an integer or stop pasted characters. Pick constraints from the service's actual requirements, and keep server-side validation independent from the client interface.

## A telephone or URL is not an arbitrary number
`tel` is a single-line telephone input state with no universal telephone-number syntax constraint. It may offer a telephone-oriented keyboard. An application-specific pattern still needs visible instructions and must not pretend that one local format accepts all international numbers.

A URL-state input checks its defined absolute-URL syntax; it does not prove that a destination is trustworthy or reachable. An email input with `multiple` can accept a comma-separated list under the email-state rules. Neither syntax check verifies ownership, permission or message delivery.

For password-related autocomplete, use `current-password` for an existing credential and `new-password` for a replacement or creation field. Purpose tokens, and any applicable grouping tokens, have a defined order. `autocomplete="off"` is not a promise that every browser will suppress credential assistance.

Text-state values do not automatically trim every space. Email and URL states have their own sanitization rules, and a pasted newline is not the same thing as a multiline textarea. Inspect the resulting value before claiming that a field preserves arbitrary input exactly.

## Worked example

```html
<label for="join-email">Email address</label>
<input id="join-email" name="email" type="email" autocomplete="email"
       aria-describedby="email-help" required>
<p id="email-help">We use this address to contact you about your application.</p>
```

The helper describes this fictional form's intended use. Replace it with the actual service policy before collecting real addresses. The control cannot prove that a user controls the supplied mailbox.

## Common mistake

Calling a password secure because its characters appear as dots, or disabling paste to discourage password managers.

## Exercise

Will type="email" prove that an address can receive your confirmation message? Does type="tel" enforce every international telephone format?

## Explained answer

No. It applies the email state's syntax rules. Message delivery and ownership are application concerns that need their own process and error handling. No. It supplies a telephone-oriented control without a universal syntax validator. Define any service-specific rules visibly and validate them separately on the server.

## Sources

- [HTML Living Standard: input states](https://html.spec.whatwg.org/multipage/input.html#states-of-the-type-attribute)
- [HTML Living Standard: telephone input](https://html.spec.whatwg.org/multipage/input.html#telephone-state-(type=tel))
- [HTML Living Standard: email input](https://html.spec.whatwg.org/multipage/input.html#email-state-(type=email))
- [HTML Living Standard: URL input](https://html.spec.whatwg.org/multipage/input.html#url-state-(type=url))
- [HTML Living Standard: autofill](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#autofill)

---

# Chapter 37: Numbers, dates and colour

A control can normalize a value without deciding what it means.

## Objectives

- Distinguish quantities from numeric-looking identifiers
- Interpret local dates without inventing timezones
- Handle numeric conversion and date-state API boundaries

## Lesson

number fits quantities where numeric operations make sense. Do not use it for every string made of digits. A membership identifier or postal code may need leading zeros, nonnumeric characters or a format that should not change.

min, max and step affect constraints for relevant input states. A range control suits selecting within a range when approximate adjustment is appropriate. Give the value a meaningful visible context; a bare slider can leave readers unsure what they are choosing.

## Dates need a data model
date supplies a date without a timezone. datetime-local supplies a local date and time, also without an offset or timezone identifier. An appointment service needs a clear policy for interpreting that value. The displayed picker can vary across browsers while the submitted value follows defined syntax.

Colour controls and the newer alpha/colorspace attributes need their own implementation review. Do not assume every browser presents the same picker or supports every standardized extension. Keep a usable alternative when exact colour input is important.

## Keep each temporal value in its own unit
`month` represents a year and month, such as `2026-10`; `week` represents an ISO week, such as `2026-W41`; `time` represents a time of day, such as `09:30`. These are not complete global timestamps. Check current picker support and provide visible format guidance rather than assuming every platform supplies the same interaction.

Step units depend on the state: a date uses days, a month uses months, a week uses weeks, and time and datetime-local use seconds. The step base comes from the applicable min, then the value content attribute, then the state's default base; week has a special default base. A valid-looking value can still have stepMismatch if it does not align with that base. `step="any"` removes the step-mismatch constraint where it applies; it is not permission for arbitrary syntax.

`valueAsNumber` returns NaN when no usable number exists, not zero. Its setter rejects infinity with TypeError, and rejects unsupported states with InvalidStateError. Setting NaN clears the applicable input. `valueAsDate` is state-specific too: date-based conversions use their defined UTC conventions, while datetime-local does not support that API. A date's calendar information is not a user's local appointment timezone.

A range control has a default range of 0 to 100 and a sanitized default value near its midpoint. It is not an empty optional number box. Keep its current value visible and label both what the quantity means and its units.

## Name newer colour behavior precisely
In the current Standard, `alpha` is boolean. `colorspace` permits `limited-srgb` and `display-p3`; missing and invalid values select Limited sRGB. Without alpha, serialization makes the color opaque. The state has sanitization rules, including an opaque-black fallback when parsing fails. These are specification rules, not evidence that every tested browser implements the extensions. Do not require a new picker feature without reviewing a usable fallback.

## Worked example

```html
<label for="copies">Number of copies</label>
<input id="copies" name="copies" type="number" min="1" max="5" step="1">
<label for="visit-date">Preferred visit date</label>
<input id="visit-date" name="visitDate" type="date">
```

The quantity has integer steps within a range. The preferred date is not an instant on a global timeline and needs application interpretation before it becomes a scheduled event.

## Common mistake

Using number for a phone number and losing formatting or leading-zero expectations.

## Exercise

Why is a phone number often better represented by type="tel" than type="number"? What does an empty number input return from valueAsNumber?

## Explained answer

A phone number is an identifier with possible leading zeros, plus signs and formatting conventions. It is not a quantity to increment or average. tel can offer a useful input mechanism without pretending to validate every international number. NaN, not zero. Check for it explicitly; also handle the state-specific exceptions and do not interpret a timezone-free date as a scheduled global instant.

## Sources

- [HTML Living Standard: numeric and temporal controls](https://html.spec.whatwg.org/multipage/input.html#states-of-the-type-attribute)
- [HTML Living Standard: month](https://html.spec.whatwg.org/multipage/input.html#month-state-(type=month))
- [HTML Living Standard: week](https://html.spec.whatwg.org/multipage/input.html#week-state-(type=week))
- [HTML Living Standard: time](https://html.spec.whatwg.org/multipage/input.html#time-state-(type=time))
- [HTML Living Standard: number conversion](https://html.spec.whatwg.org/multipage/input.html#dom-input-valueasnumber)
- [HTML Living Standard: date conversion](https://html.spec.whatwg.org/multipage/input.html#dom-input-valueasdate)
- [HTML Living Standard: colour](https://html.spec.whatwg.org/multipage/input.html#color-state-(type=color))

---

# Chapter 38: Choices, files and hidden values

Submission depends on the control state.

## Objectives

- Predict submitted entries for checked controls
- Treat files and hidden values as untrusted input
- Distinguish checked defaults from current state and file-value restrictions

## Lesson

Checkboxes express independent choices. Radios with a shared name express a mutually exclusive selection. A checked checkbox or radio contributes its value under the defined entry-list rules; an unchecked one normally contributes no entry. Plan that absence on the server.

A file input lets a user choose files. accept is a hint to the chooser, not proof that a file is safe or of the declared type. File size, content, storage name and permissions need server-side checks. Do not serve uploaded files as executable content by accident.

## Hidden is not private
A hidden input participates in form submission without an ordinary visible control. Its value remains in the document and can be changed by a visitor. A server must not trust a hidden price, role or authorization decision merely because the page supplied it.

Likewise, readonly and disabled are different states for supporting controls. A readonly text control can still contribute its value; a disabled control is generally excluded from the entry list. Neither state is a substitute for enforcing business rules on the server.

## Predict file and checked-state behavior
If a checked checkbox has no explicit value, its default submission value is `on`, not true. `checked` in markup supplies the default checked state; the current `checked` property can differ after interaction, and `defaultChecked` records the markup default. Resetting a form restores defaults rather than proving that an application has rolled back a server action.

For a file input, read the File objects from `files`; the displayed value is not a usable path to arbitrary files on the visitor's machine. Assigning a nonempty value string programmatically throws InvalidStateError. A script can clear the selection, but cannot use that value setter to choose a private local file.

`multiple` allows more than one file; each selected file contributes an entry under the same name. The extension and File.type are not authoritative proof of the content. Apply server-side size, format, storage and access rules to the actual upload. A readonly attribute is not a valid way to make a file picker immutable; state-specific applicability matters.

## Worked example

```html
<label>
  <input type="checkbox" name="updates" value="yes">
  Email me the reading-group schedule
</label>
<label for="attachment">Supporting document</label>
<input id="attachment" name="attachment" type="file" accept=".pdf">
<input type="hidden" name="formVersion" value="1">
```

The hidden value is a routing hint for the application, not a trusted permission. A surrounding file-upload form needs the appropriate multipart encoding and a real upload handler.

## Common mistake

Expecting an unchecked checkbox to submit the literal value false.

## Exercise

How should a server interpret the absence of an optional updates checkbox? What does a checked checkbox submit when it has no value attribute?

## Explained answer

Apply the documented default for the field, commonly not opted in. Do not infer consent from a missing value. Validate any submitted value as well, since clients can send requests without using the page. Its default value is on. Also, assigning a nonempty filename to a file input value is not a file-selection API; it throws InvalidStateError.

## Sources

- [HTML Living Standard: checkboxes](https://html.spec.whatwg.org/multipage/input.html#checkbox-state-(type=checkbox))
- [HTML Living Standard: file upload](https://html.spec.whatwg.org/multipage/input.html#file-upload-state-(type=file))
- [HTML Living Standard: hidden state](https://html.spec.whatwg.org/multipage/input.html#hidden-state-(type=hidden))
- [HTML Living Standard: input value modes](https://html.spec.whatwg.org/multipage/input.html#dom-input-value)
- [OWASP: file-upload defenses](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html)

---

# Chapter 39: Menus and longer text

Choose the control that fits the number and kind of answers.

## Objectives

- Use select, datalist and textarea intentionally
- Keep a native baseline for newer select customization
- Distinguish selected option content from its label metadata

## Lesson

select represents a choice among option elements, with optgroup available to group related choices. A native select carries behavior that a custom visual menu would otherwise need to recreate. Use a visible label and make any initial prompt consistent with required-selection rules.

textarea is for multiline text. Its initial value comes from its text content, not a value attribute. A datalist can supply suggestions for an associated input, but suggestions do not normally restrict the user to the listed values.

## Customizable selects need extra review
The Living Standard includes selectedcontent and newer customizable-select behavior. Their permitted structure and browser support need separate attention. Keep a conventional select usable as the baseline rather than assuming a decorative demonstration proves full keyboard and assistive-technology support.

multiple changes both the interface and submission expectations for a select. Do not use a multiple list solely to imitate the visual height of a different widget. Explain how to choose and how the service interprets several selected values.

## A placeholder option has a defined position
For the required single-select, display-size-one context used here, the placeholder label option is the first option with an empty value and no intervening optgroup ancestor. Moving the prompt into an optgroup can change whether it meets that rule. A nonempty displayed phrase alone does not establish an allowed submitted value.

Give conventional optgroups a label. The newer model also permits a first-child legend under its rules, but that needs implementation review rather than an assumption that every native picker renders arbitrary group markup. Set explicit option values when the service needs stable keys; otherwise the option's defined text processing supplies the value.

`selected` initializes an option's default selected state. The current selected property can change without rewriting that attribute. In a multiple select, several selected options produce repeated entries under the same name. For a textarea, `defaultValue` comes from its child text, while `value` is the current value and uses normalized LF line breaks. `wrap="hard"` requires cols and can insert submission line breaks; the usual Soft state does not request that hard wrapping.

## Explain selectedcontent, not just its name
In a supported customizable drop-down, the select may start with a button containing `<selectedcontent></selectedcontent>`. The element has no authored children: the browser clones the selected option's child content into it. An option's label attribute is not that cloned content, and the update algorithm does not use this mechanism for a multiple select.

For example, `<select name="shelf"><button><selectedcontent></selectedcontent></button><option value="fiction">Fiction</option><option value="history">History</option></select>` shows the intended structure; add a visible associated label in a complete form. The customizable rendering opt-in also involves CSS. Support cannot be inferred from successfully retaining an unknown element in the DOM. Keep the choice values usable in a conventional native baseline, avoid ids that become duplicate relationships when content is cloned, and test real keyboard and assistive-technology behavior.

## Worked example

```html
<label for="branch">Preferred branch</label>
<select id="branch" name="branch" required>
  <option value="">Choose a branch</option>
  <option value="central">Central</option>
  <option value="east">East</option>
</select>
<label for="request">What would you like to read?</label>
<textarea id="request" name="request" rows="4"></textarea>
```

This is a conventional select baseline. Its empty initial option works with the required single-select context shown here. Check the detailed placeholder-label rules before changing the structure.

## Common mistake

Assuming datalist creates a strict allowed-value list or that textarea uses value like an input.

## Exercise

A field must accept only Central or East. Does an input with datalist enforce that restriction? Does selectedcontent mirror an option label attribute or move its original child nodes?

## Explained answer

No. A datalist provides suggestions. Use a suitable select for this choice and validate the submitted value on the server. A client can send any value regardless of the visible controls. Neither. Its defined update clones the selected option child content, not the label attribute. A retained unknown tag alone is not proof that the browser implements those updates.

## Sources

- [HTML Living Standard: select](https://html.spec.whatwg.org/multipage/form-elements.html#the-select-element)
- [HTML Living Standard: selectedcontent](https://html.spec.whatwg.org/multipage/form-elements.html#the-selectedcontent-element)
- [HTML Living Standard: textarea](https://html.spec.whatwg.org/multipage/form-elements.html#the-textarea-element)
- [HTML Living Standard: options](https://html.spec.whatwg.org/multipage/form-elements.html#the-option-element)
- [HTML Living Standard: option groups](https://html.spec.whatwg.org/multipage/form-elements.html#the-optgroup-element)
- [HTML Living Standard: datalist](https://html.spec.whatwg.org/multipage/form-elements.html#the-datalist-element)

---

# Chapter 40: Validation people can recover from

An error message should help someone finish the task.

## Objectives

- Apply state-specific constraints
- Design and test the correction path
- Choose output, progress and meter without inventing a running service

## Lesson

Native constraints include required, appropriate type rules and state-specific min, max, step, pattern and length restrictions. Their applicability differs by input state. A constraint in the wrong state may do nothing.

Constraint validation helps guide ordinary interaction. It does not secure a request. A server must validate the submitted data, enforce permissions and return useful errors even when JavaScript or browser validation has been bypassed.

## Keep the correction near the field
When application validation finds an error, identify the field and explain how to fix it. Preserve the submitted non-sensitive values when appropriate. Connect useful error text with aria-describedby and update aria-invalid when the application knows the value is invalid. Do not mark a field invalid before there is a reason to do so.

setCustomValidity can add an application message to supporting controls; a nonempty message keeps the control invalid until cleared. A mismatch between custom validity and visible errors can trap someone in a form. Test correction, not just failure. Native error UI varies between browsers, so do not base instructions on one screenshot.

## Know what the constraints actually measure
Pattern matching uses the JavaScript Unicode-sets `v` mode and checks the whole nonempty value, not a substring. Do not include slash delimiters. An invalid pattern has no compiled expression, so testing one successful string is not enough to prove that the intended rule is enforced. `required` handles the otherwise-empty value separately.

Length constraints use the defined API value length, measured in UTF-16 code units rather than user-perceived characters. Their tooShort and tooLong conditions have user-edit and dirty-value requirements; a script assignment is not an equivalent way to test all typing constraints. Test real edits and the correction path.

`checkValidity()` checks applicable constraints and can fire invalid events on failing controls. `reportValidity()` additionally uses the browser's reporting behavior. The invalid event does not bubble like an ordinary input event; a form-level listener can use capture when it needs those events. Keep error messages meaningful instead of promising identical native popup text everywhere.

## Results and gauges are not extra submission fields
`output` represents a calculation or action result. For example, `<output for="copies" name="copyResult">2 copies selected</output>` relates a result to the copies input from Chapter 37. Its for value is a unique-token list of element ids in the same tree, not the label element's one-control rule. An output value is not submitted merely because name is present, and it is barred from constraint validation.

`progress` represents task completion: `<label for="catalogue-progress">Records indexed</label><progress id="catalogue-progress" max="10" value="3">3 of 10</progress>` has a determinate value. Remove value for indeterminate progress. The default maximum is 1; an explicit maximum must be positive, and a determinate value must be within the permitted range.

`meter` is a measurement within a known range, not a task's completion. `<label for="seats">Seats occupied</label><meter id="seats" min="0" max="20" value="12">12 of 20 seats</meter>` expresses a gauge. Its value is required; low, high and optimum are optional range points with ordering constraints. Give a visible value and units where useful, rather than relying on color alone. None of these elements implements a calculation, upload, indexing job or occupancy sensor by itself.

## Worked example

```html
<label for="card-number">Membership number</label>
<input id="card-number" name="cardNumber" inputmode="numeric"
       pattern="[0-9]{6}" aria-describedby="card-format" required>
<p id="card-format">Enter the six digits printed on your card.</p>
```

The pattern applies to this text-state input. inputmode is a keyboard hint. The six-digit rule is fictional teaching policy and needs a matching server-side rule in a real service.

## Common mistake

Adding a pattern without visible formatting guidance, or showing a generic Something went wrong message for a correctable field error.

## Exercise

After setting a custom validity message, a script sees the corrected value. What must it do to let the field become valid? Should seats occupied out of 20 be represented as task progress?

## Explained answer

Clear the custom message with setCustomValidity("") when the custom condition passes. Other native constraints may still apply, so inspect validity rather than assuming clearing one message proves every rule passed. No. That is a bounded measurement suited to meter, not progress. A computed result can use output, but its value is not automatically a submitted form entry.

## Sources

- [HTML Living Standard: constraint validation](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#the-constraint-validation-api)
- [HTML Living Standard: pattern syntax](https://html.spec.whatwg.org/multipage/input.html#attr-input-pattern)
- [HTML Living Standard: length constraints](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#limiting-user-input-length:-the-maxlength-attribute)
- [HTML Living Standard: output](https://html.spec.whatwg.org/multipage/form-elements.html#the-output-element)
- [HTML Living Standard: progress](https://html.spec.whatwg.org/multipage/form-elements.html#the-progress-element)
- [HTML Living Standard: meter](https://html.spec.whatwg.org/multipage/form-elements.html#the-meter-element)

---

# Chapter 41: Submission and server boundaries

A finished form includes what happens after the request.

## Objectives

- Choose an encoding for the actual data
- Separate a static form interface from its service
- Predict submitter exceptions and validation-bypass behavior

## Lesson

Form submission produces an entry list and a request under defined rules. application/x-www-form-urlencoded is the common default encoding. File uploads through a conventional POST form need multipart/form-data. Do not choose text/plain as a general production data format merely because it looks readable.

A submit button can override supported submission attributes for that submission. The button used can also contribute its own name and value. Test these details when one form supports several actions.

## Protect and explain the result
Use server-side validation, appropriate authorization and protections suited to the application, including CSRF defenses where the authentication and request model need them. HTTPS protects transport; it does not decide whether the requester may change a record.

A successful HTTP response is not necessarily a successful business operation. Show whether the application accepted, rejected or queued the action, and explain the next step. Handle retries and duplicate submissions according to the service's data model. Static hosting serves the interface; a working submission service needs a separately implemented handler.

## Choose the submission path deliberately
Calling `form.requestSubmit()` runs the applicable constraint validation and, if submission proceeds, dispatches a `submit` event. Calling `form.submit()` directly bypasses that validation step and does not fire the `submit` event. Do not treat those methods as interchangeable shortcuts. Pass the intended submit button to `requestSubmit()` when its name, value or overrides matter.

For a multipart upload sent with `fetch` and `FormData`, let the browser generate the `Content-Type` boundary rather than hand-writing a bare multipart header. Read the service's expected request format and response contract before adapting a markup-only example. Use fictional data in local demonstrations. GET query values appear in the URL, and switching to POST does not replace HTTPS or careful logging and storage policies.

## Defaults, overrides and exceptions belong in the contract
The accepted authoring value of accept-charset is UTF-8, matched case-insensitively. This is not a menu of legacy encodings to copy into a new form. Submission overrides belong to an eligible submit button; a hidden text field with the same spelling does not override the method or endpoint.

`requestSubmit(submitter)` throws TypeError if the argument is not a submit button and NotFoundError if its form owner is different. Omitting the argument does not select every named button. A control named or identified as submit can also mask the form's submit method through named-property behavior; avoid such collisions rather than silently switching to a validation-bypassing path.

`novalidate` on a form and `formnovalidate` on an applicable submit button skip the interactive validation stage; they do not remove server-side obligations. A canceled submit event prevents that submission, while a formdata handler can amend the entry list. Constructing a FormData object alone sends nothing.

For a dialog form, method="dialog" closes the containing dialog and can set its return value from the submitter instead of issuing the usual request. Keep that separate from a form advertised as saving an application. For real native requests, inspect the method, target, encoded entries and response; an ordinary local fixture is evidence of browser behavior, not a deployed business service.

## Worked example

```html
<form action="/applications" method="post" enctype="multipart/form-data">
  <label for="proof">Address document</label>
  <input id="proof" name="proof" type="file" required>
  <button type="submit" name="action" value="apply">Send application</button>
</form>
```

The endpoint is illustrative and is not implemented by this static book. A real service needs a handler, storage rules, privacy information and testable success and failure states.

## Common mistake

Claiming a contact or application form works because the browser renders the fields and button.

## Exercise

What else is required before this form can be advertised as accepting real applications? What happens if requestSubmit receives a submit button owned by another form?

## Explained answer

A working endpoint, validated and authorized handling, appropriate upload limits and storage controls, a clear privacy policy, and tested user-visible results for success, error and retry cases. Confirm deployment and transport behavior too. It throws NotFoundError. A non-submit button produces TypeError. Handle the intended form/submitter relationship rather than treating either method as a generic submit shortcut.

## Sources

- [HTML Living Standard: form submission](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#form-submission-2)
- [HTML Living Standard: constructing the entry list](https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#constructing-form-data-set)
- [HTML Living Standard: the form element and its methods](https://html.spec.whatwg.org/multipage/forms.html#the-form-element)
- [MDN: using FormData objects](https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest_API/Using_FormData_Objects)
- [OWASP: file-upload defenses](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html)
- [OWASP: CSRF prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross-Site_Request_Forgery_Prevention_Cheat_Sheet.html)

---

# Batch 04: revised Chapters 42 to 53

Author: Odejobi Abiola Samuel | CTROTECH
Review date: 15 October 2026

Candidate first pass only. No independent approval or closed final gates. Website and reading PDF use these maintained chapter inputs. Terms are introduced in the lesson prose and the publication glossary.

## Chapter 42: Buttons and commands

### Objectives

- Choose a button type deliberately
- Distinguish actions from persistent toggles
- Distinguish reset defaults from clearing and image-button payloads

### Prerequisites

- CH-41

### Lesson

Use button for an action. Give it a clear name and choose type deliberately. A button associated with a form can submit by default in relevant states, so write type="button" for a local interface action and type="submit" for an intended submission.

A toggle button needs a represented state when the interaction is a persistent toggle. aria-pressed is appropriate for that pattern, not for every button that can be clicked. Keep the state synchronized with the result.

## Prefer a native action when it fits
The Standard includes command and commandfor for invoker commands, including relationships to dialogs and popovers under their defined rules. This can reduce script, but each command and target needs current compatibility review. Custom command names and their handling do not become application behavior automatically.

Avoid nesting another interactive control inside a button. An icon can accompany text, but a tooltip should not be the only way to discover an otherwise unnamed action. Disabled buttons are also a communication decision: if someone needs to know why they cannot continue, provide that explanation outside the unavailable control.

## Defaults are contextual, not a slogan
For button, missing or invalid type selects the Auto state. A button in that state is a submit button when neither command nor commandfor is present and its parent is not select. An explicit type="submit" is also a submit button. An invoker inside a form should deliberately use type="button"; suppressing default submission with command attributes is not the same as implementing the intended action.

The built-in command keywords are toggle-popover, show-popover, hide-popover, close, request-close and show-modal. commandfor names a target id in the same tree. A custom keyword starts with two hyphens, such as `--pin`; it dispatches a command event rather than saving a pinned item automatically. The event exposes its command and source. Test implementation and cancellation before replacing a compatible scripted path.

## Four input button states have different payloads
`<input type="submit" value="Send">` is a submit control, while reset restores defaults and button has no default action. A reset event can be canceled. Resetting a form does not reverse a server transaction or necessarily clear every custom application message.

An image submit control uses src for its image and alt for its purpose. Its activated coordinates contribute entries such as `apply.x` and `apply.y` for name="apply", not an ordinary value under apply. Image buttons are also a historical exception to the form.elements collection. Prefer an ordinary text button when an image adds no useful information.

### Primary example

```html
<form action="catalogue.html" method="get">
  <label for="button-query">Book title</label>
  <input id="button-query" name="q" type="search">
  <button type="submit">Find books</button>
  <button type="reset">Restore search defaults</button>
</form>
```

The submit button requests submission; the reset button restores the controls to their defaults, which are empty here. Reset is not a general erase or server-undo operation. The static catalogue filename does not implement a search service.

### Common mistake

Leaving a local interaction button without a type inside a form, then being surprised by submission.

### Exercise

Does a button that opens a dialog always need aria-pressed? Does reset necessarily erase every value?

### Explained answer

No. aria-pressed represents a toggle-button state. A dialog opener is not automatically a toggle button. Give it an appropriate name and implement the dialog interaction and focus behavior correctly. No. It restores defaults; a nonempty default returns. An image submitter also has coordinate entries rather than the ordinary name/value payload of a text submit button.

### Sources

- [HTML Living Standard: button](https://html.spec.whatwg.org/multipage/form-elements.html#the-button-element)
- [HTML Living Standard: input submit](https://html.spec.whatwg.org/multipage/input.html#submit-button-state-(type=submit))
- [HTML Living Standard: image submit](https://html.spec.whatwg.org/multipage/input.html#image-button-state-(type=image))
- [HTML Living Standard: reset](https://html.spec.whatwg.org/multipage/input.html#reset-button-state-(type=reset))
- [HTML Living Standard: plain button](https://html.spec.whatwg.org/multipage/input.html#button-state-(type=button))

## Chapter 43: Disclosure with details

### Objectives

- Use a native disclosure
- Control a boolean open state correctly
- Apply same-tree exclusive-group constraints

### Prerequisites

- CH-42

### Lesson

details represents a disclosure. Its first summary supplies the label. The open attribute controls whether the contents are shown. This is a boolean attribute, so open="false" is still open.

A disclosure suits supplementary information that can reasonably remain collapsed. Do not hide the only instruction someone needs to complete a required field or understand a price behind an obscure label.

## Keep the summary useful
Write the summary as a question or a short description of the hidden information. Clicking it and keyboard activation should work without your own click handler. Avoid putting competing interactive controls in a summary without a specific reviewed reason.

The name attribute can associate details elements in an exclusive group under its defined behavior. Compatibility still matters. A group of disclosures is not automatically a tab interface or a full application accordion with every optional keyboard interaction from another pattern.

Test the disclosure with a keyboard and inspect whether its content is understandable when expanded. If you add animation, respect reduced-motion preferences and avoid delaying access to the actual information.

## Exclusive groups have authoring rules
A details name group uses the same nonempty name in the same tree. Its members need not be adjacent, although keeping related disclosures together makes their relationship easier to understand. At most one member may have open, and a member must not contain another member of that same group. Browser enforcement does not make misleading initial markup conforming.

Opening a second member closes the first. That may frustrate someone comparing both answers, so use exclusivity only when it fits the task. A native details group does not promise the arrow-key interactions of every custom accordion pattern.

Place summary first in the details content model. The first summary child is the disclosure control; adding several summaries does not create several independent controls. Toggle notifications are queued and can be coalesced after rapid changes. Do not treat each attribute mutation as a guaranteed separate user action.

### Primary example

```html
<details>
  <summary>Can I renew a borrowed book?</summary>
  <p>Ask the desk before the due date. Some collections have separate rules.</p>
</details>
```

The summary remains the control. The paragraph is ordinary document content when the disclosure is open. The library rule is an illustrative example, not a real lending policy.

### Common mistake

Adding role="button" and a second keyboard listener to a summary, creating duplicate or conflicting behavior.

### Exercise

How do you make this disclosure initially expanded, and how do you make it initially collapsed? May two same-named members both be authored open, or nested in that same group?

### Explained answer

Add open to details for an initially expanded disclosure. Omit open for the collapsed state. The string false is not a way to turn off the boolean attribute. No. Both arrangements violate the group authoring rules, even if a browser repairs their eventual open state.

### Sources

- [HTML Living Standard: details and summary](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-details-element)
- [HTML Living Standard: summary](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-summary-element)

## Chapter 44: Dialogs and popovers

### Objectives

- Distinguish modal dialog and popover behavior
- Provide a keyboard-usable close path
- Distinguish cancelable close requests and popover defaults

### Prerequisites

- CH-43

### Lesson

A dialog can be shown modally with showModal or non-modally with show. A modal dialog changes interaction with the rest of the page. Opening it requires an intentional focus destination, a usable close path and sensible focus restoration when it closes.

Writing open in source displays a dialog in its non-modal open state; it does not reproduce every part of showModal. Use the dialog API or an appropriately supported invoker relationship for the intended behavior.

## A popover is not automatically a dialog
popover controls display and dismissal behavior for a popover element. It does not assign the semantics of a menu, dialog or tooltip. Choose markup and accessibility behavior for the actual content. The auto, manual and newer hint behaviors need their own defined handling and compatibility review.

closedby and declarative commands are newer parts of this area. Keep a compatible close mechanism and test Escape, focus, pointer dismissal and small-screen scrolling. Avoid using a modal merely to deliver a short message that could be shown in the page.

## Inspect the whole interaction
A modal dialog opened with `showModal()` makes the surrounding document inert under the defined modal-dialog rules. A popover does not make the rest of the document inert merely by being open. Neither feature supplies an appropriate accessible name for your content automatically. Give a dialog a meaningful name, choose its initial focus from the task and verify that closing leaves focus somewhere useful.

In the example, a valid form submission with `method="dialog"` closes its containing dialog rather than sending a network request. The activated submit button can supply the dialog's return value. That is a local interaction result, not confirmation that a server has saved anything.

## Closing and requesting closure are different
close() closes an open dialog and can set its returnValue. requestClose() first fires a cancel event; preventDefault can reject that request. If it proceeds, closure also fires close. Calling requestClose ignores closedby="none"; that attribute configures the relevant user dismissal actions, not a veto on every script operation.

closedby accepts any, closerequest and none. Missing or invalid values select Auto, which behaves as Close Request for a modal dialog and None otherwise. Keep a usable close control and do not rely only on a newer light-dismiss affordance.

showModal throws InvalidStateError when the dialog is already open non-modally, while show throws when it is already modal. Use the intended lifecycle instead of manually removing open: that can skip close events and leave the document's modal blocking state wrong. Do not add tabindex to dialog; choose an appropriate autofocus destination under the dialog rules.

## Popover defaults are not boolean defaults
Missing popover means no popover; an empty value means Auto; an invalid value means Manual. Manual popovers do not light-dismiss like auto popovers. Hint has its own stack behavior and must be tested separately. Neither state gives the content a menu or dialog role.

beforetoggle can cancel opening under the defined rules, while toggle reports state changes through queued notifications. showPopover on a non-popover throws NotSupportedError; disconnected or otherwise invalid state can produce InvalidStateError. A working supported invoker has its own target/action relationship; storing those attributes alone does not prove the behavior.

### Primary example

```html
<button type="button" id="open-help">Membership help</button>
<dialog id="help-dialog" aria-labelledby="help-title">
  <h2 id="help-title">Membership help</h2>
  <p>Ask at the desk if you cannot supply an address document.</p>
  <form method="dialog"><button type="submit" autofocus>Close help</button></form>
</dialog>
<script>
  const help = document.getElementById("help-dialog");
  document.getElementById("open-help").addEventListener("click", () => {
    help.showModal();
  });
</script>
<button type="button" popovertarget="reading-tip">Reading tip</button>
<div id="reading-tip" popover>
  <h2>A note about renewals</h2>
  <p>This is a fictional teaching note, not a real lending policy.</p>
  <button type="button" popovertarget="reading-tip"
          popovertargetaction="hide">Dismiss reading tip</button>
</div>
```

The close button submits the method="dialog" form, closing the dialog rather than posting to a server. Test the actual focus behavior and decide whether a more specific initial focus target is needed for longer content. The short help dialog puts initial focus on its close control. The separate note uses an auto popover with an explicit dismiss button, not a modal dialog or menu. Test support and actual focus restoration.

### Common mistake

Assuming that adding the popover attribute supplies menu keyboard navigation or a dialog role.

### Exercise

Why is toggling the dialog open attribute not equivalent to calling showModal? Will closedby="none" prevent a script from calling requestClose?

### Explained answer

showModal establishes modal behavior, including its relationship with the top layer and the rest of the page. The open attribute alone shows an open dialog without that same modal operation. No. The method still requests closure and fires cancel. A canceled request can keep the dialog open; the attribute is not a general script-access restriction.

### Sources

- [HTML Living Standard: dialog](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-dialog-element)
- [HTML Living Standard: popovers](https://html.spec.whatwg.org/multipage/popover.html#the-popover-attribute)

## Chapter 45: Focus, editing and dragging

### Objectives

- Explain sequential and programmatic focus
- Provide a non-drag path for important actions
- Test actual reordering and focus rather than a decorative button

### Prerequisites

- CH-44

### Lesson

Focusable and sequentially focusable are related but distinct. tabindex="0" can place an otherwise suitable element in sequential focus order. tabindex="-1" commonly allows programmatic focus without adding an ordinary tab stop. Positive tabindex values create a separate ordering problem and are usually best avoided.

contenteditable enables editing under its defined states. It does not provide a complete rich-text editor, accessible toolbar, sanitation pipeline or save system. Editing behavior and supported input methods need real-device testing.

## Offer alternatives to dragging
draggable participates in the drag-and-drop model. A drag gesture should not be the only way to perform an important operation. Provide buttons or another keyboard-usable mechanism for moving an item, and keep the outcome understandable.

Use focus to support a task, not to surprise someone whenever content changes. When removing a focused item, decide where focus goes next. Avoid trapping focus in a non-modal widget. Mobile input, speech control and assistive technology can expose assumptions that mouse-only testing misses.

## Editing and dragging use enumerated states
contenteditable accepts true, an empty true value, false and plaintext-only; missing or invalid values inherit. isContentEditable reports the resulting editing condition, not merely the stored attribute spelling. Plaintext-only is not an HTML sanitizer or a persistent storage service.

draggable is enumerated, not boolean. Its true and false values differ from missing or invalid Auto, under which images, links and selections have their own default drag behavior. Do not write draggable="false" and assume it follows the boolean-attribute rule from disabled.

During drag-and-drop, DataTransfer has mode and phase restrictions. Write the intended data during dragstart, allow an intended drop through the relevant dragover handling, and read/validate the data in the allowed drop phase. Treat incoming text or HTML as untrusted. A synthetic DragEvent or constructed DataTransfer is not proof that native pointer, touch or assistive-technology dragging works.

The reordering controls are both a keyboard path and a single-pointer non-drag path. Those are separate accessibility considerations: keyboard operation alone is not the entire dragging-movements requirement. Test the actual pointer and keyboard controls, focus after a move and the readable result.

### Primary example

```html
<section aria-labelledby="list-title">
  <h2 id="list-title" tabindex="-1">Your fictional reading list</h2>
  <ol id="reading-list">
    <li tabindex="-1"><span>Local histories</span>
      <button type="button" data-shift="-1" disabled>Move up</button>
      <button type="button" data-shift="1" disabled>Move down</button></li>
    <li tabindex="-1"><span>Poetry</span>
      <button type="button" data-shift="-1" disabled>Move up</button>
      <button type="button" data-shift="1" disabled>Move down</button></li>
    <li tabindex="-1"><span>Fiction</span>
      <button type="button" data-shift="-1" disabled>Move up</button>
      <button type="button" data-shift="1" disabled>Move down</button></li>
  </ol>
  <p id="move-status" role="status">Changes stay in this page only.</p>
</section>
<script>
  const list = document.getElementById("reading-list");
  const status = document.getElementById("move-status");
  function updateMoves() {
    [...list.children].forEach((item, index, items) => {
      const title = item.querySelector("span").textContent;
      item.querySelectorAll("button").forEach(button => {
        const up = button.dataset.shift === "-1";
        button.disabled = up ? index === 0 : index === items.length - 1;
        button.setAttribute("aria-label", (up ? "Move up: " : "Move down: ") + title);
      });
    });
  }
  list.addEventListener("click", event => {
    const button = event.target.closest("button[data-shift]");
    if (!button || button.disabled) return;
    const item = button.closest("li");
    const shift = Number(button.dataset.shift);
    if (shift !== -1 && shift !== 1) return;
    const peer = shift === -1 ? item.previousElementSibling : item.nextElementSibling;
    if (!peer) return;
    list.insertBefore(item, shift === -1 ? peer : peer.nextElementSibling);
    updateMoves();
    item.focus();
    status.textContent = item.querySelector("span").textContent + " moved " +
      (shift === -1 ? "up." : "down.");
  });
  updateMoves();
</script>
```

The controls now perform real local reordering. Boundary controls are disabled; focus goes to the moved item and visible status text explains the result. Controls begin disabled so a script failure does not leave apparently working actions. The list is not saved to a backend, and a status element is not proof of screen-reader announcements.

### Common mistake

Adding tabindex="0" to every paragraph and wrapper, making keyboard navigation unnecessarily long.

### Exercise

An item can only be moved by dragging. What should you add before treating the interaction as broadly usable? Does a keyboard-only drag alternative necessarily cover every single-pointer non-drag requirement?

### Explained answer

Provide an operable non-drag mechanism, such as Move up and Move down controls, then implement focus management and meaningful feedback for the result. Test with a keyboard and the actual input methods you support. No. Review both input paths. The example provides clickable buttons as well as keyboard activation, performs the move and leaves an inspectable focus and status result.

### Sources

- [HTML Living Standard: focus](https://html.spec.whatwg.org/multipage/interaction.html#focus)
- [HTML Living Standard: drag and drop](https://html.spec.whatwg.org/multipage/dnd.html#dnd)
- [HTML Living Standard: editing states](https://html.spec.whatwg.org/multipage/interaction.html#contenteditable)
- [HTML Living Standard: draggable](https://html.spec.whatwg.org/multipage/dnd.html#the-draggable-attribute)
- [WCAG: dragging movements](https://www.w3.org/WAI/WCAG22/Understanding/dragging-movements.html)

## Chapter 46: Templates and component boundaries

### Objectives

- Clone inert template content
- Distinguish templates, slots and custom-element registration
- Distinguish slot assignment from moving nodes and root security

### Prerequisites

- CH-45

### Lesson

template holds inert template contents that a script can clone and insert. Its content is a DocumentFragment. Querying the template element's ordinary descendants is not the same as querying its content fragment.

slot is a placeholder within a shadow tree for assigned content. The slot attribute on an element identifies the named slot it should be assigned to under the relevant rules. This attribute is different from a slot element.

## Separate the pieces of a component
Autonomous custom elements use valid custom-element names, including the required hyphen and other naming restrictions, and are defined through the custom-elements machinery. A custom tag name alone does not register a working component. Customized built-in elements have separate is behavior and implementation considerations.

Declarative shadow DOM uses supported template shadowroot attributes to establish a shadow root during parsing under defined conditions. The evolving set includes mode, focus, cloning, serialization and registry-related controls. Review each independently. A shadow boundary is not a security sandbox or an excuse to ignore accessible names and keyboard behavior.

## A shadow root is created under parsing rules
A supported parser can consume `<template shadowrootmode="open"><slot name="heading"></slot><slot></slot></template>` inside an eligible host. A light-DOM child such as `<h2 slot="heading">Library notice</h2>` can be assigned to that named slot. The host still owns that light-DOM child: slotting does not move it into the shadow tree. Unassigned slots display their fallback content.

shadowrootmode permits open and closed; missing or invalid means no declarative shadow root. delegates-focus, cloning and serialization are controlled by their respective boolean shadowroot attributes, not by arbitrary strings such as false. shadowrootslotassignment permits named or manual, with Named as its missing and invalid default. The registry-related attribute needs its own scoped-registry review and fallback; presence in the Standard is not universal implementation evidence.

Ordinary innerHTML insertion does not generally consume declarative shadow templates as the document parser does. Use a suitable parsing API only after reviewing its injection and sanitization contract. A closed root changes ordinary lookup access; it does not protect against all same-page code, including code that retains a root reference.

The current Standard also defines template for-based streaming content updates with processing-instruction markers. That newer mechanism is part of the open feature reconciliation, not silently covered by cloneNode in this introductory example.

## Registration and assignment have separate APIs
Defining the same custom-element name twice produces NotSupportedError, and an invalid name produces SyntaxError under the registration rules. A constructor being valid JavaScript is not enough to satisfy custom-element construction requirements. whenDefined concerns registry definition, not proof that every instance is rendered, upgraded successfully or accessible.

slotchange concerns changes to assignment, not every text edit within an already assigned node. Test assignedNodes or assignedElements for the relevant slot and keep a visible fallback where useful.

### Primary example

```html
<template id="book-template">
  <article class="book">
    <h2></h2>
    <p></p>
  </article>
</template>
<div id="book-results"></div>
<script>
  const template = document.getElementById("book-template");
  const card = template.content.cloneNode(true);
  card.querySelector("h2").textContent = "Local histories";
  card.querySelector("p").textContent = "A collection of neighbourhood stories.";
  document.getElementById("book-results").append(card);
</script>
```

The example clones template content and inserts plain text into it. This is a template example, not a registered custom element or a shadow tree.

### Common mistake

Treating a shadow root as protection against hostile same-page code, or treating a template string as safely sanitized HTML.

### Exercise

Why does the script use template.content rather than expecting the article to be a normal child rendered in the page? Does a named slot transfer ownership of a light-DOM child into the shadow tree?

### Explained answer

Template contents are held in a separate fragment and are not rendered as ordinary template children. Clone that fragment, fill it safely and insert it where the page should display it. No. The child remains in light DOM and is assigned for presentation. Neither slotting nor a closed root is a general security sandbox.

### Sources

- [HTML Living Standard: template](https://html.spec.whatwg.org/multipage/scripting.html#the-template-element)
- [HTML Living Standard: custom elements](https://html.spec.whatwg.org/multipage/custom-elements.html#custom-elements)
- [HTML Living Standard: slot](https://html.spec.whatwg.org/multipage/scripting.html#the-slot-element)
- [DOM Standard: shadow trees](https://dom.spec.whatwg.org/#shadow-trees)

## Chapter 47: Custom data and structured data

### Objectives

- Read custom data with explicit type handling
- Distinguish page-specific data from public structured annotations
- Validate dataset values and distinguish assignments from deletion

### Prerequisites

- CH-46

### Lesson

data-* attributes store page-specific data where no more appropriate attribute fits. Scripts can access them through dataset with the defined name conversion. Values are strings; a value such as "false" is not automatically a false boolean.

Custom data is visible in the document. Do not place credentials or trusted authorization decisions there. A visitor can inspect and change it. Do not use a data attribute as a substitute for a real href, label or disabled state when the platform already defines one.

## Microdata serves a different purpose
itemscope, itemtype, itemprop, itemid and itemref participate in microdata. A vocabulary supplies meaning to properties; arbitrary names do not create a recognized public schema. Search and other consumers have their own supported formats and policies.

Keep visible content and structured annotations consistent. Do not claim that adding structured data guarantees a search result treatment. Choose a supported vocabulary and validate both its syntax and the content it represents using the relevant consumer's current documentation.

## Conversion and deletion have defined rules
A dash followed by an ASCII lowercase letter becomes an uppercase letter in dataset: data-book-id becomes bookId. Other permitted characters are not all transformed by that same rule. Assigning null writes the string "null"; delete removes an entry. Assigning through a key with a dash followed by an ASCII lowercase letter, such as dataset["loan-days"], throws SyntaxError rather than acting like dataset.loanDays.

A test with `in` can see properties on a prototype as well as this map's own entries. Use a suitable own-property check where that distinction matters. Convert only the format the application actually accepts; Number("") becoming zero is not proof that an empty quantity is valid.

## Microdata needs a real item model
itemscope starts an item, itemtype identifies vocabulary types, and itemprop names properties. itemid supplies a global item identifier under the vocabulary and authoring rules; itemref can refer to additional property-bearing elements by id in the same tree. It is not a general DOM ownership or permission relationship.

A Book item can use name for its visible title and an author property containing a nested Person item with its own name. Do not invent a credential, review or affiliation simply to fill a structured-data property. Element-specific value rules matter: meta uses content, time can use datetime, and URL-bearing elements have their own value extraction. A parsed graph alone does not guarantee a search treatment.

### Primary example

```html
<article id="book-record" data-book-id="LIB-204" data-copy-count="3">
  <h2>Local histories</h2>
  <p id="copy-note">This is a fictional record.</p>
</article>
<script>
  const record = document.getElementById("book-record");
  const rawCount = record.dataset.copyCount;
  const count = Number(rawCount);
  const valid = /^[0-9]+$/.test(rawCount) && Number.isSafeInteger(count);
  document.getElementById("copy-note").textContent = valid
    ? count + " copies listed in this fictional record."
    : "No usable quantity in this fictional record.";
</script>
```

The record now demonstrates string-to-number validation and a real text update instead of an unimplemented Save button. It deliberately rejects malformed or unsafe numeric values and never treats this local record as an authorization decision or real stock availability.

### Common mistake

Adding data-disabled="true" and expecting native disabled behavior.

### Exercise

What JavaScript type do you get from element.dataset.count when the source has data-count="3"? What does assigning null to a dataset entry do?

### Explained answer

You get the string "3". Convert and validate it deliberately if your application needs a number. Do not trust the value merely because it appeared in your own initial markup. It stores the string "null". Use delete to remove the entry, and validate any parsed value deliberately rather than treating stored strings as trusted typed data.

### Sources

- [HTML Living Standard: custom data](https://html.spec.whatwg.org/multipage/dom.html#embedding-custom-non-visible-data-with-the-data-*-attributes)
- [HTML Living Standard: microdata](https://html.spec.whatwg.org/multipage/microdata.html#microdata)
- [Schema.org: Book vocabulary](https://schema.org/Book)

## Chapter 48: Global attributes in context

### Objectives

- Apply global attributes with their own constraints
- Keep id relationships unique and meaningful
- Distinguish hidden rendering from form eligibility and selector syntax

### Prerequisites

- CH-47

### Lesson

The global attributes section lists attributes common to HTML elements. DOM also owns requirements for id, class and slot. Other attributes and families integrate specifications such as ARIA and CSS Shadow Parts. Keep ownership and namespace boundaries clear.

An id must satisfy its defined authoring constraints and be unique among ids in the element's tree. class is a set of tokens. title supplies advisory information, but it is not a dependable sole label or instruction because exposure varies with device and interaction.

## Hidden and inert differ
hidden participates in rendering and relevance rules, including its until-found state in supporting implementations. inert prevents interaction and affects focus and accessibility exposure under its rules. Neither is simply a synonym for a CSS property.

Use lang and dir for their own meanings. accesskey can conflict with browser, operating-system or assistive-technology commands, so do not invent a keyboard shortcut scheme casually. Newer autocorrect, writingsuggestions and heading-level attributes need compatibility review. The reference keeps them visible rather than silently dropping them because they are unfamiliar.

## Rendering, interaction and serialization differ
hidden is enumerated: missing means Not Hidden, empty or invalid means Hidden, and until-found has its own discovery behavior. Supported fragment navigation or find-in-page can reveal until-found content and fire beforematch. Its layout and CSS conditions matter; do not force display:none and expect the same discovery path.

CSS can override ordinary hidden rendering. More importantly, hidden content can still contain scripts or eligible form controls; hiding is not disabling, withholding a secret or revoking a permission. inert acts on the relevant interaction/focus subtree. A modal dialog has a defined inertness escape under its own rules, so do not generalize that exception to every nested widget.

An id must be nonempty and contain no ASCII whitespace. It is not limited to alphanumeric characters: reader:name can be a valid id, while a CSS selector referring to it needs suitable escaping. getElementById does not parse its argument as a CSS selector. Keep relationship references unique within their actual tree.

## Hints retain their own keywords
translate uses yes or an empty value for Yes and no for No; omission or invalid values use inheritance. spellcheck uses true/empty, false and its defined default behavior, not a blanket boolean presence rule. autocapitalize offers off/none, on/sentences, words and characters. autocorrect uses on and off. writingsuggestions has true/false and default behavior. These affect eligible editing behavior and do not validate the field or promise an identical keyboard.

enterkeyhint includes enter, done, go, next, previous, search and send; inputmode has its separate input-mechanism hints. Neither causes a server submission just because a key's label suggests one. accesskey uses its defined single-character token rules and platform modifier behavior; avoid conflicts and do not claim that it is a universal shortcut.

## Styling hooks cross a separate specification boundary
part names exposed shadow parts; exportparts forwards named parts through another component boundary. A part="badge" can be styled through a supported ::part(badge) selector on the host. These are CSS Shadow Parts hooks, not data-* names or permission grants. Review CSS ownership and implementation separately.

### Primary example

```html
<section id="renewal" class="notice compact" lang="en">
  <h2>Renew your membership</h2>
  <p>Use the same name as your current library card.</p>
</section>
```

id is a stable reference target. The two classes are separate tokens, not two independent class attributes. The section's language is explicit here even though it may already inherit English from html.

### Common mistake

Relying on title as the only label for an icon-only control or the only explanation of a field error.

### Exercise

Can two unrelated controls safely share an id just because they are on different visual panels? Does hiding a form control necessarily remove its submitted entry?

### Explained answer

Not within the same element tree. Visual separation does not establish a new id scope. Use unique ids and update all for, fragment and ARIA references consistently. No. Hidden rendering and entry-list eligibility are different. A valid id with punctuation can also need CSS escaping even though getElementById can use that id directly.

### Sources

- [HTML Living Standard: global attributes](https://html.spec.whatwg.org/multipage/dom.html#global-attributes)
- [HTML Living Standard: hidden](https://html.spec.whatwg.org/multipage/interaction.html#the-hidden-attribute)
- [HTML Living Standard: inert](https://html.spec.whatwg.org/multipage/interaction.html#the-inert-attribute)
- [HTML Living Standard: spelling](https://html.spec.whatwg.org/multipage/interaction.html#attr-spellcheck)
- [HTML Living Standard: capitalization](https://html.spec.whatwg.org/multipage/interaction.html#attr-autocapitalize)
- [HTML Living Standard: autocorrection](https://html.spec.whatwg.org/multipage/interaction.html#attr-autocorrect)
- [HTML Living Standard: writing suggestions](https://html.spec.whatwg.org/multipage/interaction.html#attr-writingsuggestions)
- [HTML Living Standard: enter key hints](https://html.spec.whatwg.org/multipage/interaction.html#attr-enterkeyhint)
- [CSS Shadow Parts specification](https://drafts.csswg.org/css-shadow-parts/)

## Chapter 49: Element-specific attributes

### Objectives

- Interpret attributes in element and state context
- Distinguish stored markup from implemented behavior
- Treat index rows as navigation and handler cancellation as event-specific

### Prerequisites

- CH-48

### Lesson

An attribute name is not a complete definition. type means different things on input, button, script and other elements. value differs between a text input, an option and a progress element. Read the element and state alongside the name.

The reference retains contextual rows rather than merging everything into one alphabetical name list. An input's type can determine whether min, maxlength or another constraint applies. A parser accepting an attribute does not make the use conforming or effective.

## Check the default as well as the explicit value
Missing-value defaults and invalid-value defaults can differ. Enumerated attributes have defined keywords and states. Boolean attributes depend on presence. Token lists have their own constraints. When a script reflects an attribute through a property, the property can normalize or interpret it rather than exposing the raw source string.

For a new attribute, verify its canonical definition, supported elements, permitted values, side effects and implementation data. Preserve compatibility notes and fallback behavior. Do not infer support merely because getAttribute returns the text you set; the DOM can store unknown attributes too.

## An index is a route to the definition
The attribute index is a navigation aid, not the entire normative contract. Follow each context's definition for value syntax, applicable states, side effects and exceptions. A shared spelling does not merge input, option and progress values into one behavior.

Event-handler attributes such as onclick integrate JavaScript handler processing. They are not boolean switches. Assigning a function to an onclick property differs from storing text in an inline attribute, and returning false from an addEventListener callback is not a replacement for preventDefault. Follow the applicable event's cancellation rules and CSP restrictions.

Nonce handling is a further warning against a generic getAttribute-based support detector: a connected nonce-bearing element can have an empty content attribute while its nonce property exposes the internal nonce. Chapter 53 shows the distinction. API reflection, parsing and behavior remain separate checks.

### Primary example

```html
<label for="age-years">Age in years</label>
<input id="age-years" name="age" type="number" min="0" max="120">
<label for="reader-name">Reader name</label>
<input id="reader-name" name="readerName" type="text" maxlength="100">
```

The numeric bounds suit the number state. The text length constraint suits the text state. These are illustrative service limits, not universal requirements for personal data.

### Common mistake

Adding maxlength to a number input and assuming it enforces the number of digits.

### Exercise

Why does reading an unfamiliar attribute with getAttribute fail to prove native support? Does returning false from every addEventListener callback cancel the browser action?

### Explained answer

getAttribute reads stored attribute text. It does not demonstrate that the browser implements the attribute's specified behavior. Test the behavior and consult dated implementation evidence. No. Use the event cancellation mechanism where the event is cancelable. Inline-handler processing and addEventListener are not interchangeable conventions.

### Sources

- [HTML Living Standard: attribute index](https://html.spec.whatwg.org/multipage/indices.html#attributes-3)
- [HTML Living Standard: input applicability](https://html.spec.whatwg.org/multipage/input.html#input-type-attr-summary)
- [HTML Living Standard: event handlers](https://html.spec.whatwg.org/multipage/webappapis.html#event-handlers)

## Chapter 50: Metadata readers encounter

### Objectives

- Write a specific document title
- Describe metadata without search-result guarantees
- Keep metadata consistent with visible content and base authoring

### Prerequisites

- CH-49

### Lesson

title identifies the document in browser UI and other contexts. Make it specific enough to distinguish this page from the rest of the site. A visible h1 and the document title have related but separate jobs.

meta can declare encoding or named metadata. A description is useful page-summary metadata, but its presence does not guarantee that a search engine will display it. Do not promise rankings from a tag.

## Keep head deliberate
Use link for supported resource relationships such as stylesheets and icons. A favicon is not the same as a visible logo. style holds embedded CSS when permitted. base changes URL resolution and target defaults, so use it only when you understand the effects on every relative reference.

Metadata names and link types have defined or registered meanings. Do not invent a plausible name and assume a consumer understands it. Social sharing formats also need their own current documentation. Keep canonical URLs accurate, and avoid adding several conflicting declarations through independently configured tools.

## One mechanism does not impersonate every response header
Choose the appropriate meta form: encoding, named metadata or a defined pragma. http-equiv is not an arbitrary way to set every HTTP response header. A meta-delivered CSP has important limitations, including directives that require response-header delivery; it is not identical to a header policy. Automatic refresh also has navigation and accessibility consequences.

A document has at most one base, with href, target or both. Put its href before other URL-bearing elements and its target before relevant hyperlinks. Browser handling that ignores later duplicate bases does not authorize duplicate authoring. An explicit link target can override the default target, while a fragment-only URL can still resolve against the changed base.

Style and stylesheet relationships need permitted contexts and real CSS resources. Named metadata, consumer-specific social formats and the document title have different contracts. Keep the body and annotations aligned before optimizing for a hypothetical search display.

### Primary example

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="description" content="A teaching page with fictional opening hours and a contact-status notice.">
  <title>Visit and contact | Teaching library</title>
</head>
<body>
  <h1>Visit and contact</h1>
  <h2>Example hours</h2>
  <p>Tuesday to Saturday, 09:00 to 17:00. Fictional hours for teaching.</p>
  <h2>Contact status</h2>
  <p>Real contact details are not configured in this example.</p>
</body>
</html>
```

The description now matches the actual fictional hours and contact-status notice in the body. Neither the metadata nor the page advertises a real library service or promises a particular search snippet.

### Common mistake

Giving every page the same title, or treating a meta description as a guaranteed search-result advertisement.

### Exercise

Which title better identifies the contact page: Welcome or Visit and contact | Neighbourhood Library? Does browser handling of a second base mean two base elements are conforming?

### Explained answer

The second identifies both the page purpose and the site. It remains useful in a tab list, bookmark collection or history entry where surrounding page content is absent. No. The authoring rule permits at most one. Metadata must also describe actual content rather than promise details the body does not supply.

### Sources

- [HTML Living Standard: metadata](https://html.spec.whatwg.org/multipage/semantics.html#document-metadata)
- [HTML Living Standard: meta](https://html.spec.whatwg.org/multipage/semantics.html#the-meta-element)
- [HTML Living Standard: base](https://html.spec.whatwg.org/multipage/semantics.html#the-base-element)
- [HTML Living Standard: style](https://html.spec.whatwg.org/multipage/semantics.html#the-style-element)

## Chapter 51: Resource relationships

### Objectives

- Read rel as a defined relationship
- Evaluate hints using actual requests
- Distinguish a reusable early request from a hint count

### Prerequisites

- CH-50

### Lesson

A link relation gives a relationship meaning rather than merely a destination. link rel="stylesheet" requests a stylesheet relationship. An anchor's rel can annotate a hyperlink. Their allowed contexts and effects depend on the particular link type.

preload, preconnect and related hints should correspond to a real loading need. A preload has request details such as as and, when relevant, type or crossorigin. A mismatch with the eventual request can waste work rather than helping.

## Avoid hints by habit
Measure the loading problem before adding hints. A preconnect to a third party can create network and privacy costs even when the visitor never uses that service. A resource hint is not proof of a faster page.

Canonical, alternate, author and other relations have defined uses and consumer expectations. Keep the reference's link-type inventory separate from a list of attribute names. The rel attribute's existence does not enumerate all its possible relationship tokens or guarantee a particular consumer's action.

## Request matching matters more than the word preload
For preload, as supplies the appropriate destination, such as script or style, and CORS/credentials and integrity details need to match the eventual use. An early request to the wrong resource or under a mismatched mode is not guaranteed reusable. Inspect real requests and cache behavior instead of counting link elements.

Modulepreload has module-specific fetching and processing behavior, not merely the semantics of preload with a different name. Preconnect concerns connection preparation, not downloading every future resource. Browser discretion and the workload still matter.

An alternate relation can identify an alternative representation or language under its applicable rules; a canonical relation communicates a preferred identifier to consumers, not an HTTP redirect. supported rel tokens and allowed contexts differ between link, a, area and form. relList.supports can be a scoped vocabulary probe, not proof that a consumer honors a canonical or that a hint improved performance.

### Primary example

```html
<link rel="stylesheet" href="../assets/site.css">
<link rel="icon" href="../assets/favicon.svg" type="image/svg+xml">
```

Both publication-relative resources are supplied. This is head-context markup, and the standalone example can fetch the real stylesheet and icon. The editable lab deliberately blocks external resource loading; do not weaken that policy to test a resource relationship.

### Common mistake

Preloading every image, font and script on a page without checking which resources are actually needed early.

### Exercise

Why might a preload download fail to benefit the later resource request? Does a canonical link redirect the visitor automatically?

### Explained answer

Its request parameters can differ from the later request, the resource may be unused, or the early work may contend with something more important. Inspect actual network behavior and request matching. No. It expresses a relationship for consumers. Likewise, a preload tag is not evidence of reuse or a measured loading improvement.

### Sources

- [HTML Living Standard: link types](https://html.spec.whatwg.org/multipage/links.html#linkTypes)
- [HTML Living Standard: link element](https://html.spec.whatwg.org/multipage/semantics.html#the-link-element)
- [HTML Living Standard: preload](https://html.spec.whatwg.org/multipage/links.html#link-type-preload)
- [HTML Living Standard: modulepreload](https://html.spec.whatwg.org/multipage/links.html#link-type-modulepreload)
- [HTML Living Standard: preconnect](https://html.spec.whatwg.org/multipage/links.html#link-type-preconnect)

## Chapter 52: Loading and policy attributes

### Objectives

- Distinguish loading hints from policy enforcement
- Trace integration claims to the owning specification
- Distinguish integrity enforcement from trust and nonce generation

### Prerequisites

- CH-51

### Lesson

loading and fetchpriority influence eligible loading decisions. They are not strict scheduling commands. crossorigin participates in the resource's fetching and CORS behavior; it does not grant your server permission to expose private data.

integrity integrates Subresource Integrity for supported resource uses. The hash must match the actual bytes, and cross-origin requirements matter. A placeholder digest is not a security control. nonce participates in a Content Security Policy arrangement and should be generated and delivered according to that policy's requirements.

## Follow the actual authority
HTML defines where these attributes integrate, while Fetch, CORS, CSP, Referrer Policy and SRI own important parts of their behavior. Read the relevant specification and deployment documentation for a security assertion.

referrerpolicy controls referrer information according to the defined policy, not all information a remote service can learn. Avoid presenting one attribute as a complete privacy solution. Test response headers and real requests as well as the source markup.

## Integrity is byte checking, not a trust certificate
SRI metadata can contain supported algorithm/digest tokens. When supported algorithms of different strengths are present, the strongest applicable algorithm governs matching; a matching weaker digest does not rescue a wrong stronger one. The check can block execution after a request has still occurred.

Cross-origin integrity use also needs the required CORS-enabled response. Adding crossorigin="anonymous" alone does not make a server grant that access. Changing even one script byte requires the corresponding digest to change. Review the code and distribution path, not merely the fact that a digest matches.

A CSP nonce should be unpredictable and fresh for the relevant response, with matching policy and element values. Hard-coding the same value in a static example is not the production generation mechanism. Nonce hiding moves the connected element's value out of the ordinary content attribute and exposes it through the nonce property under the defined rules.

Referrer Policy controls referrer information, not whether a destination receives a request or learns other request information. A no-referrer link can still navigate successfully while omitting the Referer header. Fetch/CORS, CSP, Referrer Policy and SRI remain distinct authorities and require actual header/request checks.

### Primary example

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>A supplied integrity-check example</title>
  <script src="../assets/integrity-demo.js"
          integrity="sha384-PYqdPK9Xnp/sfr1PXqd/y/pWZibvmdfPUzshLt7bF4U5H6NHlaHycsosnMoI3qin" defer></script>
</head>
<body>
  <h1>Integrity-check teaching example</h1>
  <p id="integrity-status">The supplied script has not run.</p>
</body>
</html>
```

The SHA-384 digest matches the actual supplied script bytes, not a placeholder. Its only action is to update the visible local status. Run the standalone example to inspect that resource; the editable lab blocks external scripts. Matching bytes does not prove that arbitrary code is safe.

### Common mistake

Copying a static nonce into every deployment and describing it as a complete CSP configuration.

### Exercise

Can adding crossorigin make a remote server return private data to your script when that server does not allow the origin? Will a matching weaker digest necessarily rescue a mismatched stronger digest?

### Explained answer

No. The server's CORS policy and the request mode and credentials behavior still apply. The attribute is part of a fetching configuration, not a bypass for a server's access policy. No. SRI uses its strongest applicable algorithm rules. Also, a matching digest verifies bytes rather than certifying the code or its source as safe.

### Sources

- [HTML Living Standard: CORS settings](https://html.spec.whatwg.org/multipage/urls-and-fetching.html#cors-settings-attributes)
- [HTML Living Standard: nonce](https://html.spec.whatwg.org/multipage/urls-and-fetching.html#attr-nonce)
- [Subresource Integrity specification](https://www.w3.org/TR/SRI/)
- [Content Security Policy specification](https://www.w3.org/TR/CSP3/)
- [Referrer Policy specification](https://www.w3.org/TR/referrer-policy/)
- [Fetch Standard](https://fetch.spec.whatwg.org/)

## Chapter 53: Attributes and properties

### Objectives

- Distinguish raw attributes and current state
- Read the correct layer when debugging controls
- Trace dirty/default/reset behavior and special reflection cases

### Prerequisites

- CH-52

### Lesson

getAttribute reads an attribute's text or returns null when absent. A corresponding DOM property can expose a parsed, normalized or stateful value. Do not assume they always remain equal.

For a text input, the value attribute is associated with its default value, while the value property describes the current value under the control's rules. User edits can change the current value without rewriting the source attribute. checked and defaultChecked have a related distinction for appropriate controls.

## Read the right layer
Boolean reflection commonly maps property true to attribute presence and false to absence. URL properties can return resolved absolute URLs while the attribute contains a relative string. Numeric reflection has its own rules, defaults and limits.

When debugging, ask whether the question concerns the original source, the current attribute, or the current control state. Reset behavior, script assignment and user interaction can affect different layers. Avoid a generic helper that treats every attribute and property as interchangeable strings.

## Default state follows its own update rules
Before a text input has a dirty current value, changing its value attribute can update the current value as well. After an edit or a value-property assignment, that synchronization changes; defaultValue can change without replacing the current text. A form reset restores the relevant default under its rules. Inspect the actual state instead of assuming every setAttribute call has the same result.

Nonce is a deliberate special case: the connected element's getAttribute("nonce") can be empty while its nonce property retains the internal nonce. Source text, current content attribute and internal state are not three interchangeable strings.

## Collections can have different result shapes
form.elements includes listed controls associated with that form, including eligible external controls, but has the historical image-button exception. namedItem can return a single element, a RadioNodeList when several match, or null. A RadioNodeList value concerns its checked radio, not a generic serialization of every checkbox. Use the form entry-list APIs for repeated submitted values.

select.options is a live options collection with its own indexed/add/remove behavior. selectedOptions has a separate current-selection purpose. Do not freeze a live collection assumption into a mutation loop without checking which nodes remain.

document.all is a legacy compatibility object with unusual falsiness and typeof behavior. It is not a recommended feature-detection API. A member inventory must retain that legacy behavior honestly, without encouraging it in new application code.

### Primary example

```html
<label for="nickname">Reading-group name</label>
<input id="nickname" name="nickname" value="Guest">
<script>
  const field = document.getElementById("nickname");
  field.value = "Ada";
  console.log(field.value);                 // Ada
  console.log(field.getAttribute("value")); // Guest
</script>
```

The script changes the current input value. The attribute retains Guest in this example. This is a specific input-state behavior, not a universal rule for every property named value.

### Common mistake

Using getAttribute("value") to read a text field after the user has edited it.

### Exercise

Which should an ordinary script read for the current text input value after editing? Can setting the value attribute affect a pristine input differently from one already edited?

### Explained answer

Read the input's value property. If you need the default value or the raw attribute, ask for that specifically instead of assuming it equals the current state. Yes. The dirty-value rules matter. Reset uses the relevant default, and nonce hiding is another reason not to assume getAttribute always reproduces the original source spelling.

### Sources

- [HTML Living Standard: reflection](https://html.spec.whatwg.org/multipage/common-dom-interfaces.html#reflecting-content-attributes-in-idl-attributes)
- [HTML Living Standard: input value](https://html.spec.whatwg.org/multipage/input.html#dom-input-value)
- [HTML Living Standard: form control collections](https://html.spec.whatwg.org/multipage/common-dom-interfaces.html#htmlformcontrolscollection)
- [HTML Living Standard: radio node lists](https://html.spec.whatwg.org/multipage/common-dom-interfaces.html#radionodelist)
- [HTML Living Standard: options collections](https://html.spec.whatwg.org/multipage/common-dom-interfaces.html#htmloptionscollection)
- [HTML Living Standard: legacy all collection](https://html.spec.whatwg.org/multipage/common-dom-interfaces.html#htmlallcollection)
- [HTML Living Standard: nonce hiding](https://html.spec.whatwg.org/multipage/urls-and-fetching.html#attr-nonce)


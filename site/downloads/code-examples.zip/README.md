# CTROTECH / Exact chapter code

By Odejobi Abiola Samuel. October 2026 production edition.

These 74 files preserve the exact UTF-8 code in content/chapters.json. Some are HTML fragments. Insert fragments in a complete UTF-8 HTML document before running them. External media, modules and server handlers may be reader-supplied; read the chapter explanation. File numbering matches chapter numbering. Wrapped browser examples and the seven complete projects are separate downloads.

© 2026 Odejobi Abiola Samuel. Third-party material retains its original rights and license terms.
No new open license or blanket reuse permission is granted by this edition.
